import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { PYQExplorer } from './components/PYQExplorer';
import { PracticeModes } from './components/PracticeModes';
import { CBTTestSimulator } from './components/CBTTestSimulator';
import { AIMasterChat } from './components/AIMasterChat';
import { BookLibrary } from './components/BookLibrary';
import { PremiumNotesStore } from './components/PremiumNotesStore';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { PDFReaderModal } from './components/PDFReaderModal';
import { CelebrationOverlay } from './components/CelebrationOverlay';
import { StreakDetailsModal } from './components/StreakDetailsModal';
import { AppGuideModal } from './components/AppGuideModal';
import { RankPredictorModal } from './components/RankPredictorModal';

import { mockQuestions } from './data/mockQuestions';
import { getAllPYQQuestions } from './data/pyqDatabase';
import { 
  getStoredStats, 
  saveStats, 
  toggleBookmark, 
  recordQuestionSolved 
} from './services/storage';
import { Question, UserProfileStats, BookItem, PremiumNoteBundle, MockTest, AppLanguage } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('pyq');
  const [stats, setStats] = useState<UserProfileStats>(getStoredStats());
  const [activeQuestionForAI, setActiveQuestionForAI] = useState<Question | null>(null);
  const [readerItem, setReaderItem] = useState<BookItem | PremiumNoteBundle | null>(null);
  const [selectedTestForCBT, setSelectedTestForCBT] = useState<MockTest | null>(null);
  const [showRankPredictor, setShowRankPredictor] = useState<boolean>(false);

  // Load the comprehensive 500 questions/year vault (2010 to 2026)
  const allQuestions = useMemo(() => getAllPYQQuestions(), []);

  // App Language State (English / हिंदी)
  const [language, setLanguage] = useState<AppLanguage>(() => {
    try {
      const saved = localStorage.getItem('sankalp_app_lang');
      return (saved === 'hi' || saved === 'en') ? saved : 'en';
    } catch {
      return 'en';
    }
  });

  const handleToggleLanguage = () => {
    setLanguage((prev) => {
      const next = prev === 'en' ? 'hi' : 'en';
      try {
        localStorage.setItem('sankalp_app_lang', next);
      } catch {}
      return next;
    });
  };

  // Daily Streak Tracking & Celebration Animation State
  const [showCelebration, setShowCelebration] = useState<boolean>(false);
  const [showStreakModal, setShowStreakModal] = useState<boolean>(false);
  const [showAppGuide, setShowAppGuide] = useState<boolean>(false);

  // Sync stats from storage on tab or action changes
  const refreshStats = () => {
    setStats(getStoredStats());
  };

  const handleToggleBookmark = (id: string) => {
    toggleBookmark(id);
    refreshStats();
  };

  const handleSolveQuestion = (isCorrect: boolean) => {
    const result = recordQuestionSolved(isCorrect);
    setStats(result.stats);
    if (result.goalJustCompleted) {
      setShowCelebration(true);
    }
  };

  const handleAskAIMaster = (question: Question) => {
    setActiveQuestionForAI(question);
    setActiveTab('ai-master');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Header with Daily Streak Tracker & Language Switcher */}
      <Header
        stats={stats}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        language={language}
        onToggleLanguage={handleToggleLanguage}
        onOpenQuickDoubt={() => {
          setActiveQuestionForAI(null);
          setActiveTab('ai-master');
        }}
        onOpenStreakDetails={() => setShowStreakModal(true)}
        onOpenAppGuide={() => setShowAppGuide(true)}
        onOpenRankPredictor={() => setShowRankPredictor(true)}
      />

      {/* Main Tab Navigation */}
      <Navigation
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        unlockedNotesCount={stats.unlockedNoteIds.length}
        language={language}
      />

      {/* Main Content View Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'pyq' && (
          <PYQExplorer
            questions={allQuestions}
            bookmarkedIds={stats.bookmarkedQuestionIds}
            onToggleBookmark={handleToggleBookmark}
            onSolveQuestion={handleSolveQuestion}
            onAskAIMaster={handleAskAIMaster}
            language={language}
            onStartChapterTest={(test) => {
              setSelectedTestForCBT(test);
              setActiveTab('cbt');
            }}
          />
        )}

        {activeTab === 'practice' && (
          <PracticeModes
            questions={allQuestions}
            onSolveQuestion={handleSolveQuestion}
            onAskAIMaster={handleAskAIMaster}
            language={language}
          />
        )}

        {activeTab === 'cbt' && (
          <CBTTestSimulator
            onAskAIMaster={handleAskAIMaster}
            initialTest={selectedTestForCBT}
            language={language}
            onClearInitialTest={() => setSelectedTestForCBT(null)}
            onTestCompleted={(goalJustCompleted) => {
              refreshStats();
              if (goalJustCompleted) {
                setShowCelebration(true);
              }
            }}
          />
        )}

        {activeTab === 'ai-master' && (
          <AIMasterChat
            initialQuestion={activeQuestionForAI}
            onClearInitialQuestion={() => setActiveQuestionForAI(null)}
          />
        )}

        {activeTab === 'books' && (
          <BookLibrary
            onAskAIMaster={handleAskAIMaster}
            onOpenBookReader={(book) => setReaderItem(book)}
            language={language}
          />
        )}

        {activeTab === 'notes' && (
          <PremiumNotesStore
            stats={stats}
            onStatsUpdated={refreshStats}
            onOpenNotesReader={(bundle) => setReaderItem(bundle)}
            language={language}
            onLaunchChapterTest={() => setActiveTab('cbt')}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsDashboard
            stats={stats}
            onNavigateTab={(tab) => setActiveTab(tab)}
            onOpenStreakModal={() => setShowStreakModal(true)}
          />
        )}
      </main>

      {/* App Guide & How-To-Use Walkthrough Modal */}
      {showAppGuide && (
        <AppGuideModal
          isOpen={showAppGuide}
          onClose={() => setShowAppGuide(false)}
          language={language}
          onNavigateTab={(tab) => setActiveTab(tab)}
        />
      )}

      {/* All-India Rank (AIR) Predictor Modal */}
      {showRankPredictor && (
        <RankPredictorModal
          isOpen={showRankPredictor}
          onClose={() => setShowRankPredictor(false)}
          stats={stats}
          language={language}
        />
      )}

      {/* Full Document Reader Modal */}
      {readerItem && (
        <PDFReaderModal
          item={readerItem}
          onClose={() => setReaderItem(null)}
          onAskAIMaster={handleAskAIMaster}
        />
      )}

      {/* Streak Details Modal */}
      {showStreakModal && (
        <StreakDetailsModal
          stats={stats}
          onClose={() => setShowStreakModal(false)}
          onStatsUpdated={refreshStats}
          onTriggerTestCelebration={() => {
            setShowStreakModal(false);
            setShowCelebration(true);
          }}
        />
      )}

      {/* Celebration Animation Overlay when Daily Goal is Reached */}
      {showCelebration && (
        <CelebrationOverlay
          streakDays={stats.streakDays}
          dailyGoal={stats.dailyGoal || 5}
          onClose={() => setShowCelebration(false)}
          onViewStreakDetails={() => {
            setShowCelebration(false);
            setShowStreakModal(true);
          }}
        />
      )}

      {/* Subtle Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 text-center text-xs text-slate-400">
        <p>
          <span className="font-semibold text-amber-300">👑 Owner: MOHIT PARAMHANS</span> &bull; JEE Pulse &bull; 2010–2026 PYQ Vault &bull; 20,000+ Questions Archive &bull; English &amp; हिन्दी Dual Language &bull; Kota Topper Formulas
        </p>
      </footer>
    </div>
  );
}
