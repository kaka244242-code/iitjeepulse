export type Subject = 'Physics' | 'Chemistry' | 'Mathematics';

export type ExamType = 'JEE Main' | 'JEE Advanced';

export type Difficulty = 'Easy' | 'Moderate' | 'Challenging' | 'IIT Advanced Level';

export interface Question {
  id: string;
  exam: ExamType;
  year: number;
  subject: Subject;
  topic: string;
  subtopic?: string;
  difficulty: Difficulty;
  question: string;
  questionHindi?: string;
  diagramSvg?: string; // Optional SVG or schematic representation
  options: string[];
  optionsHindi?: string[];
  correctOption: number; // 0-based index
  solution: string;
  solutionHindi?: string;
  keyFormula?: string;
  keyFormulaHindi?: string;
  topperTrick?: string;
  topperTrickHindi?: string;
  bookmarked?: boolean;
}

export interface Flashcard {
  id: string;
  subject: Subject;
  topic: string;
  title: string;
  front: string; // The formula / concept question
  back: string;  // Detailed formula, derivation snippet, conditions & exceptions
  tips: string;
  chapter?: string;
  chapterHindi?: string;
  frontHindi?: string;
  backHindi?: string;
  formula?: string;
  formulaHindi?: string;
  topperHack?: string;
  importance?: string;
  examFrequency?: string;
}

export interface MockTest {
  id: string;
  testNumber?: number; // 1 to 1000
  title: string;
  titleHindi?: string;
  examType: ExamType;
  durationMinutes: number;
  totalQuestions: number;
  totalMarks: number;
  subjectBreakdown: {
    Physics: number;
    Chemistry: number;
    Mathematics: number;
  };
  questions: Question[];
  difficulty: 'Standard JEE Main' | 'High Rank Predictor' | 'JEE Advanced Paper-1' | 'Hard / IIT Advanced Level';
  description: string;
  descriptionHindi?: string;
  chapter?: string;
  isChapterTest?: boolean;
  category?: 'high_yield_ranker' | 'chapter' | 'hard_advanced' | 'grand_mock' | 'year_wise' | 'tricky_traps';
  weightageTag?: string; // e.g. "🔥 16-20 Marks Guaranteed"
  weightageTagHindi?: string;
  highYieldTips?: string; // High-yield score strategy
  highYieldTipsHindi?: string;
  isBilingualAvailable?: boolean;
}

export interface ChapterTestInfo {
  id: string;
  chapter: string;
  subject: Subject;
  examType: 'JEE Main & Advanced' | 'JEE Main' | 'JEE Advanced';
  questionsCount: number;
  durationMinutes: number;
  totalMarks: number;
  yearCoverage: string; // "2010 – 2026"
  difficulty: Difficulty;
  description: string;
  questions: Question[];
  highYieldPoints: string[];
}

export interface UserTestAttempt {
  id: string;
  testId: string;
  testTitle: string;
  date: string;
  totalTimeSpentSeconds: number;
  score: number;
  maxScore: number;
  accuracy: number;
  correctCount: number;
  incorrectCount: number;
  unattemptedCount: number;
  subjectScores: {
    Physics: { score: number; total: number; correct: number; incorrect: number };
    Chemistry: { score: number; total: number; correct: number; incorrect: number };
    Mathematics: { score: number; total: number; correct: number; incorrect: number };
  };
  answers: Record<string, number | null>; // questionId -> selectedOption index
}

export type AppLanguage = 'en' | 'hi';

export interface BookItem {
  id: string;
  title: string;
  author: string;
  subject: Subject | 'All Subjects';
  category: 'Textbook' | 'Problem Book' | 'Reference' | 'PYQ Compendium' | 'Custom Upload' | 'PYQ Practice Sheet';
  totalPages: number;
  rating: number;
  coverColor: string;
  description: string;
  chapters: string[];
  sampleContent: string;
  fileDataUrl?: string; // For user uploaded PDFs
  fileName?: string;
  uploadedAt?: string;
  isUserUploaded?: boolean;
  questionCount?: number;
  yearCoverage?: string;
  exemplarQuestions?: {
    year: number;
    exam: string;
    questionEn: string;
    questionHi: string;
    optionsEn: string[];
    optionsHi: string[];
    correctOption: number;
    solutionEn: string;
    solutionHi: string;
    topperTrickEn?: string;
    topperTrickHi?: string;
  }[];
  chapterQuestions?: {
    chapterIndex: number;
    chapterTitle: string;
    questions: {
      year: number;
      exam: string;
      questionEn: string;
      questionHi: string;
      optionsEn: string[];
      optionsHi: string[];
      correctOption: number;
      solutionEn: string;
      solutionHi: string;
      topperTrickEn?: string;
      topperTrickHi?: string;
    }[];
  }[];
}

export interface PremiumNoteBundle {
  id: string;
  title: string;
  subtitle: string;
  author: string;
  authorRank: string; // e.g. "AIR 43 JEE Advanced"
  subject: Subject | 'Full PCM';
  pages: number;
  priceCoins: number;
  rating: number;
  reviewsCount: number;
  previewPages: string[];
  fullContentSnippet: string;
  isUnlocked?: boolean;
  tags: string[];
  features: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
  subject?: Subject;
  doubtImage?: string;
  isCodeOrMath?: boolean;
}

export interface UserProfileStats {
  coins: number;
  streakDays: number;
  longestStreak: number;
  lastActiveDate: string; // 'YYYY-MM-DD'
  dailyGoal: number; // target questions per day (e.g. 5)
  todayQuestionsSolved: number;
  todayGoalCompleted: boolean;
  activityHistory?: Record<string, number>; // 'YYYY-MM-DD' -> count of questions solved
  questionsSolved: number;
  testsCompleted: number;
  accuracyRate: number;
  unlockedNoteIds: string[];
  bookmarkedQuestionIds: string[];
}
