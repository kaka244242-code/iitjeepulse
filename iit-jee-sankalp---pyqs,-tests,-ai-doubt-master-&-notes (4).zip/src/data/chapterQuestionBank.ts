import { PYQSheetItem } from './allChaptersNotesAndSheets';

type ExemplarQ = PYQSheetItem['exemplarQuestions'][0];

// Balanced answer sequence across 20 questions (5 A's, 5 B's, 5 C's, 5 D's):
// Q1: B (1), Q2: C (2), Q3: A (0), Q4: D (3), Q5: B (1),
// Q6: D (3), Q7: A (0), Q8: C (2), Q9: B (1), Q10: C (2),
// Q11: D (3), Q12: A (0), Q13: B (1), Q14: A (0), Q15: C (2),
// Q16: D (3), Q17: C (2), Q18: B (1), Q19: A (0), Q20: D (3)
export const BALANCED_ANSWER_PATTERN = [1, 2, 0, 3, 1, 3, 0, 2, 1, 2, 3, 0, 1, 0, 2, 3, 2, 1, 0, 3];

export interface ConcreteQuestionData {
  year: number;
  exam: string;
  qEn: string;
  qHi: string;
  correctValEn: string;
  distractorsEn: [string, string, string];
  correctValHi: string;
  distractorsHi: [string, string, string];
  solEn: string;
  solHi: string;
  trickEn: string;
  trickHi: string;
}

// Builds an ExemplarQ with the correct answer placed at the assigned correctOption (0=A, 1=B, 2=C, 3=D)
export function createExemplar(data: ConcreteQuestionData, correctOption: number): ExemplarQ {
  const optionsEn = ['', '', '', ''];
  const optionsHi = ['', '', '', ''];

  optionsEn[correctOption] = data.correctValEn;
  optionsHi[correctOption] = data.correctValHi;

  let dIdx = 0;
  for (let i = 0; i < 4; i++) {
    if (i !== correctOption) {
      optionsEn[i] = data.distractorsEn[dIdx];
      optionsHi[i] = data.distractorsHi[dIdx];
      dIdx++;
    }
  }

  return {
    year: data.year,
    exam: data.exam,
    questionEn: data.qEn,
    questionHi: data.qHi,
    optionsEn,
    optionsHi,
    correctOption,
    solutionEn: data.solEn,
    solutionHi: data.solHi,
    topperTrickEn: data.trickEn,
    topperTrickHi: data.trickHi,
  };
}
