import { MockTest } from '../types';
import { mockQuestions } from './mockQuestions';
import { chapterTestsList } from './chapterTests';

export const fullSyllabusMockTests: MockTest[] = [
  {
    id: 'test-cbt-01',
    title: 'JEE Main 2025-2026 Full Syllabus High-Yield CBT Mock 01',
    examType: 'JEE Main',
    durationMinutes: 45,
    totalQuestions: mockQuestions.length,
    totalMarks: mockQuestions.length * 4,
    subjectBreakdown: {
      Physics: mockQuestions.filter(q => q.subject === 'Physics').length,
      Chemistry: mockQuestions.filter(q => q.subject === 'Chemistry').length,
      Mathematics: mockQuestions.filter(q => q.subject === 'Mathematics').length,
    },
    difficulty: 'Standard JEE Main',
    description: 'Realistic NTA CBT simulator featuring standard marking (+4 for correct, -1 for wrong, 0 for unattempted). Includes question palette, countdown timer, section navigation, and comprehensive scorecard analysis.',
    questions: mockQuestions,
    isChapterTest: false,
  },
  {
    id: 'test-cbt-02',
    title: 'JEE Advanced Rank-Booster Super Mock (Paper 1)',
    examType: 'JEE Advanced',
    durationMinutes: 60,
    totalQuestions: mockQuestions.filter(q => q.exam === 'JEE Advanced' || q.difficulty === 'Challenging' || q.difficulty === 'IIT Advanced Level').length,
    totalMarks: mockQuestions.filter(q => q.exam === 'JEE Advanced' || q.difficulty === 'Challenging' || q.difficulty === 'IIT Advanced Level').length * 4,
    subjectBreakdown: {
      Physics: mockQuestions.filter(q => q.subject === 'Physics' && (q.exam === 'JEE Advanced' || q.difficulty === 'IIT Advanced Level')).length,
      Chemistry: mockQuestions.filter(q => q.subject === 'Chemistry' && (q.exam === 'JEE Advanced' || q.difficulty === 'IIT Advanced Level')).length,
      Mathematics: mockQuestions.filter(q => q.subject === 'Mathematics' && (q.exam === 'JEE Advanced' || q.difficulty === 'IIT Advanced Level')).length,
    },
    difficulty: 'JEE Advanced Paper-1',
    description: 'Intense JEE Advanced benchmark containing rigorous conceptual questions. Strict negative marking to hone decision-making on whether to attempt or leave risky questions.',
    questions: mockQuestions.filter(q => q.exam === 'JEE Advanced' || q.difficulty === 'Challenging' || q.difficulty === 'IIT Advanced Level'),
    isChapterTest: false,
  },
  {
    id: 'test-cbt-03',
    title: 'Rapid 15-Min Physics Speed & Accuracy Sprint',
    examType: 'JEE Main',
    durationMinutes: 15,
    totalQuestions: mockQuestions.filter(q => q.subject === 'Physics').length,
    totalMarks: mockQuestions.filter(q => q.subject === 'Physics').length * 4,
    subjectBreakdown: {
      Physics: mockQuestions.filter(q => q.subject === 'Physics').length,
      Chemistry: 0,
      Mathematics: 0,
    },
    difficulty: 'Standard JEE Main',
    description: 'Targeted physics sprint to evaluate speed under pressure across Rotational Motion, Electrodynamics, Modern Physics, and Thermodynamics.',
    questions: mockQuestions.filter(q => q.subject === 'Physics'),
    isChapterTest: false,
  },
];

export const chapterMockTests: MockTest[] = chapterTestsList.map((ct) => ({
  id: ct.id,
  title: `${ct.chapter} · Chapter CBT Test (${ct.yearCoverage})`,
  examType: ct.examType === 'JEE Advanced' ? 'JEE Advanced' : 'JEE Main',
  durationMinutes: ct.durationMinutes,
  totalQuestions: ct.questions.length,
  totalMarks: ct.questions.length * 4,
  subjectBreakdown: {
    Physics: ct.subject === 'Physics' ? ct.questions.length : 0,
    Chemistry: ct.subject === 'Chemistry' ? ct.questions.length : 0,
    Mathematics: ct.subject === 'Mathematics' ? ct.questions.length : 0,
  },
  difficulty: ct.difficulty === 'IIT Advanced Level' ? 'JEE Advanced Paper-1' : 'Standard JEE Main',
  description: `${ct.description} Curated from authentic ${ct.yearCoverage} JEE Main & Advanced official question papers.`,
  chapter: ct.chapter,
  isChapterTest: true,
  questions: ct.questions,
}));

export const mockTests: MockTest[] = [
  ...fullSyllabusMockTests,
  ...chapterMockTests,
];
