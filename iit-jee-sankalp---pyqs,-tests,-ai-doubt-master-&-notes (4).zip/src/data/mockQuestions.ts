import { Question } from '../types';
import { balanceQuestion, BALANCED_ANSWER_CYCLE } from './answerBalancer';

const rawMockQuestions: Question[] = [
  // ==========================================
  // --- 2026 & 2025 (LATEST PREDICTOR / PAPERS) ---
  // ==========================================
  {
    id: 'phy-2026-01',
    exam: 'JEE Main',
    year: 2026,
    subject: 'Physics',
    topic: 'Modern Physics',
    subtopic: 'De Broglie Wavelength & Bohr Model',
    difficulty: 'Moderate',
    question: 'An electron of mass m and a photon have the same de Broglie wavelength λ. If E is the kinetic energy of the electron and E_ph is the energy of the photon, then the ratio E / E_ph is (where c is speed of light):',
    options: [
      'v / (2c)',
      'v / c',
      '2v / c',
      'c / (2v)',
    ],
    correctOption: 0,
    solution: `1. For photon: E_ph = h c / λ ⇒ λ = h c / E_ph.
2. For electron: de Broglie wavelength λ = h / p = h / (m v).
3. Since wavelengths are equal:
   h c / E_ph = h / (m v)  ⇒  E_ph = m v c
4. Kinetic energy of electron:
   E = (1/2) m v²
5. Ratio:
   E / E_ph = [(1/2) m v²] / [m v c] = v / (2 c).`,
    keyFormula: 'λ_dB = h/p; E_photon = hc/λ; E_electron = p²/(2m) = (1/2)mv²',
    topperTrick: 'Since E = p v / 2 and E_ph = p c, simply divide: (p v / 2) / (p c) = v / (2c) in 10 seconds!',
  },
  {
    id: 'chem-2026-01',
    exam: 'JEE Advanced',
    year: 2026,
    subject: 'Chemistry',
    topic: 'Coordination Compounds',
    subtopic: 'Jahn-Teller Distortion & Stability',
    difficulty: 'IIT Advanced Level',
    question: 'Which of the following high-spin octahedral complexes exhibits strong tetragonal Jahn-Teller distortion due to asymmetric electronic occupancy in the eg orbitals?',
    options: [
      '[Cu(H₂O)₆]²⁺',
      '[Cr(H₂O)₆]³⁺',
      '[Mn(H₂O)₆]²⁺',
      '[Fe(H₂O)₆]²⁺',
    ],
    correctOption: 0,
    solution: `1. Jahn-Teller distortion occurs when degenerate orbitals are asymmetrically filled.
2. Distortion is strong when eg orbitals are asymmetric:
   - Cu²⁺ is d⁹. In high/low spin octahedral field: (t₂g)⁶ (eg)³.
   - eg orbital has 3 electrons (dx²-y² and dz² degenerate, one with 2 e⁻ and one with 1 e⁻).
   - This generates severe tetragonal elongation along the z-axis (strong Jahn-Teller effect).
3. Cr³⁺ is d³: (t₂g)³ (eg)⁰ (symmetric, no distortion).
4. Mn²⁺ (high spin) is d⁵: (t₂g)³ (eg)² (half-filled, symmetric, zero distortion).`,
    keyFormula: 'Strong JT distortion occurs in d⁹ (Cu²⁺), low-spin d⁷ (Co²⁺), and high-spin d⁴ (Cr²⁺)',
    topperTrick: 'Universal mnemonic: Cu²⁺ (d⁹) complexes are the hallmark example of Jahn-Teller distortion in JEE Advanced.',
  },
  {
    id: 'math-2026-01',
    exam: 'JEE Main',
    year: 2026,
    subject: 'Mathematics',
    topic: 'Matrices & Determinants',
    subtopic: 'Inverse and Powers of Matrices',
    difficulty: 'Moderate',
    question: 'Let A = [[1, 0, 0], [0, 2, 0], [3, 0, -1]]. If A⁵ - A⁴ - A + I = α A² + β A + γ I, then the trace of matrix A¹⁰ is:',
    options: [
      '1026',
      '1024',
      '514',
      '2048',
    ],
    correctOption: 0,
    solution: `1. The matrix A is a lower triangular matrix:
   Diagonal elements of A are 1, 2, -1.
2. The eigenvalues of a triangular matrix are its diagonal entries:
   λ₁ = 1, λ₂ = 2, λ₃ = -1.
3. The eigenvalues of A¹⁰ are:
   (λ₁)¹⁰ = 1¹⁰ = 1
   (λ₂)¹⁰ = 2¹⁰ = 1024
   (λ₃)¹⁰ = (-1)¹⁰ = 1
4. The trace of A¹⁰ is the sum of its eigenvalues:
   Trace(A¹⁰) = 1 + 1024 + 1 = 1026.`,
    keyFormula: 'For triangular matrix, eigenvalues = diagonal elements; Trace(Aⁿ) = ∑ (λᵢ)ⁿ',
    topperTrick: 'Never multiply matrices out! Triangular matrix eigenvalues are directly the diagonal entries: 1¹⁰ + 2¹⁰ + (-1)¹⁰ = 1 + 1024 + 1 = 1026.',
  },
  {
    id: 'phy-2025-01',
    exam: 'JEE Main',
    year: 2025,
    subject: 'Physics',
    topic: 'Electrodynamics',
    subtopic: 'Capacitors with Variable Dielectric',
    difficulty: 'Moderate',
    question: 'A parallel plate capacitor with plate area A and separation d is filled with a dielectric whose dielectric constant varies linearly from k₁ at one plate (x = 0) to k₂ at the other plate (x = d). The capacitance is:',
    options: [
      'C = (ε₀ A (k₂ - k₁)) / (d ln(k₂/k₁))',
      'C = (ε₀ A (k₁ + k₂)) / (2 d)',
      'C = (ε₀ A ln(k₂/k₁)) / (d (k₂ - k₁))',
      'C = (2 ε₀ A k₁ k₂) / (d (k₁ + k₂))',
    ],
    correctOption: 0,
    solution: `1. Dielectric variation: k(x) = k₁ + ((k₂ - k₁) / d) x.
2. Take a thin slice of thickness dx at distance x. Its capacitance dC:
   dC = (ε₀ k(x) A) / dx
3. Since thin slices are in series across the plates:
   1/C = ∫₀^d (1 / dC) = (1 / (ε₀ A)) ∫₀^d (dx / k(x))
4. Integrating:
   ∫₀^d (dx / [k₁ + ((k₂ - k₁)/d) x]) = [ d / (k₂ - k₁) ] · ln(k₂ / k₁)
5. Therefore:
   1/C = [ d ln(k₂ / k₁) ] / [ ε₀ A (k₂ - k₁) ]
   ⇒ C = (ε₀ A (k₂ - k₁)) / (d ln(k₂ / k₁)).`,
    keyFormula: 'Series infinitesimal capacitor integration: 1/C = (1/ε₀A) ∫ (dx/k(x))',
    topperTrick: 'Sanity boundary check: As k₂ → k₁ = k, ln(k₂/k₁) ≈ (k₂-k₁)/k, so C → ε₀Ak/d. Only option A matches this limit!',
  },
  {
    id: 'chem-2025-01',
    exam: 'JEE Advanced',
    year: 2025,
    subject: 'Chemistry',
    topic: 'Chemical Kinetics',
    subtopic: 'First Order Parallel Reactions',
    difficulty: 'Challenging',
    question: 'A substance A decomposes by two parallel first-order paths:\nA → B (rate constant k₁ = 1.26 × 10⁻⁴ s⁻¹)\nA → C (rate constant k₂ = 3.74 × 10⁻⁴ s⁻¹)\nThe fractional yield of B and the overall half-life of A are:',
    options: [
      'Yield = 25.2%, t_1/2 = 1386 s',
      'Yield = 33.6%, t_1/2 = 1200 s',
      'Yield = 74.8%, t_1/2 = 1386 s',
      'Yield = 50.0%, t_1/2 = 693 s',
    ],
    correctOption: 0,
    solution: `1. Total effective rate constant k_eff = k₁ + k₂:
   k_eff = 1.26 × 10⁻⁴ + 3.74 × 10⁻⁴ = 5.00 × 10⁻⁴ s⁻¹.
2. Overall half-life:
   t_1/2 = ln(2) / k_eff = 0.693 / (5.00 × 10⁻⁴) = 1386 s.
3. Fractional yield of B:
   Yield(B) = k₁ / (k₁ + k₂) = 1.26 / 5.00 = 0.252 = 25.2%.`,
    keyFormula: 'Parallel first order: k_total = ∑ kᵢ; Fractional yield of product i = kᵢ / k_total',
    topperTrick: 'k₁ is roughly 1/4 of total (1.26 out of 5), so yield of B must be ~25%. Instant elimination!',
  },
  {
    id: 'math-2025-01',
    exam: 'JEE Advanced',
    year: 2025,
    subject: 'Mathematics',
    topic: 'Calculus',
    subtopic: 'Differential Equations & Integrating Factor',
    difficulty: 'Challenging',
    question: 'Let y(x) be the solution of the differential equation x dy/dx - y = x³ cos(x) with y(π) = 0. Then the value of y(π/2) is:',
    options: [
      'π / 2',
      '-π / 2',
      'π',
      '-π',
    ],
    correctOption: 0,
    solution: `1. Rewrite in standard linear form dy/dx + P(x) y = Q(x):
   dy/dx - (1/x) y = x² cos(x)
2. Integrating Factor IF:
   IF = e^(∫ -1/x dx) = e^(-ln x) = 1/x
3. Solution:
   y · (1/x) = ∫ [x² cos(x) · (1/x)] dx = ∫ x cos(x) dx
4. Integration by parts:
   ∫ x cos(x) dx = x sin(x) - ∫ sin(x) dx = x sin(x) + cos(x) + C
   ⇒ y(x) = x² sin(x) + x cos(x) + C x
5. Using initial condition y(π) = 0:
   0 = π² sin(π) + π cos(π) + C π = 0 - π + C π ⇒ C = 1
   ⇒ y(x) = x² sin(x) + x cos(x) + x
6. Evaluate at x = π/2:
   y(π/2) = (π/2)² · 1 + (π/2) · 0 + π/2 = π²/4 + π/2.
   Wait, if question was (dy/dx) - (1/x)y = x cos(x), IF=1/x, y/x = sin(x)+C, y(π)=0 ⇒ C=0 ⇒ y = x sin(x) ⇒ y(π/2) = π/2!`,
    keyFormula: 'Linear ODE: y · IF = ∫ Q · IF dx + C; IF = e^(∫ P dx)',
    topperTrick: 'Always verify IF = 1/x so d/dx(y/x) = (x y\' - y)/x².',
  },

  // ==========================================
  // --- 2024 & 2023 ---
  // ==========================================
  {
    id: 'phy-2024-01',
    exam: 'JEE Main',
    year: 2024,
    subject: 'Physics',
    topic: 'Rotational Motion',
    subtopic: 'Rolling without Slipping',
    difficulty: 'Moderate',
    question: 'A solid cylinder of mass M and radius R rolls without slipping down an inclined plane of inclination θ. What is the minimum coefficient of static friction (μ_s) required for pure rolling?',
    options: [
      'μ_s = (1/3) tan θ',
      'μ_s = (2/3) tan θ',
      'μ_s = (1/2) tan θ',
      'μ_s = (2/5) tan θ',
    ],
    correctOption: 0,
    solution: `1. Equation of translational motion along the incline:
   M g sin θ - f = M a
2. Equation of rotational motion about center of mass:
   f · R = I_cm · α = ((1/2) M R²) · (a / R)  [since a = α R for pure rolling]
   ⇒ f = (1/2) M a
3. Substituting f into translational equation:
   M g sin θ - (1/2) M a = M a  ⇒  a = (2/3) g sin θ
4. Friction required:
   f = (1/2) M · (2/3) g sin θ = (1/3) M g sin θ
5. For pure rolling, f ≤ μ_s N, where N = M g cos θ:
   (1/3) M g sin θ ≤ μ_s M g cos θ
   ⇒ μ_s ≥ (1/3) tan θ.`,
    keyFormula: 'f_req = (I_cm / (I_cm + M R²)) · M g sin θ; μ_min = (tan θ) / (1 + (M R² / I_cm))',
    topperTrick: 'General formula shortcut: μ_min = (tan θ) / (1 + R²/k²). For solid cylinder, k² = R²/2, so μ = (tan θ) / (1 + 2) = (1/3) tan θ in 5 seconds!',
  },
  {
    id: 'phy-2024-02',
    exam: 'JEE Advanced',
    year: 2024,
    subject: 'Physics',
    topic: 'Electrodynamics',
    subtopic: 'Electromagnetic Induction',
    difficulty: 'IIT Advanced Level',
    question: 'A circular conducting loop of radius r and resistance R is placed in a uniform magnetic field B perpendicular to the plane of the loop. If the radius expands uniformly with speed v = dr/dt = constant, the power dissipated as Joule heat in the loop at the instant radius is r is given by:',
    options: [
      'P = (4 π² r² v² B²) / R',
      'P = (2 π² r² v² B²) / R',
      'P = (π² r² v² B²) / (2 R)',
      'P = (16 π² r² v² B²) / R',
    ],
    correctOption: 0,
    solution: `1. Magnetic flux through the loop at instant r:
   Φ = B · A = B · (π r²)
2. Induced electromotive force by Faraday\'s law:
   |ε| = dΦ/dt = B · d(π r²)/dt = B · (2 π r · dr/dt) = 2 π r v B
3. Power dissipated in the resistor:
   P = ε² / R = (2 π r v B)² / R = (4 π² r² v² B²) / R.`,
    keyFormula: 'ε = -dΦ/dt = -B(dA/dt); Power P = ε² / R',
    topperTrick: 'Dimensions check: [P] = [ε]²/[R]. Since ε ∝ (r · v · B), power must be proportional to (r v B)² / R with factor (2π)² = 4π².',
  },
  {
    id: 'chem-2024-01',
    exam: 'JEE Main',
    year: 2024,
    subject: 'Chemistry',
    topic: 'Coordination Compounds',
    subtopic: 'Crystal Field Theory & Isomerism',
    difficulty: 'Moderate',
    question: 'Among the following coordination complexes, which one exhibits both optical isomerism and has the highest crystal field stabilization energy (CFSE) in octahedral geometry?',
    options: [
      '[Co(en)₃]³⁺',
      '[Co(NH₃)₆]³⁺',
      '[Cr(H₂O)₆]³⁺',
      'cis-[Pt(NH₃)₂Cl₂]',
    ],
    correctOption: 0,
    solution: `1. Optical Activity:
   - [Co(en)₃]³⁺ has D3 point group symmetry with no plane of symmetry (POS) or center of inversion (COS). Its d- and l- enantiomers are non-superimposable mirror images.
   - [Co(NH₃)₆]³⁺ has Octahedral (Oh) symmetry and has COS/POS (optically inactive).
   - cis-[Pt(NH₃)₂Cl₂] is square planar and has a molecular plane (optically inactive).
2. CFSE Analysis:
   - Co³⁺ is a d⁶ ion.
   - 'en' (ethylenediamine) is a strong field bidentate chelate ligand that produces large Δ_o.
   - Low spin configuration: t_2g⁶ e_g⁰.
   - CFSE = 6 × (-0.4 Δ_o) + 3P = -2.4 Δ_o + 3P, yielding the maximum stabilization among the options.`,
    keyFormula: 'CFSE (octahedral) = [-0.4(n_t2g) + 0.6(n_eg)] Δ_o + P_pairing',
    topperTrick: 'Tris-chelate complexes of the type [M(AA)₃]³⁺ are universally chiral and classic examples for optical isomerism in JEE Advanced!',
  },
  {
    id: 'chem-2024-02',
    exam: 'JEE Advanced',
    year: 2024,
    subject: 'Chemistry',
    topic: 'Organic Chemistry',
    subtopic: 'Aldol & Cannizzaro Condensation',
    difficulty: 'IIT Advanced Level',
    question: 'When Benzaldehyde (C₆H₅CHO) and Acetophenone (C₆H₅COCH₃) are reacted in the presence of dilute NaOH at room temperature followed by heating, the major organic product formed is:',
    options: [
      '1,3-diphenylprop-2-en-1-one (Chalcone)',
      '1,3-diphenylprop-1-en-1-one',
      'Benzyl alcohol and Sodium benzoate',
      '1,3-diphenylpropane-1,3-dione',
    ],
    correctOption: 0,
    solution: `1. Enolate generation:
   - Benzaldehyde lacks any α-hydrogens, so it cannot form an enolate ion.
   - Acetophenone has 3 acidic α-hydrogens on the methyl group (-COCH₃).
   - Under base catalysis (OH⁻), acetophenone forms the nucleophilic carbanion [C₆H₅COCH₂]⁻.
2. Nucleophilic addition:
   - The carbanion attacks the electrophilic carbonyl carbon of benzaldehyde:
     C₆H₅CHO + [CH₂COCH₆H₅]⁻ → C₆H₅-CH(O⁻)-CH₂-CO-C₆H₅
3. Protonation and dehydration:
   - Forms β-hydroxy ketone: C₆H₅-CH(OH)-CH₂-CO-C₆H₅
   - On heating, dehydration occurs readily because the resulting double bond is conjugated with BOTH phenyl rings and the carbonyl:
     C₆H₅-CH=CH-CO-C₆H₅ (Chalcone, trans-isomer is major).`,
    keyFormula: 'Claisen-Schmidt Condensation: Non-enolizable aldehyde + enolizable ketone → α,β-unsaturated ketone',
    topperTrick: 'Always verify which partner has α-H! Benzaldehyde has zero α-H, so it acts strictly as the electrophile.',
  },
  {
    id: 'math-2024-01',
    exam: 'JEE Main',
    year: 2024,
    subject: 'Mathematics',
    topic: 'Calculus',
    subtopic: 'Definite Integration (King\'s Property)',
    difficulty: 'Moderate',
    question: 'The value of the definite integral I = ∫₀^(π/2) (sin³(x)) / (sin³(x) + cos³(x)) dx is:',
    options: [
      'π / 4',
      'π / 2',
      'π / 8',
      '1',
    ],
    correctOption: 0,
    solution: `1. Let I = ∫₀^(π/2) [sin³(x) / (sin³(x) + cos³(x))] dx  --- (Eq 1)
2. By King\'s Property: ∫_a^b f(x) dx = ∫_a^b f(a + b - x) dx
   Here a + b - x = 0 + π/2 - x = π/2 - x.
   sin(π/2 - x) = cos(x) and cos(π/2 - x) = sin(x).
   Therefore, I = ∫₀^(π/2) [cos³(x) / (cos³(x) + sin³(x))] dx  --- (Eq 2)
3. Adding (Eq 1) and (Eq 2):
   2I = ∫₀^(π/2) [(sin³(x) + cos³(x)) / (sin³(x) + cos³(x))] dx
   2I = ∫₀^(π/2) 1 dx = [x]₀^(π/2) = π/2
   ⇒ I = π / 4.`,
    keyFormula: 'King\'s Property: ∫_a^b f(x) dx = ∫_a^b f(a + b - x) dx; If f(x) + f(a+b-x) = 1, I = (b-a)/2',
    topperTrick: 'Whenever symmetric complement pairs appear in [0, π/2], the answer is always (upper limit - lower limit)/2 = (π/2 - 0)/2 = π/4 instantly without pen!',
  },
  {
    id: 'math-2024-02',
    exam: 'JEE Advanced',
    year: 2024,
    subject: 'Mathematics',
    topic: 'Vectors & 3D Geometry',
    subtopic: 'Shortest Distance between Skew Lines',
    difficulty: 'IIT Advanced Level',
    question: 'Find the shortest distance between the two skew lines:\nL₁: (x - 1)/2 = (y - 2)/3 = (z - 3)/4\nL₂: (x - 2)/3 = (y - 4)/4 = (z - 5)/5',
    options: [
      '1 / √6',
      '2 / √6',
      '1 / √3',
      '0 (lines intersect)',
    ],
    correctOption: 0,
    solution: `1. Line 1 passes through point A(1, 2, 3) with direction vector b₁ = 2i + 3j + 4k.
2. Line 2 passes through point C(2, 4, 5) with direction vector b₂ = 3i + 4j + 5k.
3. Vector connecting the points:
   a = C - A = (2 - 1)i + (4 - 2)j + (5 - 3)k = 1i + 2j + 2k
4. Cross product b₁ × b₂:
   | i   j   k |
   | 2   3   4 | = i(15 - 16) - j(10 - 12) + k(8 - 9) = -i + 2j - k
   | 3   4   5 |
   Magnitude: |b₁ × b₂| = √((-1)² + 2² + (-1)²) = √(1 + 4 + 1) = √6
5. Dot product (b₁ × b₂) · a:
   (-1)(1) + (2)(2) + (-1)(2) = -1 + 4 - 2 = 1
6. Shortest distance d:
   d = |(b₁ × b₂) · (C - A)| / |b₁ × b₂| = 1 / √6.`,
    keyFormula: 'Shortest distance d = |(a₂ - a₁) · (b₁ × b₂)| / |b₁ × b₂|',
    topperTrick: 'Compute the 3×3 determinant directly: numerator is Det([a₂-a₁; b₁; b₂]) = Det([[1, 2, 2], [2, 3, 4], [3, 4, 5]]) = 1. Denominator is norm of cross product = √6.',
  },
  {
    id: 'phy-2023-01',
    exam: 'JEE Main',
    year: 2023,
    subject: 'Physics',
    topic: 'Modern Physics',
    subtopic: 'Photoelectric Effect',
    difficulty: 'Easy',
    question: 'When light of frequency 2ν₀ (where ν₀ is threshold frequency) is incident on a metal plate, the maximum velocity of emitted electrons is v₁. When the frequency is increased to 5ν₀, the maximum velocity is v₂. The ratio v₁ : v₂ is:',
    options: [
      '1 : 2',
      '1 : 4',
      '1 : √2',
      '1 : 3',
    ],
    correctOption: 0,
    solution: `1. Einstein\'s photoelectric equation:
   (1/2) m v² = hν - hν₀ = h(ν - ν₀)
2. Case 1 (ν = 2ν₀):
   (1/2) m v₁² = h(2ν₀ - ν₀) = hν₀  ⇒  v₁² ∝ 1
3. Case 2 (ν = 5ν₀):
   (1/2) m v₂² = h(5ν₀ - ν₀) = 4 hν₀ ⇒  v₂² ∝ 4
4. Ratio of velocities:
   v₁² / v₂² = 1 / 4  ⇒  v₁ / v₂ = √(1/4) = 1/2.`,
    keyFormula: 'KE_max = (1/2) m v_max² = h(ν - ν₀)',
    topperTrick: 'Instant ratio: v ∝ √(ν - ν₀). For 2ν₀ - ν₀ = 1 and 5ν₀ - ν₀ = 4, ratio is √1 : √4 = 1 : 2.',
  },
  {
    id: 'chem-2023-01',
    exam: 'JEE Main',
    year: 2023,
    subject: 'Chemistry',
    topic: 'Physical Chemistry',
    subtopic: 'Electrochemistry & Nernst Equation',
    difficulty: 'Moderate',
    question: 'For the cell Zn(s) | Zn²⁺(0.01 M) || Cu²⁺(1.0 M) | Cu(s), given E°(Zn²⁺/Zn) = -0.76 V and E°(Cu²⁺/Cu) = +0.34 V, what is the cell electromotive force E_cell at 298 K? (Take 2.303 RT/F = 0.059 V)',
    options: [
      '1.159 V',
      '1.100 V',
      '1.041 V',
      '0.800 V',
    ],
    correctOption: 0,
    solution: `1. Standard cell potential E°_cell:
   E°_cell = E°_cathode - E°_anode = +0.34 - (-0.76) = +1.10 V
2. Cell reaction:
   Zn(s) + Cu²⁺(aq) ⇌ Zn²⁺(aq) + Cu(s), n = 2 electrons transferred
3. Reaction quotient Q:
   Q = [Zn²⁺] / [Cu²⁺] = 0.01 / 1.0 = 10⁻²
4. Applying Nernst Equation at 298 K:
   E_cell = E°_cell - (0.059 / n) log₁₀ Q
   E_cell = 1.10 - (0.059 / 2) log₁₀(10⁻²)
   E_cell = 1.10 - (0.059 / 2) × (-2) = 1.10 + 0.059 = 1.159 V.`,
    keyFormula: 'E_cell = E°_cell - (0.0591 / n) · log Q',
    topperTrick: 'Notice [reactant] > [product] ([Cu²⁺] > [Zn²⁺]), so cell potential MUST be greater than standard 1.10 V! Only option A (1.159 V) is greater than 1.10 V!',
  },

  // ==========================================
  // --- 2022 & 2021 ---
  // ==========================================
  {
    id: 'phy-2022-01',
    exam: 'JEE Advanced',
    year: 2022,
    subject: 'Physics',
    topic: 'Thermodynamics',
    subtopic: 'Carnot & Polytropic Processes',
    difficulty: 'Challenging',
    question: 'An ideal monoatomic gas undergoes a thermodynamic process described by P · V² = constant. If the gas expands from volume V to 2V, the molar heat capacity C of the gas for this process is:',
    options: [
      'C = 0.5 R',
      'C = R',
      'C = 1.5 R',
      'C = 2 R',
    ],
    correctOption: 0,
    solution: `1. Polytropic process general form: P V^n = constant, here n = 2.
2. Molar heat capacity for any polytropic process:
   C = C_v + R / (1 - n)
3. For a monoatomic ideal gas, C_v = (3/2) R:
   C = (3/2) R + R / (1 - 2)
   C = (3/2) R - R = (1/2) R = 0.5 R.`,
    keyFormula: 'C = C_v + R / (1 - n) where P V^n = const; Monoatomic C_v = 3R/2',
    topperTrick: 'Never integrate work and ΔU separately in polytropic questions! Directly apply C = C_v + R/(1 - n).',
  },
  {
    id: 'chem-2022-01',
    exam: 'JEE Advanced',
    year: 2022,
    subject: 'Chemistry',
    topic: 'Chemical Bonding',
    subtopic: 'Molecular Orbital Theory',
    difficulty: 'Challenging',
    question: 'According to Molecular Orbital Theory, which of the following diatomic species is diamagnetic and possesses the highest bond order?',
    options: [
      'N₂',
      'O₂',
      'C₂²⁻',
      'NO⁺',
    ],
    correctOption: 0,
    solution: `1. N₂ has 14 electrons.
   Electronic configuration: σ1s² σ*1s² σ2s² σ*2s² (π2p_x² = π2p_y²) σ2p_z²
   Bond order = (10 - 4)/2 = 3. All paired electrons ⇒ Diamagnetic!
2. O₂ has 16 electrons, Bond order = 2. Has 2 unpaired electrons in π*2p (Paramagnetic).`,
    keyFormula: 'Bond Order = 1/2 (N_b - N_a); 14 e⁻ system gives maximum BO = 3.0',
    topperTrick: 'The 14-electron rule: Any 14-electron diatomic species (N₂, CO, NO⁺, CN⁻, C₂²⁻) has Bond Order = 3 and is diamagnetic!',
  },
  {
    id: 'math-2022-01',
    exam: 'JEE Advanced',
    year: 2022,
    subject: 'Mathematics',
    topic: 'Algebra',
    subtopic: 'Complex Numbers & Geometry',
    difficulty: 'Challenging',
    question: 'Let z be a complex number such that |z - 25i| ≤ 15. The complex number z in this region having the least value of arg(z) (principal argument in [0, 2π)) has argument:',
    options: [
      'cos⁻¹(3/5)',
      'sin⁻¹(3/5)',
      'tan⁻¹(4/3)',
      'π/2 - sin⁻¹(3/5)',
    ],
    correctOption: 0,
    solution: `1. The inequality |z - 25i| ≤ 15 represents a circle with center C(0, 25) on the positive imaginary axis and radius R = 15.
2. Tangent from origin to circle:
   - Hypotenuse OC = 25
   - Radius CT = 15
   - In right triangle OTC, sin θ = 15 / 25 = 3/5.
3. Since center lies along positive y-axis (π/2), the tangent line makes angle:
   arg(z) = π/2 - θ = π/2 - sin⁻¹(3/5) = cos⁻¹(3/5).`,
    keyFormula: '|z - z₀| = r represents a circle; Tangents from origin give extreme arguments.',
    topperTrick: 'Classic 3-4-5 right triangle geometry! Tangent angle with positive x-axis = cos⁻¹(3/5) directly.',
  },
  {
    id: 'phy-2021-01',
    exam: 'JEE Main',
    year: 2021,
    subject: 'Physics',
    topic: 'Oscillations & Waves',
    subtopic: 'Simple Harmonic Motion',
    difficulty: 'Moderate',
    question: 'A mass M attached to a horizontal spring executes SHM with amplitude A₁. When the mass M passes through its mean position, then a smaller mass m is placed over it and both of them move together with amplitude A₂. The ratio of (A₁ / A₂) is:',
    options: [
      '√((M + m) / M)',
      '√(M / (M + m))',
      '(M + m) / M',
      'M / (M + m)',
    ],
    correctOption: 0,
    solution: `1. At mean position, potential energy is zero and total energy is kinetic:
   Speed of mass M at mean position: v₁ = ω₁ A₁ = √(k/M) · A₁
2. When mass m is gently placed, momentum is conserved along horizontal:
   M v₁ = (M + m) v₂  ⇒  v₂ = [M / (M + m)] v₁
3. The new combined system has new maximum kinetic energy equal to new total energy:
   (1/2) (M + m) v₂² = (1/2) k A₂²
   ⇒ A₂ = v₂ √( (M + m)/k )
4. Substitute v₂:
   A₂ = [M / (M + m)] · [√(k/M) A₁] · √( (M + m)/k )
   A₂ = A₁ √(M / (M + m))
   ⇒ A₁ / A₂ = √((M + m) / M).`,
    keyFormula: 'Conservation of linear momentum at mean position: P = constant; E_total = (1/2)kA²',
    topperTrick: 'Energy method: Since kinetic energy drops by factor M/(M+m), amplitude squared must drop by factor M/(M+m), so A₁/A₂ = √((M+m)/M).',
  },

  // ==========================================
  // --- 2020 & 2019 ---
  // ==========================================
  {
    id: 'chem-2020-01',
    exam: 'JEE Main',
    year: 2020,
    subject: 'Chemistry',
    topic: 'Organic Chemistry',
    subtopic: 'Aromaticity & Carbocations',
    difficulty: 'Moderate',
    question: 'Which of the following carbocations is aromatic and exceptionally stable?',
    options: [
      'Cycloheptatrienyl cation (Tropylium ion)',
      'Cyclopentadienyl cation',
      'Cyclopropenyl anion',
      'Cycloheptatrienyl anion',
    ],
    correctOption: 0,
    solution: `1. Tropylium cation (C₇H₇⁺):
   - 7-membered planar ring with 3 conjugated double bonds and a positive charge.
   - Total π electrons = 3 × 2 = 6 π-electrons.
   - Satisfies Hückel's Rule (4n + 2 with n = 1). Completely delocalized and aromatic!
2. Cyclopentadienyl cation: 4 π-electrons (Anti-aromatic, highly unstable).
3. Cyclopropenyl anion: 4 π-electrons (Anti-aromatic).
4. Cycloheptatrienyl anion: 8 π-electrons (Non-aromatic / anti-aromatic).`,
    keyFormula: 'Hückel\'s Rule: Planar, cyclic, conjugated with (4n + 2) π-electrons = Aromatic',
    topperTrick: 'The Tropylium ion with 6 π-electrons is so stable that Tropylium bromide is a fully ionic salt soluble in water!',
  },
  {
    id: 'math-2020-01',
    exam: 'JEE Advanced',
    year: 2020,
    subject: 'Mathematics',
    topic: 'Probability',
    subtopic: 'Bayes Theorem & Conditional Probability',
    difficulty: 'Challenging',
    question: 'An urn contains 4 white and 6 black balls. A ball is drawn at random, its color is noted, and it is returned to the urn along with 2 additional balls of the same color. What is the probability that a second ball drawn is white?',
    options: [
      '2 / 5',
      '1 / 3',
      '1 / 2',
      '3 / 5',
    ],
    correctOption: 0,
    solution: `1. Case 1: First ball drawn is White.
   P(W₁) = 4 / 10 = 2/5.
   2 white balls added. New contents: 6 White, 6 Black (Total = 12).
   P(W₂ | W₁) = 6 / 12 = 1/2.
2. Case 2: First ball drawn is Black.
   P(B₁) = 6 / 10 = 3/5.
   2 black balls added. New contents: 4 White, 8 Black (Total = 12).
   P(W₂ | B₁) = 4 / 12 = 1/3.
3. Total Probability by Law of Total Probability:
   P(W₂) = P(W₁) · P(W₂ | W₁) + P(B₁) · P(W₂ | B₁)
   P(W₂) = (2/5) · (1/2) + (3/5) · (1/3) = 1/5 + 1/5 = 2/5.`,
    keyFormula: 'Pólya Urn Theorem: Probability of drawing a white ball at ANY stage remains equal to initial fraction W/(W+B)',
    topperTrick: 'Pólya\'s Urn Classic Theorem: Adding k balls of the drawn color leaves the probability of the next draw completely UNCHANGED: P = 4/10 = 2/5 instantly!',
  },
  {
    id: 'phy-2019-01',
    exam: 'JEE Main',
    year: 2019,
    subject: 'Physics',
    topic: 'Electrodynamics',
    subtopic: 'Magnetic Force on Current Carrying Wire',
    difficulty: 'Moderate',
    question: "A rigid square loop of side 'a' and mass m carrying current I is placed in a horizontal uniform magnetic field B = B₀ ĵ. The minimum current I required to flip the loop about one of its edges on the horizontal surface is:",
    options: [
      'm g / (2 B₀ a)',
      'm g / (B₀ a)',
      '2 m g / (B₀ a)',
      'm g / (4 B₀ a)',
    ],
    correctOption: 0,
    solution: `1. Magnetic dipole moment of the square loop: M = I · A = I · a² k̂ (pointing vertically upward).
2. Magnetic field is horizontal: B = B₀ ĵ.
3. Magnetic torque τ_mag = M × B:
   |τ_mag| = M · B₀ = I a² B₀
4. Gravitational restoring torque about the pivoting edge:
   Center of mass is at distance a/2 from the edge.
   τ_grav = m g · (a / 2)
5. To flip the loop, magnetic torque must balance gravitational torque:
   I a² B₀ ≥ m g (a / 2)
   ⇒ I_min = (m g) / (2 a B₀).`,
    keyFormula: 'τ_mag = M × B = I A B; Restoring torque τ_grav = m g (a/2)',
    topperTrick: 'Balance torques about the contact pivot edge: I a² B = m g (a/2) ⇒ I = mg / (2aB). Done in 15 seconds.',
  },

  // ==========================================
  // --- 2018 & 2017 ---
  // ==========================================
  {
    id: 'chem-2018-01',
    exam: 'JEE Advanced',
    year: 2018,
    subject: 'Chemistry',
    topic: 'Inorganic Chemistry',
    subtopic: 'p-Block Nitrogen & Phosphorus Oxyacids',
    difficulty: 'IIT Advanced Level',
    question: 'Among the following oxyacids of phosphorus, which one is a monobasic acid and acts as a strong reducing agent due to the presence of two P-H bonds?',
    options: [
      'Hypophosphorous acid (H₃PO₂)',
      'Orthophosphorous acid (H₃PO₃)',
      'Orthophosphoric acid (H₃PO₄)',
      'Pyrophosphoric acid (H₄P₂O₇)',
    ],
    correctOption: 0,
    solution: `1. Structure of H₃PO₂ (Phosphinic acid / Hypophosphorous acid):
   - Central P is sp³ hybridized.
   - Contains: One P=O bond, ONE P-OH bond, and TWO P-H bonds.
   - Since it has only one ionizable P-OH group, it is strictly MONOBASIC.
   - The presence of two direct P-H bonds makes it a powerful reducing agent (e.g. reduces AgNO₃ to metallic Ag).
2. H₃PO₃ has two P-OH and one P-H (dibasic).
3. H₃PO₄ has three P-OH and zero P-H (tribasic, non-reducing).`,
    keyFormula: 'Basicity of phosphorus oxyacid = number of P-OH bonds; Reducing power ∝ number of P-H bonds',
    topperTrick: 'Formula count: H₃PO_n has (n - 1) ionizable OH groups! For H₃PO₂, basicity = 2 - 1 = 1 (monobasic).',
  },
  {
    id: 'math-2018-01',
    exam: 'JEE Main',
    year: 2018,
    subject: 'Mathematics',
    topic: 'Coordinate Geometry',
    subtopic: 'Ellipse & Hyperbola Eccentricity',
    difficulty: 'Moderate',
    question: 'If the eccentricity of the standard hyperbola x²/a² - y²/b² = 1 is e₁, and the eccentricity of its conjugate hyperbola is e₂, then (1/e₁²) + (1/e₂²) is equal to:',
    options: [
      '1',
      '2',
      '0',
      '1/2',
    ],
    correctOption: 0,
    solution: `1. Standard hyperbola x²/a² - y²/b² = 1:
   e₁² = 1 + b²/a² = (a² + b²) / a²
   ⇒ 1 / e₁² = a² / (a² + b²)
2. Conjugate hyperbola -x²/a² + y²/b² = 1:
   e₂² = 1 + a²/b² = (b² + a²) / b²
   ⇒ 1 / e₂² = b² / (a² + b²)
3. Adding the reciprocals of squares:
   (1/e₁²) + (1/e₂²) = [a² / (a² + b²)] + [b² / (a² + b²)] = (a² + b²) / (a² + b²) = 1.`,
    keyFormula: 'Standard hyperbola & conjugate relation: 1/e₁² + 1/e₂² = 1',
    topperTrick: 'Classic universal identity! Valid for ANY hyperbola and its conjugate regardless of values of a and b.',
  },
  {
    id: 'phy-2017-01',
    exam: 'JEE Advanced',
    year: 2017,
    subject: 'Physics',
    topic: 'Mechanics',
    subtopic: 'Collision & Variable Mass',
    difficulty: 'Challenging',
    question: 'A block of mass M with a semicircular groove of radius R rests on a smooth horizontal surface. A small sphere of mass m is released from the top edge of the groove. When the sphere reaches the lowest point of the groove, the horizontal displacement of the block M is:',
    options: [
      'm R / (M + m)',
      'M R / (M + m)',
      'R',
      'm R / M',
    ],
    correctOption: 0,
    solution: `1. Since there are NO external forces in the horizontal x-direction:
   The Center of Mass (COM) of the system remains stationary horizontally: ΔX_com = 0.
2. Equation of horizontal center of mass:
   M ΔX_block + m Δx_sphere = 0
3. Relative to the block, the sphere moves horizontally by distance R to reach the lowest point:
   Δx_sphere = ΔX_block + R
4. Substituting into COM equation:
   M ΔX_block + m (ΔX_block + R) = 0
   (M + m) ΔX_block = - m R
   ⇒ Magnitude of displacement of block = (m R) / (M + m).`,
    keyFormula: 'ΔX_com = 0 ⇒ M · Δx₁ + m · Δx₂ = 0; Displacement of boat/wedge = (m · d) / (M + m)',
    topperTrick: 'Classic wedge-block relation: x = (mass moved · relative shift) / (total mass) = (m R) / (M + m).',
  },

  // ==========================================
  // --- 2016 & 2015 ---
  // ==========================================
  {
    id: 'chem-2016-01',
    exam: 'JEE Main',
    year: 2016,
    subject: 'Chemistry',
    topic: 'Thermodynamics',
    subtopic: 'Gibbs Free Energy & Spontaneity',
    difficulty: 'Moderate',
    question: 'For a certain reaction, ΔH° = -35.5 kJ/mol and ΔS° = -83.6 J/(mol·K). At what temperature does the reaction become non-spontaneous (assuming ΔH° and ΔS° remain constant with temperature)?',
    options: [
      'T > 425 K',
      'T < 425 K',
      'T > 298 K',
      'T < 298 K',
    ],
    correctOption: 0,
    solution: `1. Gibbs Free Energy: ΔG° = ΔH° - T ΔS°.
2. For spontaneity: ΔG° < 0.
   At equilibrium (boundary temperature T_eq):
   ΔG° = 0  ⇒  T_eq = ΔH° / ΔS°
3. Converting units:
   ΔH° = -35.5 × 10³ J/mol
   ΔS° = -83.6 J/(mol·K)
   T_eq = (-35.5 × 10³) / (-83.6) ≈ 424.6 K ≈ 425 K.
4. Since ΔH < 0 (favors spontaneity) and ΔS < 0 (opposes spontaneity):
   As T increases, the positive term (-T ΔS) dominates.
   Hence, the reaction is spontaneous at low temperatures (T < 425 K) and becomes NON-SPONTANEOUS when T > 425 K.`,
    keyFormula: 'ΔG = ΔH - TΔS; T_eq = ΔH/ΔS',
    topperTrick: 'Both ΔH and ΔS are negative ⇒ Spontaneous only at low T, non-spontaneous at high T > 425 K!',
  },
  {
    id: 'math-2016-01',
    exam: 'JEE Advanced',
    year: 2016,
    subject: 'Mathematics',
    topic: 'Calculus',
    subtopic: 'Limit of a Sum',
    difficulty: 'Challenging',
    question: 'The value of lim_(n→∞) ∑_(k=1)^n [ n / (n² + k²) ] is:',
    options: [
      'π / 4',
      'π / 2',
      'ln 2',
      '1',
    ],
    correctOption: 0,
    solution: `1. Rewrite the sum in standard Riemann integral form lim_(n→∞) (1/n) ∑ f(k/n):
   ∑_(k=1)^n [ n / (n² + k²) ] = (1/n) ∑_(k=1)^n [ 1 / (1 + (k/n)²) ]
2. Convert to definite integral:
   Let x = k/n, dx = 1/n.
   Lower limit: as k=1, x = 1/n → 0.
   Upper limit: as k=n, x = n/n → 1.
3. Evaluate integral:
   ∫₀¹ (1 / (1 + x²)) dx = [tan⁻¹(x)]₀¹ = tan⁻¹(1) - tan⁻¹(0) = π / 4.`,
    keyFormula: 'Riemann Sum: lim_(n→∞) (1/n) ∑ f(r/n) = ∫₀¹ f(x) dx',
    topperTrick: 'Standard prototype: 1/(1+x²) integrates to tan⁻¹(x). From 0 to 1, result is π/4.',
  },
  {
    id: 'phy-2015-01',
    exam: 'JEE Main',
    year: 2015,
    subject: 'Physics',
    topic: 'Ray Optics',
    subtopic: 'Prism & Minimum Deviation',
    difficulty: 'Moderate',
    question: 'The refracting angle of a prism is A and refractive index of the material of the prism is cot(A/2). The angle of minimum deviation δ_m is:',
    options: [
      '180° - 2A',
      '180° + 2A',
      '90° - A',
      '180° - A',
    ],
    correctOption: 0,
    solution: `1. Prism formula for refractive index μ:
   μ = sin( (A + δ_m) / 2 ) / sin( A / 2 )
2. Given μ = cot( A / 2 ) = cos( A / 2 ) / sin( A / 2 ):
   cos( A / 2 ) / sin( A / 2 ) = sin( (A + δ_m) / 2 ) / sin( A / 2 )
   ⇒ cos( A / 2 ) = sin( (A + δ_m) / 2 )
3. Using trigonometry cos(θ) = sin(90° - θ):
   sin( 90° - A/2 ) = sin( (A + δ_m) / 2 )
   ⇒ 90° - A/2 = (A + δ_m) / 2
   ⇒ 180° - A = A + δ_m
   ⇒ δ_m = 180° - 2A.`,
    keyFormula: 'μ = sin((A + δ_m)/2) / sin(A/2)',
    topperTrick: 'Substitute a special angle! If A = 60°, μ = cot(30°) = √3. For equilateral prism with μ = √3, δ_m = 2(60°) - 60° = 60° = 180° - 2(60°). Matches option A!',
  },

  // ==========================================
  // --- 2014 & 2013 ---
  // ==========================================
  {
    id: 'chem-2014-01',
    exam: 'JEE Advanced',
    year: 2014,
    subject: 'Chemistry',
    topic: 'Equilibrium',
    subtopic: 'Solubility Product & Common Ion Effect',
    difficulty: 'Challenging',
    question: 'The solubility product of Ag₂CrO₄ is 1.1 × 10⁻¹² at 298 K. The solubility (in mol/L) of Ag₂CrO₄ in a 0.1 M AgNO₃ aqueous solution is:',
    options: [
      '1.1 × 10⁻¹⁰ M',
      '1.1 × 10⁻¹¹ M',
      '6.5 × 10⁻⁵ M',
      '1.1 × 10⁻¹² M',
    ],
    correctOption: 0,
    solution: `1. Dissociation of Ag₂CrO₄(s):
   Ag₂CrO₄(s) ⇌ 2 Ag⁺(aq) + CrO₄²⁻(aq)
2. In presence of 0.1 M AgNO₃ (completely dissociated into Ag⁺ and NO₃⁻):
   [Ag⁺] = 0.1 + 2s ≈ 0.1 M  (since solubility s is tiny compared to 0.1 M)
   [CrO₄²⁻] = s
3. Solubility product expression:
   K_sp = [Ag⁺]² [CrO₄²⁻] = (0.1)² · s = 10⁻² · s
4. Solving for s:
   1.1 × 10⁻¹² = 10⁻² · s
   ⇒ s = (1.1 × 10⁻¹²) / 10⁻² = 1.1 × 10⁻¹⁰ mol/L.`,
    keyFormula: 'Common ion effect: K_sp = [Common Ion]ⁿ · s',
    topperTrick: 'Quick division: 1.1 × 10⁻¹² / (0.1)² = 1.1 × 10⁻¹² / 10⁻² = 1.1 × 10⁻¹⁰ M without any quadratic calculation!',
  },
  {
    id: 'math-2014-01',
    exam: 'JEE Main',
    year: 2014,
    subject: 'Mathematics',
    topic: 'Algebra',
    subtopic: 'Binomial Theorem Coefficient Sum',
    difficulty: 'Moderate',
    question: 'If the coefficients of x² and x³ in the expansion of (3 + α x)⁹ are equal, then the value of α is:',
    options: [
      '9 / 7',
      '7 / 9',
      '3 / 7',
      '7 / 3',
    ],
    correctOption: 0,
    solution: `1. General term T_(r+1) in (3 + α x)⁹:
   T_(r+1) = ⁹C_r · 3^(9-r) · (α x)^r = [ ⁹C_r · 3^(9-r) · α^r ] · x^r
2. Coefficient of x² (put r = 2):
   Coeff(x²) = ⁹C₂ · 3⁷ · α² = [(9 × 8)/2] · 3⁷ · α² = 36 · 3⁷ · α²
3. Coefficient of x³ (put r = 3):
   Coeff(x³) = ⁹C₃ · 3⁶ · α³ = [(9 × 8 × 7)/6] · 3⁶ · α³ = 84 · 3⁶ · α³
4. Setting coefficients equal:
   36 · 3⁷ · α² = 84 · 3⁶ · α³
   36 · 3 = 84 · α
   108 = 84 · α
   ⇒ α = 108 / 84 = 9 / 7.`,
    keyFormula: 'T_(r+1) = ⁿC_r a^(n-r) b^r; Ratio of consecutive terms = (n - r + 1)/r · (b/a)',
    topperTrick: 'Use the term ratio formula: T₃/T₂ = (9 - 2 + 1)/3 · (α/3) = (8/3)(α/3) = 8α/9. Equating gives α = 9/7.',
  },
  {
    id: 'phy-2013-01',
    exam: 'JEE Advanced',
    year: 2013,
    subject: 'Physics',
    topic: 'Fluid Mechanics',
    subtopic: 'Torricelli\'s Law & Bernoulli',
    difficulty: 'Challenging',
    question: 'A large open tank has two small holes in its vertical wall at depths h and 4h from the free surface of water. If the jets of water issuing from both holes hit the ground at the same horizontal distance x from the base, the total height H of the water column in the tank is:',
    options: [
      '5 h',
      '4 h',
      '6 h',
      '8 h',
    ],
    correctOption: 0,
    solution: `1. Horizontal efflux speed from depth y:
   v = √(2 g y)
2. Height of hole above ground: (H - y).
   Time of flight to reach the ground: t = √( 2(H - y) / g )
3. Horizontal range:
   x = v · t = √(2 g y) · √( 2(H - y) / g ) = 2 √( y (H - y) )
4. For both holes to have the same range x:
   y₁ (H - y₁) = y₂ (H - y₂)
5. Since y₁ ≠ y₂, they must be roots of quadratic y² - H y + (x/2)² = 0.
   Sum of roots: y₁ + y₂ = H.
6. Given y₁ = h and y₂ = 4h:
   H = y₁ + y₂ = h + 4h = 5h.`,
    keyFormula: 'Range x = 2 √(y (H - y)); Equal range condition y₁ + y₂ = H',
    topperTrick: 'Symmetry rule of Torricelli ranges: Holes at depths y₁ and y₂ have equal range if and only if y₁ + y₂ = H! Thus H = h + 4h = 5h in 3 seconds!',
  },

  // ==========================================
  // --- 2012 & 2011 ---
  // ==========================================
  {
    id: 'chem-2012-01',
    exam: 'JEE Main',
    year: 2012,
    subject: 'Chemistry',
    topic: 'Atomic Structure',
    subtopic: 'Bohr Model & Rydberg Formula',
    difficulty: 'Easy',
    question: 'The energy of an electron in the first Bohr orbit of H-atom is -13.6 eV. The possible energy value of an excited state for Li²⁺ ion is:',
    options: [
      '-30.6 eV',
      '-13.6 eV',
      '-3.4 eV',
      '-27.2 eV',
    ],
    correctOption: 0,
    solution: `1. Energy of an electron in nth orbit of hydrogen-like ion with atomic number Z:
   E_n = -13.6 · (Z² / n²) eV
2. For Li²⁺, Z = 3, so Z² = 9:
   E_n = -13.6 · (9 / n²) = -122.4 / n² eV
3. Check integer values of n:
   - For n = 1: E₁ = -122.4 eV (ground state)
   - For n = 2: E₂ = -122.4 / 4 = -30.6 eV
   - For n = 3: E₃ = -122.4 / 9 = -13.6 eV
4. Out of the given options, -30.6 eV corresponds to the first excited state (n = 2).`,
    keyFormula: 'E_n = -13.6 × (Z²/n²) eV',
    topperTrick: 'Multiply 13.6 × 9 / 4 = 13.6 × 2.25 = 30.6 eV. Direct match with option A!',
  },
  {
    id: 'math-2012-01',
    exam: 'JEE Advanced',
    year: 2012,
    subject: 'Mathematics',
    topic: 'Vectors & 3D Geometry',
    subtopic: 'Scalar Triple Product & Coplanarity',
    difficulty: 'Challenging',
    question: 'If the vectors a î + ĵ + k̂, î + b ĵ + k̂, and î + ĵ + c k̂ (where a, b, c ≠ 1) are coplanar, then the value of 1/(1 - a) + 1/(1 - b) + 1/(1 - c) is:',
    options: [
      '1',
      '0',
      '-1',
      '2',
    ],
    correctOption: 0,
    solution: `1. For coplanarity, determinant of the coefficients is zero:
   | a  1  1 |
   | 1  b  1 | = 0
   | 1  1  c |
2. Apply row operations R₂ → R₂ - R₁ and R₃ → R₃ - R₁:
   |   a       1       1   |
   | 1 - a   b - 1     0   | = 0
   | 1 - a     0     c - 1 |
3. Expanding along R₁:
   a(b - 1)(c - 1) - 1(1 - a)(c - 1) + 1(0 - (1 - a)(b - 1)) = 0
4. Divide throughout by (1 - a)(1 - b)(1 - c):
   a/(1 - a) + 1/(1 - b) + 1/(1 - c) = 0
5. Rewrite a/(1 - a) as [ (a - 1) + 1 ] / (1 - a) = -1 + 1/(1 - a):
   -1 + 1/(1 - a) + 1/(1 - b) + 1/(1 - c) = 0
   ⇒ 1/(1 - a) + 1/(1 - b) + 1/(1 - c) = 1.`,
    keyFormula: 'Coplanar vectors: [u, v, w] = 0; Standard result ∑ 1/(1 - a) = 1',
    topperTrick: 'Famous classic IIT-JEE problem! Set symmetric values a = b = c = -1/2 or test: the invariant sum is always 1.',
  },
  {
    id: 'phy-2011-01',
    exam: 'JEE Advanced',
    year: 2011,
    subject: 'Physics',
    topic: 'Electrodynamics',
    subtopic: 'RL Circuit & Time Constant',
    difficulty: 'Moderate',
    question: 'An inductor of inductance L = 400 mH and resistors R₁ = 2 Ω and R₂ = 2 Ω are connected to a battery of EMF E = 12 V through a switch. After the switch has been closed for a very long time, the current through the inductor is:',
    options: [
      '6 A',
      '3 A',
      '12 A',
      '0 A',
    ],
    correctOption: 0,
    solution: `1. In an RL circuit, at steady state (t → ∞):
   The rate of change of current di/dt = 0.
   Therefore, the inductor behaves as an ideal ZERO RESISTANCE wire (short circuit).
2. The inductor branch with R₁ is directly connected across the 12 V battery (assuming parallel setup).
   Current through inductor branch: I = E / R₁ = 12 V / 2 Ω = 6 A.`,
    keyFormula: 'Inductor at t = 0 behaves as open circuit; at t → ∞ behaves as short circuit (zero resistance wire)',
    topperTrick: 'Steady state rule: Replace inductor with plain wire, I = V / R = 12 / 2 = 6 A.',
  },

  // ==========================================
  // --- 2010 (FOUNDATIONAL IIT-JEE / AIEEE) ---
  // ==========================================
  {
    id: 'phy-2010-01',
    exam: 'JEE Advanced',
    year: 2010,
    subject: 'Physics',
    topic: 'Modern Physics',
    subtopic: 'Radioactive Decay & Half Life',
    difficulty: 'Moderate',
    question: 'A radioactive sample has a half-life of 20 minutes. The fraction of the original radioactive nuclei remaining undecayed after 1 hour (60 minutes) is:',
    options: [
      '1 / 8',
      '1 / 4',
      '1 / 16',
      '1 / 32',
    ],
    correctOption: 0,
    solution: `1. Half-life t_1/2 = 20 minutes.
2. Total elapsed time t = 60 minutes.
3. Number of half-lives elapsed:
   n = t / t_1/2 = 60 / 20 = 3 half-lives.
4. Remaining fraction:
   N / N₀ = (1/2)^n = (1/2)³ = 1 / 8.`,
    keyFormula: 'N(t) = N₀ (1/2)^(t / t_1/2)',
    topperTrick: '20 min -> 1/2, 40 min -> 1/4, 60 min -> 1/8. 5-second mental math!',
  },
  {
    id: 'chem-2010-01',
    exam: 'JEE Main',
    year: 2010,
    subject: 'Chemistry',
    topic: 'Coordination Compounds',
    subtopic: 'Werner\'s Theory & Precipitation',
    difficulty: 'Moderate',
    question: 'One mole of a complex compound Co(NH₃)₅Cl₃ on reaction with excess of AgNO₃ solution gives 2 moles of AgCl precipitate. The formulation of the complex is:',
    options: [
      '[Co(NH₃)₅Cl]Cl₂',
      '[Co(NH₃)₄Cl₂]Cl',
      '[Co(NH₃)₅Cl₂]Cl',
      '[Co(NH₃)₆]Cl₃',
    ],
    correctOption: 0,
    solution: `1. According to Werner\'s Theory:
   Only ions present outside the coordination sphere (ionizable secondary valence / counter ions) can precipitate with AgNO₃.
2. Since 2 moles of AgCl precipitate are formed per mole of complex:
   There must be exactly 2 chloride ions outside the brackets as counter ions.
3. Total formula is Co(NH₃)₅Cl₃:
   Keeping 2 chlorides outside leaves [Co(NH₃)₅Cl] inside the coordination sphere.
   Therefore, the complex is [Co(NH₃)₅Cl]Cl₂.`,
    keyFormula: 'Precipitated AgCl moles = number of ionizable Cl⁻ outside the coordination sphere',
    topperTrick: '2 moles of AgCl precipitate means 2 Cl outside the brackets. Immediately select [Co(NH₃)₅Cl]Cl₂!',
  },
  {
    id: 'math-2010-01',
    exam: 'JEE Main',
    year: 2010,
    subject: 'Mathematics',
    topic: 'Calculus',
    subtopic: 'Continuity & Differentiability',
    difficulty: 'Moderate',
    question: 'The function f(x) = |x - 1| + |x - 2| is:',
    options: [
      'Continuous everywhere, but not differentiable at x = 1 and x = 2',
      'Differentiable everywhere',
      'Discontinuous at x = 1 and x = 2',
      'Not differentiable at x = 1 only',
    ],
    correctOption: 0,
    solution: `1. The function f(x) is the sum of two continuous modulus functions:
   Therefore, f(x) is continuous for all real x ∈ ℝ.
2. Express in piecewise form:
   - For x < 1: f(x) = -(x - 1) - (x - 2) = -2x + 3 (derivative = -2)
   - For 1 ≤ x < 2: f(x) = (x - 1) - (x - 2) = 1 (derivative = 0)
   - For x ≥ 2: f(x) = (x - 1) + (x - 2) = 2x - 3 (derivative = +2)
3. At x = 1: LHD = -2, RHD = 0 (LHD ≠ RHD ⇒ non-differentiable sharp corner).
4. At x = 2: LHD = 0, RHD = +2 (LHD ≠ RHD ⇒ non-differentiable sharp corner).
5. Hence, f(x) is continuous everywhere but not differentiable at x = 1 and x = 2.`,
    keyFormula: '|x - c| has a sharp corner (vertex) at x = c and is not differentiable there',
    topperTrick: 'Modulus functions |x - a| have sharp "V-shaped" vertices at their roots, making them non-differentiable at each root!',
  },
];

export const mockQuestions: Question[] = rawMockQuestions.map((q, idx) =>
  balanceQuestion(q, BALANCED_ANSWER_CYCLE[idx % BALANCED_ANSWER_CYCLE.length])
);
