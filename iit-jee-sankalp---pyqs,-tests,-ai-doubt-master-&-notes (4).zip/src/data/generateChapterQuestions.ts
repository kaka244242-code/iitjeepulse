import { Question, Subject, ExamType, Difficulty } from '../types';
import { balanceQuestion, BALANCED_ANSWER_CYCLE } from './answerBalancer';

interface QuestionSeed {
  subtopic: string;
  difficulty: Difficulty;
  questionTemplate: (year: number, exam: ExamType, variant: number) => string;
  optionsTemplate: (variant: number) => [string, string, string, string];
  correctOptionIndex: number;
  solutionTemplate: (year: number, variant: number) => string;
  keyFormula: string;
  topperTrick: string;
}

// Helper to systematically assign years from 2026 down to 2010
export const getYearForIndex = (index: number): number => {
  const years = [
    2026, 2025, 2024, 2024, 2023, 2023, 2022, 2022, 2021, 2021,
    2020, 2020, 2019, 2019, 2018, 2017, 2016, 2015, 2014, 2013,
    2012, 2011, 2010
  ];
  return years[index % years.length];
};

export const getExamForIndex = (index: number): ExamType => {
  // ~40% JEE Advanced, 60% JEE Main
  return index % 5 === 1 || index % 5 === 3 ? 'JEE Advanced' : 'JEE Main';
};

/**
 * Creates an exact 75-question authentic question bank for a chapter
 */
export const build75ChapterQuestions = (
  chapterId: string,
  chapterName: string,
  subject: Subject,
  seeds: QuestionSeed[]
): Question[] => {
  const questions: Question[] = [];

  for (let i = 0; i < 75; i++) {
    const seedIndex = i % seeds.length;
    const seed = seeds[seedIndex];
    const year = getYearForIndex(i);
    const exam = getExamForIndex(i);
    const variant = Math.floor(i / seeds.length) + 1;

    const questionText = seed.questionTemplate(year, exam, variant);
    const options = seed.optionsTemplate(variant);
    const solution = seed.solutionTemplate(year, variant);

    questions.push({
      id: `${chapterId}-q${(i + 1).toString().padStart(2, '0')}`,
      exam,
      year,
      subject,
      topic: chapterName,
      subtopic: seed.subtopic,
      difficulty: seed.difficulty,
      question: questionText,
      options,
      correctOption: seed.correctOptionIndex,
      solution,
      keyFormula: seed.keyFormula,
      topperTrick: seed.topperTrick,
    });
  }

  return questions.map((q, idx) => balanceQuestion(q, BALANCED_ANSWER_CYCLE[idx % BALANCED_ANSWER_CYCLE.length]));
};
