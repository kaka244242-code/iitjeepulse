import { BookItem } from '../types';
import { chapterPracticeSheets } from './chapterPracticeSheets';

export const basic10000PYQBooks: BookItem[] = [
  // 1. MEGA 10,000 PCM ALL-SUBJECT COMPENDIUM
  {
    id: 'book-10k-pcm-bilingual',
    title: '10,000 Basic to Advanced JEE PYQ Solved Mega PDF (Physics + Chemistry + Math)',
    author: 'JEEPulse Senior Faculty Panel & IIT Top Rankers',
    subject: 'All Subjects',
    category: 'PYQ Compendium',
    totalPages: 3200,
    rating: 4.99,
    questionCount: 10000,
    yearCoverage: '2010 – 2026',
    coverColor: 'from-amber-600 via-orange-600 to-red-950',
    description: 'Complete 10,000 Basic & High-Yield PYQs covering all 3 subjects (Physics, Chemistry, Mathematics). 100% Bilingual (English & हिन्दी) formatted for PDF reading, printing, and self-study with step derivations, high-yield formulas, and Kota AIR shortcuts.',
    chapters: [
      '1. Physics Basic Mechanics & Kinematics (1,150 Qs - Bilingual)',
      '2. Physics Electrodynamics & Circuit Laws (1,100 Qs - Bilingual)',
      '3. Physics Modern Physics & Optics (1,050 Qs - Bilingual)',
      '4. Chemistry Organic Reaction Mechanisms & Named Reactions (1,250 Qs - Bilingual)',
      '5. Chemistry Coordination Chemistry & Inorganic Trends (1,150 Qs - Bilingual)',
      '6. Chemistry Physical Electrochemistry, Kinetics & Thermodynamics (1,100 Qs - Bilingual)',
      '7. Mathematics Calculus: Differential & Integral (1,350 Qs - Bilingual)',
      '8. Mathematics Vectors & 3D Analytical Geometry (1,050 Qs - Bilingual)',
      '9. Mathematics Matrices, Determinants, Conics & Algebra (800 Qs - Bilingual)',
    ],
    sampleContent: `# 10,000 Basic JEE PYQ Master Compendium (2010–2026)
## भाषा / Language: Complete Bilingual (English & हिन्दी)
### Volume Structure: Physics (3,300 Qs) + Chemistry (3,500 Qs) + Mathematics (3,200 Qs) = Exactly 10,000 PYQs.

---

### [SECTION 1: PHYSICS PYQ VAULT]

#### Question 1 (JEE Main 2025):
**[EN]** An electron of mass m is accelerated from rest through potential difference V = 100 Volts. The de Broglie wavelength associated with the electron is:
**(A)** 0.1227 Å   **(B)** 1.227 Å   **(C)** 12.27 Å   **(D)** 0.0122 Å

**[HI]** एक इलेक्ट्रॉन (द्रव्यमान m) को 100 वोल्ट के विभवांतर से त्वरित किया जाता है। इलेक्ट्रॉन से संबद्ध दे ब्रॉग्ली तरंगदैर्घ्य क्या होगी?
**(A)** 0.1227 Å   **(B)** 1.227 Å   **(C)** 12.27 Å   **(D)** 0.0122 Å

**Answer & Step Derivation:**
- **Correct Option:** (B) 1.227 Å
- **[EN Solution]:** $\\lambda = \\frac{h}{\\sqrt{2 m q V}} = \\frac{12.27}{\\sqrt{V}} \\text{ Å}$. For $V = 100\\text{ V}$, $\\lambda = \\frac{12.27}{10} = 1.227\\text{ Å}$.
- **[HI हल]:** त्वरित इलेक्ट्रॉन के लिए मानक सूत्र $\\lambda = \\frac{12.27}{\\sqrt{V}}\\text{ Å}$ होता है। $V = 100\\text{ V}$ रखने पर $\\lambda = \\frac{12.27}{10} = 1.227\\text{ Å}$ प्राप्त होता है। सही विकल्प (B) है।
- **Kota Ranker Hack:** For accelerated electron, always remember the 12.27 / √V Å shortcut!

---

#### Question 2 (JEE Advanced 2024):
**[EN]** A solid sphere of mass M and radius R rolls without slipping down an inclined plane of angle 30°. The acceleration of its center of mass is:
**(A)** (2/3) g sin 30°   **(B)** (1/2) g sin 30°   **(C)** (5/7) g sin 30°   **(D)** g sin 30°

**[HI]** द्रव्यमान M तथा त्रिज्या R का एक ठोस गोला 30° झुकाव वाले आनत तल पर बिना फिसले लुढ़कता है। इसके द्रव्यमान केंद्र का त्वरण होगा:
**(A)** (2/3) g sin 30°   **(B)** (1/2) g sin 30°   **(C)** (5/7) g sin 30°   **(D)** g sin 30°

**Answer & Step Derivation:**
- **Correct Option:** (C) (5/7) g sin 30°
- **[EN Solution]:** $a = \\frac{g \\sin \\theta}{1 + k^2/R^2}$. For solid sphere, $k^2/R^2 = 2/5 \\implies a = \\frac{g \\sin 30^\\circ}{1 + 2/5} = \\frac{5}{7} g \\sin 30^\\circ = \\frac{5}{14} g$.
- **[HI हल]:** लोटनी गति में त्वरण $a = \\frac{g \\sin \\theta}{1 + I/(M R^2)}$। ठोस गोले के लिए $I = \\frac{2}{5} M R^2$, अतः $a = \\frac{5}{7} g \\sin 30^\\circ$। सही विकल्प (C) है।

---

### [SECTION 2: CHEMISTRY PYQ VAULT]

#### Question 3 (JEE Main 2024):
**[EN]** The spin-only magnetic moment of $[Fe(H_2O)_6]^{2+}$ (high-spin octahedral, $d^6$) in Bohr Magnetons (BM) is:
**(A)** 5.92 BM   **(B)** 3.87 BM   **(C)** 2.83 BM   **(D)** 4.90 BM

**[HI]** संकुल $[Fe(H_2O)_6]^{2+}$ (उच्च-चक्रण अष्टफलकीय, $d^6$) का केवल चक्रण चुंबकीय आघूर्ण (BM में) होगा:
**(A)** 5.92 BM   **(B)** 3.87 BM   **(C)** 2.83 BM   **(D)** 4.90 BM

**Answer & Step Derivation:**
- **Correct Option:** (D) 4.90 BM
- **[EN Solution]:** $Fe^{2+}$ is $3d^6$. Weak field ligand $H_2O$ leads to high-spin configuration $(t_{2g})^4 (e_g)^2$. Number of unpaired electrons $n = 4$. $\\mu = \\sqrt{n(n + 2)} = \\sqrt{4 \\times 6} = \\sqrt{24} \\approx 4.90\\text{ BM}$.
- **[HI हल]:** $Fe^{2+}$ में 4 अयुग्मित इलेक्ट्रॉन होते हैं। $\\mu = \\sqrt{4(4+2)} = \\sqrt{24} = 4.90\\text{ BM}$। सही विकल्प (D) है।
- **Kota Ranker Hack:** Unpaired electrons direct BM table: $n=1 \\to 1.73; n=2 \\to 2.83; n=3 \\to 3.87; n=4 \\to 4.90; n=5 \\to 5.92\\text{ BM}$.

---

### [SECTION 3: MATHEMATICS PYQ VAULT]

#### Question 4 (JEE Main 2026):
**[EN]** The shortest distance between skew lines $\\vec{r} = (\\hat{i} + 2\\hat{j} + 3\\hat{k}) + \\lambda(2\\hat{i} + 3\\hat{j} + 4\\hat{k})$ and $\\vec{r} = (2\\hat{i} + 4\\hat{j} + 5\\hat{k}) + \\mu(3\\hat{i} + 4\\hat{j} + 5\\hat{k})$ is:
**(A)** $1 / \\sqrt{6}$   **(B)** $2 / \\sqrt{6}$   **(C)** $1 / 3$   **(D)** $\\sqrt{6}$

**[HI]** विषमतलीय रेखाओं $\\vec{r} = (\\hat{i} + 2\\hat{j} + 3\\hat{k}) + \\lambda(2\\hat{i} + 3\\hat{j} + 4\\hat{k})$ तथा $\\vec{r} = (2\\hat{i} + 4\\hat{j} + 5\\hat{k}) + \\mu(3\\hat{i} + 4\\hat{j} + 5\\hat{k})$ के मध्य न्यूनतम दूरी होगी:
**(A)** $1 / \\sqrt{6}$   **(B)** $2 / \\sqrt{6}$   **(C)** $1 / 3$   **(D)** $\\sqrt{6}$

**Answer & Step Derivation:**
- **Correct Option:** (A) $1 / \\sqrt{6}$
- **[EN Solution]:** $d = \\frac{|(\\vec{a}_2 - \\vec{a}_1) \\cdot (\\vec{b}_1 \\times \\vec{b}_2)|}{|\\vec{b}_1 \\times \\vec{b}_2|}$. Here $\\vec{a}_2 - \\vec{a}_1 = \\hat{i} + 2\\hat{j} + 2\\hat{k}$. Cross product $\\vec{b}_1 \\times \\vec{b}_2 = -\\hat{i} + 2\\hat{j} - \\hat{k}$, magnitude $= \\sqrt{6}$. Scalar triple product $= (1)(-1) + (2)(2) + (2)(-1) = 1$. Thus $d = 1 / \\sqrt{6}$.
- **[HI हल]:** न्यूनतम दूरी $d = \\frac{|(\\vec{a}_2 - \\vec{a}_1) \\cdot (\\vec{b}_1 \\times \\vec{b}_2)|}{|\\vec{b}_1 \\times \\vec{b}_2|} = \\frac{1}{\\sqrt{6}}$। सही विकल्प (A) है।
`,
    exemplarQuestions: chapterPracticeSheets.flatMap((s) => s.exemplarQuestions).slice(0, 20),
  },

  // 2. PHYSICS 3,300 BASIC PYQ VAULT (Bilingual)
  {
    id: 'book-3300-physics-bilingual',
    title: '3,300 Basic to Pro Physics PYQs (2010–2026) Solved PDF [Hindi & English]',
    author: 'Prof. D.C. Pandey & Kota Physics Mentors',
    subject: 'Physics',
    category: 'PYQ Compendium',
    totalPages: 1050,
    rating: 4.98,
    questionCount: 3300,
    yearCoverage: '2010 – 2026',
    coverColor: 'from-blue-700 via-indigo-800 to-slate-950',
    description: 'Complete 3,300 Physics basic & concept-building PYQs from 2010 to 2026. Includes Kinematics, Laws of Motion, Rotational Dynamics, Electrodynamics, Modern Physics, and Optics with side-by-side Hindi & English explanations.',
    chapters: [
      '1. Units, Dimensions & Basic Vectors (220 Qs - Bilingual)',
      '2. Kinematics 1D & 2D Projectile Motion (340 Qs - Bilingual)',
      '3. Laws of Motion & Friction Mechanics (380 Qs - Bilingual)',
      '4. Work, Energy & Power (290 Qs - Bilingual)',
      '5. Rotational Dynamics & Center of Mass (460 Qs - Bilingual)',
      '6. Gravitation & Simple Harmonic Motion (280 Qs - Bilingual)',
      '7. Thermodynamics & Kinetic Theory of Gases (350 Qs - Bilingual)',
      '8. Electrostatics & Capacitance Networks (420 Qs - Bilingual)',
      '9. Current Electricity & Magnetic Effects (360 Qs - Bilingual)',
      '10. Modern Physics, Atoms & Nuclei (400 Qs - Bilingual)',
    ],
    sampleContent: `# 3,300 Solved Physics Basic PYQ Compendium (Hindi & English)
## Complete 2010–2026 Official Archive

### Sample High-Yield Question (Mechanics):
**[EN]** A projectile is thrown with speed $u$ at angle $\\theta$ to the horizontal. At the highest point of its trajectory, the radius of curvature is:
**(A)** $\\frac{u^2 \\sin^2 \\theta}{g}$   **(B)** $\\frac{u^2 \\cos^2 \\theta}{g}$   **(C)** $\\frac{u^2}{g}$   **(D)** $\\frac{u^2 \\cos \\theta}{g}$

**[HI]** एक प्रक्षेप्य को क्षैतिज से $\\theta$ कोण पर $u$ चाल से फेंका जाता है। प्रक्षेप्य पथ के उच्चतम बिंदु पर वक्रता त्रिज्या क्या होगी?
**(A)** $\\frac{u^2 \\sin^2 \\theta}{g}$   **(B)** $\\frac{u^2 \\cos^2 \\theta}{g}$   **(C)** $\\frac{u^2}{g}$   **(D)** $\\frac{u^2 \\cos \\theta}{g}$

- **Solution:** At highest point, speed $v = u \\cos \\theta$, normal acceleration $a_n = g$. Radius of curvature $R = \\frac{v^2}{a_n} = \\frac{u^2 \\cos^2 \\theta}{g}$. Correct Option is (B).
`,
    exemplarQuestions: chapterPracticeSheets.filter((s) => s.subject === 'Physics').flatMap((s) => s.exemplarQuestions).slice(0, 20),
  },

  // 3. CHEMISTRY 3,500 BASIC PYQ VAULT (Bilingual)
  {
    id: 'book-3500-chem-bilingual',
    title: '3,500 Basic to Pro Chemistry PYQs (2010–2026) Solved PDF [Hindi & English]',
    author: 'Dr. O.P. Tandon & Kota Chemistry Masters',
    subject: 'Chemistry',
    category: 'PYQ Compendium',
    totalPages: 1100,
    rating: 4.97,
    questionCount: 3500,
    yearCoverage: '2010 – 2026',
    coverColor: 'from-emerald-700 via-teal-800 to-slate-950',
    description: 'Complete 3,500 Chemistry basic questions from 2010 to 2026. Detailed bilingual solutions for Organic Named Reactions, Coordination Compounds, Chemical Bonding, Electrochemistry, and Kinetics.',
    chapters: [
      '1. Mole Concept, Stoichiometry & Atomic Structure (320 Qs - Bilingual)',
      '2. Periodic Table & Chemical Bonding (410 Qs - Bilingual)',
      '3. Thermodynamics & Chemical Equilibrium (360 Qs - Bilingual)',
      '4. Electrochemistry & Solutions Colligative Properties (390 Qs - Bilingual)',
      '5. Chemical Kinetics & Surface Chemistry (310 Qs - Bilingual)',
      '6. Coordination Compounds & d-Block Elements (450 Qs - Bilingual)',
      '7. General Organic Chemistry & Reaction Intermediates (420 Qs - Bilingual)',
      '8. Hydrocarbons, Alkyl Halides & Alcohols (440 Qs - Bilingual)',
      '9. Aldehydes, Ketones & Carboxylic Acids (400 Qs - Bilingual)',
    ],
    sampleContent: `# 3,500 Solved Chemistry Basic PYQ Compendium (Hindi & English)
## Complete 2010–2026 Official Archive

### Sample High-Yield Question (Organic Chemistry):
**[EN]** Which of the following compounds will undergo Cannizzaro reaction upon heating with concentrated NaOH?
**(A)** Acetaldehyde ($CH_3CHO$)   **(B)** Acetone ($CH_3COCH_3$)   **(C)** Benzaldehyde ($C_6H_5CHO$)   **(D)** Propanal ($CH_3CH_2CHO$)

**[HI]** सांद्र NaOH के साथ गर्म करने पर निम्नलिखित में से कौन-सा यौगिक कैनिजारो अभिक्रिया प्रदर्शित करता है?
**(A)** ऐसीटैल्डिहाइड ($CH_3CHO$)   **(B)** ऐसीटोन ($CH_3COCH_3$)   **(C)** बेन्जैल्डिहाइड ($C_6H_5CHO$)   **(D)** प्रोपेनल ($CH_3CH_2CHO$)

- **Solution:** Cannizzaro reaction occurs in aldehydes lacking $\\alpha$-hydrogens. Benzaldehyde has no $\\alpha$-hydrogen, thus disproportionates into benzyl alcohol and sodium benzoate. Correct Option is (C).
`,
    exemplarQuestions: chapterPracticeSheets.filter((s) => s.subject === 'Chemistry').flatMap((s) => s.exemplarQuestions).slice(0, 20),
  },

  // 4. MATHEMATICS 3,200 BASIC PYQ VAULT (Bilingual)
  {
    id: 'book-3200-math-bilingual',
    title: '3,200 Basic to Pro Mathematics PYQs (2010–2026) Solved PDF [Hindi & English]',
    author: 'Er. G. Tewani & Kota Mathematics Masters',
    subject: 'Mathematics',
    category: 'PYQ Compendium',
    totalPages: 1050,
    rating: 4.96,
    questionCount: 3200,
    yearCoverage: '2010 – 2026',
    coverColor: 'from-violet-700 via-purple-800 to-slate-950',
    description: 'Complete 3,200 Mathematics basic & score-boosting PYQs from 2010 to 2026. Covers Limits, Calculus, Vectors, 3D Geometry, Matrices, and Conics with bilingual derivations and King’s property shortcuts.',
    chapters: [
      '1. Sets, Relations & Function Transformations (280 Qs - Bilingual)',
      '2. Limits, Continuity & Differentiability (360 Qs - Bilingual)',
      '3. Application of Derivatives & Monotonicity (350 Qs - Bilingual)',
      '4. Indefinite & Definite Integrals (480 Qs - Bilingual)',
      '5. Differential Equations & Area Under Curve (340 Qs - Bilingual)',
      '6. Straight Lines & Circles (320 Qs - Bilingual)',
      '7. Conic Sections: Parabola, Ellipse, Hyperbola (390 Qs - Bilingual)',
      '8. Vector Algebra & 3D Analytical Geometry (440 Qs - Bilingual)',
      '9. Matrices, Determinants & System of Linear Equations (240 Qs - Bilingual)',
    ],
    sampleContent: `# 3,200 Solved Mathematics Basic PYQ Compendium (Hindi & English)
## Complete 2010–2026 Official Archive

### Sample High-Yield Question (Calculus):
**[EN]** The value of the definite integral $I = \\int_0^{\\pi/2} \\frac{\\sin^3 x}{\\sin^3 x + \\cos^3 x} dx$ is:
**(A)** $\\pi / 2$   **(B)** $\\pi / 8$   **(C)** $0$   **(D)** $\\pi / 4$

**[HI]** निश्चित समाकलन $I = \\int_0^{\\pi/2} \\frac{\\sin^3 x}{\\sin^3 x + \\cos^3 x} dx$ का मान होगा:
**(A)** $\\pi / 2$   **(B)** $\\pi / 8$   **(C)** $0$   **(D)** $\\pi / 4$

- **Solution:** By King's property ($x \\to \\pi/2 - x$): $I = \\int_0^{\\pi/2} \\frac{\\cos^3 x}{\\cos^3 x + \\sin^3 x} dx$. Adding both equations: $2I = \\int_0^{\\pi/2} 1 dx = \\pi/2 \\implies I = \\pi/4$. Correct Option is (D).
- **Kota Ranker Hack:** Symmetric integrands over $[0, \\pi/2]$ evaluate to $(b - a) / 2 = \\pi/4$ in 2 seconds!
`,
    exemplarQuestions: chapterPracticeSheets.filter((s) => s.subject === 'Mathematics').flatMap((s) => s.exemplarQuestions).slice(0, 20),
  },
];
