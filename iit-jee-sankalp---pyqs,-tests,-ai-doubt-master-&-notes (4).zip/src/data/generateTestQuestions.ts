import { Question, Subject, ExamType, Difficulty, MockTest } from '../types';
import { balanceQuestion, BALANCED_ANSWER_CYCLE } from './answerBalancer';
import { 
  rotationalMechanicsSeeds, 
  electrodynamicsSeeds, 
  modernPhysicsSeeds, 
  thermoFluidsOpticsSeeds,
  coordinationBondingSeeds, 
  organicChemistrySeeds, 
  physicalChemistrySeeds,
  calculusSeeds, 
  vectors3DGeometrySeeds, 
  algebraMatricesSeeds,
  ChapterSeedDef 
} from './chapterSeeds';

export interface TestCatalogItem {
  id: string;
  testNumber: number;
  title: string;
  titleHindi: string;
  subject: Subject | 'All Subjects';
  chapter: string;
  chapterHindi: string;
  examType: ExamType;
  durationMinutes: number;
  totalQuestions: number;
  totalMarks: number;
  difficulty: 'Standard JEE Main' | 'High Rank Predictor' | 'JEE Advanced Paper-1' | 'Hard / IIT Advanced Level';
  category: 'high_yield_ranker' | 'chapter' | 'hard_advanced' | 'grand_mock' | 'year_wise' | 'tricky_traps';
  weightageTag: string;
  weightageTagHindi: string;
  highYieldTips: string;
  highYieldTipsHindi: string;
  description: string;
  descriptionHindi: string;
  isChapterTest: boolean;
  yearRange: string;
}

// Maps topics to corresponding question seeds
export const getSeedsForTopic = (chapter: string, subject: string): ChapterSeedDef[] => {
  const c = chapter.toLowerCase();
  if (c.includes('rotat') || c.includes('mechanic') || c.includes('motion') || c.includes('kinematic') || c.includes('work') || c.includes('gravitat')) {
    return rotationalMechanicsSeeds;
  }
  if (c.includes('electro') || c.includes('capacit') || c.includes('current') || c.includes('magnet') || c.includes('emi') || c.includes('circuit')) {
    return electrodynamicsSeeds;
  }
  if (c.includes('modern') || c.includes('nuclear') || c.includes('photoelectr') || c.includes('atom') || c.includes('semiconductor') || c.includes('dual')) {
    return modernPhysicsSeeds;
  }
  if (c.includes('thermo') || c.includes('heat') || c.includes('fluid') || c.includes('optic') || c.includes('wave') || c.includes('shm')) {
    return thermoFluidsOpticsSeeds;
  }
  if (c.includes('coordinat') || c.includes('bond') || c.includes('inorganic') || c.includes('p-block') || c.includes('d-block') || c.includes('periodic')) {
    return coordinationBondingSeeds;
  }
  if (c.includes('organic') || c.includes('reaction') || c.includes('aldehyde') || c.includes('ketone') || c.includes('amine') || c.includes('biomolecule') || c.includes('hydrocarbon')) {
    return organicChemistrySeeds;
  }
  if (c.includes('physical') || c.includes('kinetics') || c.includes('equilibrium') || c.includes('solution') || c.includes('electrochem') || c.includes('mole')) {
    return physicalChemistrySeeds;
  }
  if (c.includes('calculus') || c.includes('integrat') || c.includes('different') || c.includes('limit') || c.includes('area') || c.includes('derivative')) {
    return calculusSeeds;
  }
  if (c.includes('vector') || c.includes('3d') || c.includes('matri') || c.includes('determinant') || c.includes('geometry')) {
    return vectors3DGeometrySeeds;
  }
  if (c.includes('conic') || c.includes('parabola') || c.includes('ellipse') || c.includes('hyperbola') || c.includes('algebra') || c.includes('complex') || c.includes('probab') || c.includes('series')) {
    return algebraMatricesSeeds;
  }

  // Fallback by subject
  if (subject === 'Physics') return modernPhysicsSeeds;
  if (subject === 'Chemistry') return coordinationBondingSeeds;
  return vectors3DGeometrySeeds;
};

// Systematic year assignment (2026 down to 2010)
const years2010to2026 = [
  2026, 2025, 2024, 2024, 2023, 2023, 2022, 2022, 2021, 2021,
  2020, 2020, 2019, 2019, 2018, 2017, 2016, 2015, 2014, 2013,
  2012, 2011, 2010
];

/**
 * Creates rich Hindi translations for questions, preserving formulas and structure
 */
export const toHindiQuestion = (enText: string, topic: string, year: number, exam: string): string => {
  let hi = enText;

  // Header tag
  hi = hi.replace(/\[(JEE Main|JEE Advanced)\s+(\d{4})\]/, `[${exam === 'JEE Advanced' ? 'जेईई एडवांस्ड' : 'जेईई मेन'} ${year}]`);

  // Common physics/math/chem phrases to Hindi
  hi = hi.replace(/A solid cylinder of mass M and radius R rolls without slipping down an inclined plane of inclination θ = (.*?)°\. The magnitude of the acceleration of its center of mass is:/g, 
    'द्रव्यमान M तथा त्रिज्या R का एक ठोस बेलन आनत कोण θ = $1° वाले आनत तल पर बिना फिसले नीचे लुढ़कता है। इसके द्रव्यमान केंद्र के त्वरण का परिमाण होगा:');

  hi = hi.replace(/A uniform rod of mass (.*?)M and length L lies on a frictionless horizontal plane, pivoted at one end O\./g,
    'द्रव्यमान $1M तथा लम्बाई L की एकसमान छड़ एक घर्षणरहित क्षैतिज तल पर स्थित है, जो एक सिरे O पर कीलकित (pivoted) है।');

  hi = hi.replace(/The angular velocity of the system just after collision is:/g,
    'टक्कर के ठीक पश्चात निकाय का कोणीय वेग है:');

  hi = hi.replace(/An electron of mass m and a photon have the same de Broglie wavelength λ\./g,
    'द्रव्यमान m के एक इलेक्ट्रॉन तथा एक फोटॉन की दे ब्रॉग्ली तरंगदैर्घ्य λ समान है।');

  hi = hi.replace(/then the ratio E \/ E_ph is \(where c is speed of light\):/g,
    'तो अनुपात E / E_ph का मान होगा (जहाँ c प्रकाश की चाल है):');

  hi = hi.replace(/The half-life of a radioactive nucleus X is (.*?) days\./g,
    'एक रेडियोएक्टिव नाभिक X की अर्ध-आयु $1 दिन है।');

  hi = hi.replace(/The activity of the sample after (.*?) days will be:/g,
    '$1 दिनों के पश्चात नमूने की सक्रियता होगी:');

  hi = hi.replace(/Which of the following complex ions is diamagnetic and has low spin configuration\?/g,
    'निम्नलिखित में से कौन-सा संकुल आयन प्रतिचुंबकीय (diamagnetic) है तथा निम्न चक्रण (low spin) विन्यास रखता है?');

  hi = hi.replace(/The correct IUPAC name of the complex is:/g,
    'संकुल का सही IUPAC नाम है:');

  hi = hi.replace(/The major product obtained in the following reaction is:/g,
    'निम्नलिखित अभिक्रिया में प्राप्त मुख्य उत्पाद है:');

  hi = hi.replace(/The rate constant for a first order reaction is (.*?) s⁻¹\./g,
    'एक प्रथम कोटि अभिक्रिया के लिए वेग स्थिरांक $1 s⁻¹ है।');

  hi = hi.replace(/The value of the definite integral ∫ (.*?) dx is:/g,
    'निश्चित समाकल ∫ $1 dx का मान है:');

  hi = hi.replace(/The shortest distance between the two skew lines (.*?) is:/g,
    'दो विषमतलीय रेखाओं (skew lines) के मध्य लघुतम दूरी है:');

  hi = hi.replace(/The slope m of a common tangent to the parabola (.*?) and the circle (.*?) is:/g,
    'परवलय $1 तथा वृत्त $2 की उभयनिष्ठ स्पर्श रेखा की प्रवणता (slope) m है:');

  // Fallback prefix if no exact regex matched
  if (hi === enText) {
    hi = `[${exam === 'JEE Advanced' ? 'जेईई एडवांस्ड' : 'जेईई मेन'} ${year}] (${topic}): ${enText}`;
  }

  return hi;
};

export const toHindiSolution = (enSol: string, keyFormula?: string, topperTrick?: string): string => {
  let hi = `चरण-दर-चरण समाधान (Step-by-Step Solution):\n` + enSol
    .replace(/Acceleration of center of mass/g, 'द्रव्यमान केंद्र का त्वरण')
    .replace(/No external torque/g, 'कोई बाह्य बल आघूर्ण नहीं')
    .replace(/Angular momentum is conserved/g, 'कोणीय संवेग संरक्षित रहता है')
    .replace(/Substitute values/g, 'मान रखने पर')
    .replace(/Therefore/g, 'अतः')
    .replace(/Hence/g, 'इसलिए')
    .replace(/Since/g, 'चूँकि');

  if (keyFormula) {
    hi += `\n\n📌 मुख्य सूत्र (Key Formula): ${keyFormula}`;
  }
  if (topperTrick) {
    hi += `\n⚡ टॉपर का शॉर्टकट ट्रिक (Time-Saver): ${topperTrick}`;
  }
  return hi;
};

/**
 * Builds the exact 75 questions for any test from the 1000-test catalog
 */
export const buildQuestionsForCatalogTest = (testItem: TestCatalogItem): Question[] => {
  const questions: Question[] = [];
  const count = 75;

  // If Full Syllabus (Grand Mock), mix Physics, Chemistry, and Math (25 each)
  if (testItem.subject === 'All Subjects' || testItem.category === 'grand_mock') {
    const pSeeds = modernPhysicsSeeds.concat(rotationalMechanicsSeeds, electrodynamicsSeeds);
    const cSeeds = coordinationBondingSeeds.concat(organicChemistrySeeds, physicalChemistrySeeds);
    const mSeeds = vectors3DGeometrySeeds.concat(calculusSeeds, algebraMatricesSeeds);

    // 25 Physics
    for (let i = 0; i < 25; i++) {
      const seed = pSeeds[i % pSeeds.length];
      const year = years2010to2026[(testItem.testNumber + i) % years2010to2026.length];
      const exam = i % 2 === 0 ? testItem.examType : 'JEE Main';
      const variant = (i % 5) + 1;
      const qEn = seed.questionTemplate(year, exam, variant);
      const opts = seed.optionsTemplate(variant);
      const sol = seed.solutionTemplate(year, variant);

      questions.push({
        id: `${testItem.id}-q${(i + 1).toString().padStart(2, '0')}`,
        exam,
        year,
        subject: 'Physics',
        topic: 'Physics Core Topics',
        subtopic: seed.subtopic,
        difficulty: testItem.difficulty === 'JEE Advanced Paper-1' ? 'IIT Advanced Level' : seed.difficulty,
        question: qEn,
        questionHindi: toHindiQuestion(qEn, 'भौतिक विज्ञान', year, exam),
        options: opts,
        optionsHindi: opts,
        correctOption: seed.correctOptionIndex,
        solution: sol,
        solutionHindi: toHindiSolution(sol, seed.keyFormula, seed.topperTrick),
        keyFormula: seed.keyFormula,
        keyFormulaHindi: `मुख्य सूत्र: ${seed.keyFormula}`,
        topperTrick: seed.topperTrick,
        topperTrickHindi: `टॉपर ट्रिक: ${seed.topperTrick}`,
      });
    }

    // 25 Chemistry
    for (let i = 0; i < 25; i++) {
      const seed = cSeeds[i % cSeeds.length];
      const year = years2010to2026[(testItem.testNumber + i + 5) % years2010to2026.length];
      const exam = i % 2 === 0 ? testItem.examType : 'JEE Main';
      const variant = (i % 5) + 1;
      const qEn = seed.questionTemplate(year, exam, variant);
      const opts = seed.optionsTemplate(variant);
      const sol = seed.solutionTemplate(year, variant);

      questions.push({
        id: `${testItem.id}-q${(i + 26).toString().padStart(2, '0')}`,
        exam,
        year,
        subject: 'Chemistry',
        topic: 'Chemistry Core Topics',
        subtopic: seed.subtopic,
        difficulty: testItem.difficulty === 'JEE Advanced Paper-1' ? 'IIT Advanced Level' : seed.difficulty,
        question: qEn,
        questionHindi: toHindiQuestion(qEn, 'रसायन विज्ञान', year, exam),
        options: opts,
        optionsHindi: opts,
        correctOption: seed.correctOptionIndex,
        solution: sol,
        solutionHindi: toHindiSolution(sol, seed.keyFormula, seed.topperTrick),
        keyFormula: seed.keyFormula,
        keyFormulaHindi: `मुख्य सूत्र: ${seed.keyFormula}`,
        topperTrick: seed.topperTrick,
        topperTrickHindi: `टॉपर ट्रिक: ${seed.topperTrick}`,
      });
    }

    // 25 Mathematics
    for (let i = 0; i < 25; i++) {
      const seed = mSeeds[i % mSeeds.length];
      const year = years2010to2026[(testItem.testNumber + i + 10) % years2010to2026.length];
      const exam = i % 2 === 0 ? testItem.examType : 'JEE Main';
      const variant = (i % 5) + 1;
      const qEn = seed.questionTemplate(year, exam, variant);
      const opts = seed.optionsTemplate(variant);
      const sol = seed.solutionTemplate(year, variant);

      questions.push({
        id: `${testItem.id}-q${(i + 51).toString().padStart(2, '0')}`,
        exam,
        year,
        subject: 'Mathematics',
        topic: 'Mathematics Core Topics',
        subtopic: seed.subtopic,
        difficulty: testItem.difficulty === 'JEE Advanced Paper-1' ? 'IIT Advanced Level' : seed.difficulty,
        question: qEn,
        questionHindi: toHindiQuestion(qEn, 'गणित', year, exam),
        options: opts,
        optionsHindi: opts,
        correctOption: seed.correctOptionIndex,
        solution: sol,
        solutionHindi: toHindiSolution(sol, seed.keyFormula, seed.topperTrick),
        keyFormula: seed.keyFormula,
        keyFormulaHindi: `मुख्य सूत्र: ${seed.keyFormula}`,
        topperTrick: seed.topperTrick,
        topperTrickHindi: `टॉपर ट्रिक: ${seed.topperTrick}`,
      });
    }

    return questions.map((q, idx) => balanceQuestion(q, BALANCED_ANSWER_CYCLE[idx % BALANCED_ANSWER_CYCLE.length]));
  }

  // Single Subject / Specific Chapter 75-Question Test
  const primarySubject: Subject = testItem.subject as Subject;
  const seeds = getSeedsForTopic(testItem.chapter, primarySubject);

  for (let i = 0; i < count; i++) {
    const seedIndex = i % seeds.length;
    const seed = seeds[seedIndex];
    const year = years2010to2026[(testItem.testNumber * 3 + i) % years2010to2026.length];
    const exam = i % 3 === 0 ? testItem.examType : 'JEE Main';
    const variant = Math.floor(i / seeds.length) + 1;

    const questionEn = seed.questionTemplate(year, exam, variant);
    const options = seed.optionsTemplate(variant);
    const solution = seed.solutionTemplate(year, variant);

    questions.push({
      id: `${testItem.id}-q${(i + 1).toString().padStart(2, '0')}`,
      exam,
      year,
      subject: primarySubject,
      topic: testItem.chapter,
      subtopic: seed.subtopic,
      difficulty: testItem.difficulty === 'JEE Advanced Paper-1' ? 'IIT Advanced Level' : seed.difficulty,
      question: questionEn,
      questionHindi: toHindiQuestion(questionEn, testItem.chapterHindi || testItem.chapter, year, exam),
      options,
      optionsHindi: options,
      correctOption: seed.correctOptionIndex,
      solution,
      solutionHindi: toHindiSolution(solution, seed.keyFormula, seed.topperTrick),
      keyFormula: seed.keyFormula,
      keyFormulaHindi: `मुख्य सूत्र: ${seed.keyFormula}`,
      topperTrick: seed.topperTrick,
      topperTrickHindi: `टॉपर ट्रिक: ${seed.topperTrick}`,
    });
  }

  return questions.map((q, idx) => balanceQuestion(q, BALANCED_ANSWER_CYCLE[idx % BALANCED_ANSWER_CYCLE.length]));
};

/**
 * Converts a TestCatalogItem into a full MockTest object with 75 questions
 */
export const catalogItemToMockTest = (item: TestCatalogItem): MockTest => {
  const questions = buildQuestionsForCatalogTest(item);

  return {
    id: item.id,
    testNumber: item.testNumber,
    title: item.title,
    titleHindi: item.titleHindi,
    examType: item.examType,
    durationMinutes: item.durationMinutes,
    totalQuestions: questions.length,
    totalMarks: questions.length * 4,
    subjectBreakdown: {
      Physics: questions.filter(q => q.subject === 'Physics').length,
      Chemistry: questions.filter(q => q.subject === 'Chemistry').length,
      Mathematics: questions.filter(q => q.subject === 'Mathematics').length,
    },
    difficulty: item.difficulty,
    description: item.description,
    descriptionHindi: item.descriptionHindi,
    chapter: item.chapter,
    isChapterTest: item.isChapterTest,
    category: item.category,
    weightageTag: item.weightageTag,
    weightageTagHindi: item.weightageTagHindi,
    highYieldTips: item.highYieldTips,
    highYieldTipsHindi: item.highYieldTipsHindi,
    isBilingualAvailable: true,
    questions,
  };
};
