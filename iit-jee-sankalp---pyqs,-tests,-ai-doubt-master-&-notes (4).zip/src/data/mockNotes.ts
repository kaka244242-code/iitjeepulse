import { PremiumNoteBundle } from '../types';

export interface ChapterNote {
  id: string;
  subject: 'Physics' | 'Chemistry' | 'Mathematics';
  chapter: string;
  readTimeMinutes: number;
  weightagePercentage: number;
  summary: string;
  keyFormulas: { name: string; formula: string; notes: string }[];
  highYieldPoints: string[];
  commonMistakes: string[];
}

export const chapterNotes: ChapterNote[] = [
  {
    id: 'cn-phy-rot',
    subject: 'Physics',
    chapter: 'Rotational Motion & Rigid Body Dynamics',
    readTimeMinutes: 12,
    weightagePercentage: 8,
    summary: 'Rotational motion blends translational kinematics with moment of inertia, torque, angular momentum conservation, and pure rolling on horizontal/inclined surfaces.',
    keyFormulas: [
      { name: 'Moment of Inertia (Continuous)', formula: 'I = ∫ r² dm', notes: 'Rod (center): ML²/12; Ring: MR²; Disc: MR²/2; Solid Sphere: (2/5)MR²; Hollow: (2/3)MR²' },
      { name: 'Angular Momentum', formula: 'L_total = r_cm × P_total + I_cm · ω', notes: 'Conserved when external torque τ_ext = 0 about the chosen axis' },
      { name: 'Pure Rolling Acceleration', formula: 'a_cm = (g sin θ) / (1 + I_cm / (M R²))', notes: 'Friction f = (M g sin θ) / (1 + M R² / I_cm)' },
      { name: 'Kinetic Energy of Rolling Body', formula: 'KE = (1/2) M v_cm² + (1/2) I_cm ω² = (1/2) M v_cm² (1 + k²/R²)', notes: 'k is radius of gyration' },
    ],
    highYieldPoints: [
      'For pure rolling, velocity of instantaneous point of contact with ground is ZERO.',
      'Torque equation τ = I α is valid about Center of Mass OR about an Instantaneous Center of Zero Velocity.',
      'Work done by static friction in pure rolling on stationary ground is ZERO.',
    ],
    commonMistakes: [
      'Applying perpendicular axis theorem to 3D bodies.',
      'Taking torque about an accelerating non-COM point without adding pseudo-force torque.',
      'Assuming friction always opposes motion; in rolling, friction can act in direction of motion.',
    ],
  },
  {
    id: 'cn-chem-goc',
    subject: 'Chemistry',
    chapter: 'General Organic Chemistry (GOC) & Reaction Mechanisms',
    readTimeMinutes: 15,
    weightagePercentage: 10,
    summary: 'The foundation of organic chemistry: inductive effect, resonance, hyperconjugation, aromaticity (Hückel\'s rule), acidity, basicity, and reactive intermediates.',
    keyFormulas: [
      { name: 'Aromaticity Criteria (Hückel\'s Rule)', formula: 'Planar, cyclic, conjugated with (4n + 2) π-electrons', notes: '4n π-electrons in planar cyclic conjugated system = Anti-aromatic (highly unstable)' },
      { name: 'Carbocation Stability Trend', formula: 'Aromatic > Tropylium > Cyclopropylmethyl (CPM) > Substituted Allylic/Benzylic > 3° > 2° > 1° > Vinyl/Phenyl', notes: 'CPM shows exceptional stability due to dancing resonance' },
      { name: 'Acidic Strength Rule', formula: 'Acidity ∝ Stability of Conjugate Base (Anion)', notes: '-M, -I stabilize conjugate base; +M, +I destabilize' },
    ],
    highYieldPoints: [
      'Resonance effect (+M/-M) operates equally at ortho and para positions, but DOES NOT operate at meta position.',
      'Ortho-effect in substituted benzoic acids dramatically increases acidic strength regardless of whether the ortho-group is electron withdrawing or donating (due to steric hindrance to planarity).',
      'Hyperconjugation in alkenes: Stability ∝ number of α-hydrogens.',
    ],
    commonMistakes: [
      'Considering mesomeric effect at meta position.',
      'Forgetting that halogens are deactivating yet ortho/para directing on benzene ring.',
      'Confusing carbocation hydride shift with methyl shift; always prefer the shift giving maximum resonance stability.',
    ],
  },
  {
    id: 'cn-math-calc',
    subject: 'Mathematics',
    chapter: 'Definite Integration & Differential Equations',
    readTimeMinutes: 14,
    weightagePercentage: 12,
    summary: 'Definite integrals using properties (King\'s, Queen\'s, periodic integrals), limit of a sum, and linear/exact differential equations with integrating factors.',
    keyFormulas: [
      { name: 'King\'s Property', formula: '∫_a^b f(x) dx = ∫_a^b f(a + b - x) dx', notes: 'Most frequently tested property in JEE Main & Advanced' },
      { name: 'Leibnitz Rule', formula: 'd/dx ∫_(u(x))^(v(x)) f(t) dt = f(v(x)) · v\'(x) - f(u(x)) · u\'(x)', notes: 'Used frequently for evaluating 0/0 limits' },
      { name: 'Linear Differential Equation', formula: 'dy/dx + P(x) y = Q(x)', notes: 'Integrating Factor IF = e^(∫ P(x) dx); Solution: y · IF = ∫ Q(x) · IF dx + C' },
    ],
    highYieldPoints: [
      'If f(x) + f(a + b - x) = c (constant), then ∫_a^b f(x) dx = c · (b - a) / 2.',
      'For periodic function f(x) with period T: ∫₀^(nT) f(x) dx = n ∫₀^T f(x) dx.',
      'Definite integral as limit of sum: lim_(n→∞) (1/n) ∑ f(r/n) = ∫₀¹ f(x) dx.',
    ],
    commonMistakes: [
      'Omitting the derivative of limits (v\'(x) and u\'(x)) when applying Leibnitz rule.',
      'Forgetting the integrating factor coefficient sign when rewriting non-standard differential equations.',
    ],
  },
];

export const premiumNoteBundles: PremiumNoteBundle[] = [
  {
    id: 'pnb-01',
    title: 'Kota Toppers AIR-1 Handwritten Physics Master-Vault',
    subtitle: 'Complete Class 11 & 12 formulas, edge-case derivations & memory-maps by IIT Bombay CS toppers.',
    author: 'Er. Aryan Sharma',
    authorRank: 'AIR 34 · IIT Bombay EE',
    subject: 'Physics',
    pages: 142,
    priceCoins: 120, // Free with practice coins or instant unlock
    rating: 4.9,
    reviewsCount: 3840,
    tags: ['Handwritten', 'Kota Coaching Elite', 'Color Coded', 'Edge Cases'],
    features: [
      '100% Comprehensive Coverage of 32 Chapters',
      'All Irodov & Krotov recurring trick patterns annotated',
      'Error & Negative Marks Prevention Checklists',
      'Full Vector & Graph Visualization Cheat-sheets',
    ],
    previewPages: [
      'Kinematics & Relative Motion: Instantaneous center of rotation & river-boat 3D vectors',
      'Rotational Dynamics: Toppling conditions vs sliding, angular impulse problems',
      'Electrodynamics: Mirror charge method, dipole-quadrupole field approximations',
      'Modern Physics: Bohr correspondence principle, X-ray Duane-Hunt limit derivations',
    ],
    fullContentSnippet: `# KOTA TOPPERS AIR-34 HANDWRITTEN PHYSICS VAULT

## Chapter 1: Advanced Rotational Mechanics
- Toppling vs Sliding Condition:
  * Block of base 'b' and height 'h' pulled with force F at height 'y'.
  * Normal force shifts towards the front edge: x = (F · y) / (M g).
  * Toppling occurs before sliding if y / (b/2) > 1 / μ.

## Chapter 2: Electrodynamics Pro Tips
- Capacitance with multiple dielectrics:
  * For split along area: Parallel combination -> C = (ε₀/d)[k₁ A₁ + k₂ A₂]
  * For split along thickness: Series combination -> 1/C = (1/ε₀ A)[d₁/k₁ + d₂/k₂]
  * Force between capacitor plates: F = Q² / (2 A ε₀) = (1/2) Q E_external

## Chapter 3: Thermodynamics Shortcuts
- Polytropic work done: W = (P₁ V₁ - P₂ V₂) / (n - 1) = n R (T₁ - T₂) / (n - 1)
- Ratio of slopes: (dP/dV)_adiabatic / (dP/dV)_isothermal = γ (Always steeper by factor γ!)
`,
  },
  {
    id: 'pnb-02',
    title: 'Organic Chemistry Reaction Mechanism & Reagent Bible',
    subtitle: 'From GOC to Named Reactions, Reagent charts, Stereochemistry tables & Synthesis roadmaps.',
    author: 'Dr. Vikrant Mehta',
    authorRank: 'Ex-Allen Senior Chemistry Faculty · IIT Delhi',
    subject: 'Chemistry',
    pages: 118,
    priceCoins: 100,
    rating: 4.95,
    reviewsCount: 5210,
    tags: ['Reaction Roadmaps', 'Named Reactions', 'Reagents Chart', 'Stereochem'],
    features: [
      '50+ High-Yield Named Reactions with step-by-step arrows',
      'Complete Reagent Summary: Reducing & Oxidizing agents matrix',
      'Stereochemical outcomes of SN1, SN2, E1, E2, Syn/Anti additions',
      'Biomolecules & Polymer memory triggers',
    ],
    previewPages: [
      'Carbocation Rearrangements: Ring expansion rules (4->5 and 5->6 membered)',
      'Carbonyl Chemistry: Cannizzaro, Aldol, Perkin, Benzoin, Reformatsky mechanisms',
      'Aromatic Chemistry: Nitration, Friedel-Crafts limitations & rearrangement quirks',
      'Reagent Master Matrix: DIBAL-H, LiAlH₄, NaBH₄, PCC, PDC, Jones, CrO₂Cl₂ selectivity',
    ],
    fullContentSnippet: `# ORGANIC CHEMISTRY REAGENTS & MECHANISMS BIBLE

## 1. Selectivity of Hydride Reducing Agents
- LiAlH₄: Reduces RCOOH, RCOCl, RCOOR, RCONH₂, RCN, Aldehydes & Ketones to alcohols/amines. Does NOT touch isolated C=C bonds (Exception: Cinnamaldehyde).
- NaBH₄: Mild! Only reduces Aldehydes, Ketones, and Acid chlorides. Inert towards Esters, Acids, Amides.
- DIBAL-H: At -78°C, smoothly reduces Esters and Nitriles (RCN) directly to Aldehydes!
- Pd/BaSO₄ + Quinoline (Lindlar): Alkynes -> cis-Alkenes (Syn addition).
- Na / Liquid NH₃ (Birch): Alkynes -> trans-Alkenes (Anti addition); reduces aromatic rings to 1,4-cyclohexadienes.

## 2. Electrophilic Aromatic Substitution (EAS) Reactivity Order:
- -O⁻ > -NR₂ > -NH₂ > -OH > -OR > -NHCOR > -R > -Ph > -H > -X > -CHO > -COR > -COOR > -COOH > -SO₃H > -CN > -NO₂ > -NR₃⁺
- Remember: Halogens (-F, -Cl, -Br, -I) are DEACTIVATING due to strong -I, but ORTHO/PARA DIRECTING due to lone pair +M effect!
`,
  },
  {
    id: 'pnb-03',
    title: 'JEE Mathematics 100 Short-Tricks & Elimination Hacks',
    subtitle: 'Solve 20+ JEE Main math questions in under 60 seconds each using options testing, limits, and symmetry.',
    author: 'Prof. Ramanujan K.',
    authorRank: 'AIR 12 · IIT Kanpur Math Dept.',
    subject: 'Mathematics',
    pages: 96,
    priceCoins: 90,
    rating: 4.88,
    reviewsCount: 4120,
    tags: ['Speed Hacks', 'Calculus Shortcuts', 'Coordinate Elimination', 'Matrices Tricks'],
    features: [
      'Substitution & Dimensional elimination methods',
      'Matrices: Cayley-Hamilton & Eigenvalue rapid solvers',
      'Coordinate Geometry: Parametric locus shortcuts',
      'Definite Integrals: Master table of standard King\'s property forms',
    ],
    previewPages: [
      'Binomial Theorem: Setting x = 1, -1, i for sum of series in 15 seconds',
      'Calculus: Rapid Area under curves using standard parabolic arch formulas (8/3 a² / m³)',
      '3D Geometry: Skew lines distance without formula using determinant inspection',
      'Probability: Bayes theorem tree diagrams and trick ratios',
    ],
    fullContentSnippet: `# JEE MATHEMATICS 100 SPEED HACKS

## Trick 1: Area Enclosed Between Parabola and Line
- For y² = 4ax and y = mx:
  * Area = (8/3) · (a² / m³)
  * Example: Area between y² = 4x (a=1) and y = x (m=1) is (8/3)(1/1) = 8/3 sq units in 2 seconds!
- Area between y² = 4ax and x² = 4by:
  * Area = (16/3) · a · b

## Trick 2: Cayley-Hamilton for 2x2 Matrix Inverses & Powers
- Every square matrix satisfies its own characteristic equation:
  * For matrix A = [[a, b], [c, d]]:
  * A² - (trace A) A + (det A) I = 0
  * Multiply by A⁻¹: A⁻¹ = (1 / det A) [ (trace A) I - A ]
  * This allows computing A¹⁰ or A⁻¹ in 3 lines without calculating adjoint elements!

## Trick 3: Sum of Trigonometric Series
- sin(α) + sin(α+β) + ... + sin(α + (n-1)β) = [ sin(nβ/2) / sin(β/2) ] · sin( α + (n-1)β/2 )
`,
  },
  {
    id: 'pnb-04',
    title: '15-Year Solved Chapter-wise JEE Advanced Mega Compendium',
    subtitle: 'Every challenging multi-correct, matrix match, and integer-type question with multi-method solutions.',
    author: 'Sankalp Academic Team',
    authorRank: 'IITian Faculty Panel',
    subject: 'Full PCM',
    pages: 350,
    priceCoins: 180,
    rating: 4.97,
    reviewsCount: 6890,
    tags: ['15 Years PYQ', 'Multi-Correct', 'Integer Type', 'Matrix Match'],
    features: [
      '2009–2024 JEE Advanced official papers fully analyzed',
      'Classified by topic & increasing cognitive difficulty',
      'Alternative conceptual methods for every multi-correct question',
      'Includes Official JEE Advanced Answer Keys & marking nuances',
    ],
    previewPages: [
      'Physics: Advanced electromagnetic levitation and variable mass systems',
      'Chemistry: Comprehensive multi-step organic synthesis puzzles',
      'Maths: Complex numbers geometry & Olympiad-level polynomial roots',
      'Marking Scheme Strategy: When to guess partially in multi-correct to maximize positive marks',
    ],
    fullContentSnippet: `# 15-YEAR SOLVED JEE ADVANCED MEGA COMPENDIUM

## JEE Advanced Multi-Correct Strategy:
- In partial marking:
  * If correct options are A, B, D:
  * Selecting A, B gives +2 marks.
  * Selecting A, B, C (one wrong option) gives -2 marks!
  * GOLDEN RULE: If uncertain about the 3rd or 4th option, DO NOT SELECT IT! Lock in the sure-shot partial positive marks.

## Topic Breakdown:
1. Physics: Mechanics (26%), Electrodynamics (32%), Modern Physics (18%), Optics & Waves (14%), Thermal (10%)
2. Chemistry: Organic (34%), Physical (33%), Inorganic (33%)
3. Mathematics: Calculus (38%), Coordinate Geometry (20%), Vectors & 3D (18%), Algebra (24%)
`,
  },
];
