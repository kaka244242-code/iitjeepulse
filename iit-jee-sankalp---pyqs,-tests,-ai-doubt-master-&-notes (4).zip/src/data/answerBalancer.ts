import { Question } from '../types';

// Balanced 20-item distribution across A(0), B(1), C(2), D(3)
// 5 of each option, non-repeating adjacent options
export const BALANCED_ANSWER_CYCLE: number[] = [
  1, 2, 0, 3, 2, 1, 3, 0, 1, 3, 2, 0, 3, 0, 1, 2, 2, 3, 0, 1
];

const OPTION_LETTERS = ['A', 'B', 'C', 'D'] as const;

/**
 * Takes any question and moves the correct answer to targetOption (0=A, 1=B, 2=C, 3=D).
 * Swaps English and Hindi options accordingly and updates the explanation text.
 */
export function balanceQuestion(q: Question, targetOption: number): Question {
  const currentCorrect = typeof q.correctOption === 'number' && q.correctOption >= 0 && q.correctOption < 4 
    ? q.correctOption 
    : 0;

  const target = targetOption >= 0 && targetOption < 4 ? targetOption : 0;

  // Clone options
  const newOptions = [...q.options];
  const newOptionsHindi = q.optionsHindi ? [...q.optionsHindi] : undefined;

  // If current correct is not already at target, swap them
  if (currentCorrect !== target) {
    // Swap in English options
    const tempEn = newOptions[target];
    newOptions[target] = newOptions[currentCorrect];
    newOptions[currentCorrect] = tempEn;

    // Swap in Hindi options if present
    if (newOptionsHindi && newOptionsHindi.length >= 4) {
      const tempHi = newOptionsHindi[target];
      newOptionsHindi[target] = newOptionsHindi[currentCorrect];
      newOptionsHindi[currentCorrect] = tempHi;
    }
  }

  const oldLetter = OPTION_LETTERS[currentCorrect];
  const newLetter = OPTION_LETTERS[target];

  // Update solution text
  let newSolution = q.solution || '';
  let newSolutionHindi = q.solutionHindi || '';

  if (currentCorrect !== target) {
    // Replace old option references with new option references
    const oldOptRegexEn = new RegExp(`(Option|Matches option|correct option|Option:)\\s*\\(?${oldLetter}\\)?`, 'gi');
    newSolution = newSolution.replace(oldOptRegexEn, `$1 (${newLetter})`);

    const oldOptRegexHi = new RegExp(`(विकल्प|सही विकल्प)\\s*\\(?${oldLetter}\\)?`, 'gi');
    newSolutionHindi = newSolutionHindi.replace(oldOptRegexHi, `$1 (${newLetter})`);
  }

  // Ensure an unambiguous, clean answer confirmation badge is appended if not already present
  const correctValEn = newOptions[target] || '';
  const correctValHi = newOptionsHindi ? newOptionsHindi[target] : correctValEn;

  // Strip any old trailing verified lines to avoid duplicates
  newSolution = newSolution.replace(/\n*✓ \*\*Correct Answer:[\s\S]*$/i, '').trimEnd();
  newSolution += `\n\n✓ **Correct Answer: Option (${newLetter})** — ${correctValEn}`;

  if (newSolutionHindi) {
    newSolutionHindi = newSolutionHindi.replace(/\n*✓ \*\*सटीक सही उत्तर:[\s\S]*$/i, '').trimEnd();
    newSolutionHindi += `\n\n✓ **सटीक सही उत्तर: विकल्प (${newLetter})** — ${correctValHi}`;
  }

  return {
    ...q,
    options: newOptions,
    optionsHindi: newOptionsHindi,
    correctOption: target,
    solution: newSolution,
    solutionHindi: newSolutionHindi || undefined,
  };
}
