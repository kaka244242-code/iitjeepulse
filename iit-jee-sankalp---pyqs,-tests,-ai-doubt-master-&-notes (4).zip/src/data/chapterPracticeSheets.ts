import { PYQSheetItem } from './allChaptersNotesAndSheets';
import { BookItem } from '../types';
import { get20QuestionsForChapter } from './chapterSpecificQuestions';

// Complete list of chapters across Physics, Chemistry, and Mathematics
interface ChapterMeta {
  id: string;
  chapter: string;
  chapterHindi: string;
  subject: 'Physics' | 'Chemistry' | 'Mathematics';
  weightage: string;
  topSubtopics: string[];
  topSubtopicsHindi: string[];
  formula: string;
  formulaHi: string;
  trick: string;
  trickHi: string;
  sampleEn: string;
  sampleHi: string;
  optionsEn: string[];
  optionsHi: string[];
  correctOption: number;
  solEn: string;
  solHi: string;
}

const allChaptersMeta: ChapterMeta[] = [
  // --- PHYSICS (12 High-Yield Chapters) ---
  {
    id: 'ps-phy-01',
    chapter: 'Rotational Motion & Rigid Dynamics',
    chapterHindi: 'घूर्णन गति एवं दृढ़ पिंड गतिकी',
    subject: 'Physics',
    weightage: '🔥 12-16 Marks',
    topSubtopics: ['Pure Rolling', 'Moment of Inertia', 'Angular Momentum Conservation', 'Toppling Condition'],
    topSubtopicsHindi: ['शुद्ध लोटनी गति', 'जड़त्व आघूर्ण', 'कोणीय संवेग संरक्षण', 'पलटने की स्थिति'],
    formula: 'a = (g sin θ) / (1 + k²/R²);  τ = I α = dL/dt',
    formulaHi: 'त्वरण a = (g sin θ) / (1 + k²/R²);  बल आघूर्ण τ = I α',
    trick: 'Rolling acceleration rank: Solid Sphere (5/7) > Disc (2/3) > Ring (1/2). Sphere always wins!',
    trickHi: 'त्वरण क्रम: ठोस गोला (5/7) > चकती (2/3) > वलय (1/2)। गोला सदैव पहले पहुंचेगा!',
    sampleEn: 'A solid sphere of mass M and radius R rolls down a 30° incline without slipping. Acceleration of its COM is:',
    sampleHi: 'द्रव्यमान M तथा त्रिज्या R का एक ठोस गोला 30° आनत तल पर बिना फिसले लुढ़कता है। इसके द्रव्यमान केंद्र का त्वरण होगा:',
    optionsEn: ['(5/7) g sin 30°', '(2/3) g sin 30°', '(1/2) g sin 30°', 'g sin 30°'],
    optionsHi: ['(5/7) g sin 30°', '(2/3) g sin 30°', '(1/2) g sin 30°', 'g sin 30°'],
    correctOption: 0,
    solEn: 'For solid sphere k²/R² = 2/5 ⇒ a = g sin θ / (1 + 2/5) = (5/7) g sin 30°.',
    solHi: 'ठोस गोले हेतु k²/R² = 2/5, अतः a = (5/7) g sin 30° = 5g/14.',
  },
  {
    id: 'ps-phy-02',
    chapter: 'Electrodynamics & Capacitors',
    chapterHindi: 'विद्युत चुंबकत्व एवं संधारित्र परिपथ',
    subject: 'Physics',
    weightage: '🔥 16-20 Marks',
    topSubtopics: ['Dielectric Insertion', 'RC Transients', 'Gauss Law', 'Conductor Charge Sharing'],
    topSubtopicsHindi: ['परावैद्युत प्रविष्टि', 'RC परिपथ आवेशन', 'गाउस नियम', 'आवेश पुनर्वितरण'],
    formula: 'C = ε₀ A / (d - t + t/K);  q(t) = Q₀(1 - e^(-t/RC))',
    formulaHi: 'धारिता C = ε₀ A / (d - t + t/K);  q(t) = Q₀(1 - e^(-t/RC))',
    trick: 'Battery connected ⇒ V constant. Battery removed ⇒ Q constant. Memorize this to avoid sign traps!',
    trickHi: 'बैटरी जुड़ी हो तो V नियत, बैटरी हटा लेने पर Q नियत रहता है!',
    sampleEn: 'A parallel plate capacitor is charged and then disconnected from battery. A dielectric slab K is inserted. The electric field E:',
    sampleHi: 'समानांतर प्लेट संधारित्र को आवेशित कर बैटरी से अलग कर दिया जाता है। परावैद्युत K डालने पर विद्युत क्षेत्र E:',
    optionsEn: ['Decreases by factor 1/K', 'Increases by factor K', 'Remains unchanged', 'Becomes zero'],
    optionsHi: ['1/K गुना घट जाता है', 'K गुना बढ़ जाता है', 'अपरिवर्तित रहता है', 'शून्य हो जाता है'],
    correctOption: 0,
    solEn: 'Since battery is disconnected, charge Q is constant. E = σ / (K ε₀) = E₀ / K. Hence decreases by factor 1/K.',
    solHi: 'बैटरी हटने पर आवेश Q नियत रहता है। E = E₀ / K, अतः 1/K गुना घट जाता है।',
  },
  {
    id: 'ps-phy-03',
    chapter: 'Modern Physics & Dual Nature',
    chapterHindi: 'आधुनिक भौतिकी एवं प्रकाश वैद्युत प्रभाव',
    subject: 'Physics',
    weightage: '🔥 16-20 Marks',
    topSubtopics: ['Photoelectric Effect', 'De Broglie Wavelength', 'Bohr Atom Transitions', 'Nuclear Decay'],
    topSubtopicsHindi: ['प्रकाश वैद्युत प्रभाव', 'दे ब्रॉग्ली तरंगदैर्घ्य', 'बोर परमाणु मॉडल', 'रेडियोएक्टिव क्षय'],
    formula: 'eV_s = hν - Φ;  λ = 12.27 / √V Å (for electron);  E_n = -13.6 Z²/n² eV',
    formulaHi: 'eV_s = hν - Φ;  λ = 12.27 / √V Å;  E_n = -13.6 Z²/n² eV',
    trick: 'Photoelectric current ∝ Light Intensity only. Kinetic Energy ∝ Light Frequency only!',
    trickHi: 'प्रकाश धारा केवल तीव्रता पर निर्भर करती है, गतिज ऊर्जा केवल आवृत्ति पर!',
    sampleEn: 'An electron is accelerated through potential difference V = 100 Volts. Its de Broglie wavelength is:',
    sampleHi: 'एक इलेक्ट्रॉन को V = 100 वोल्ट से त्वरित किया जाता है। इसकी दे ब्रॉग्ली तरंगदैर्घ्य होगी:',
    optionsEn: ['1.227 Å', '0.1227 Å', '12.27 Å', '0.012 Å'],
    optionsHi: ['1.227 Å', '0.1227 Å', '12.27 Å', '0.012 Å'],
    correctOption: 0,
    solEn: 'λ = 12.27 / √100 = 12.27 / 10 = 1.227 Å.',
    solHi: 'λ = 12.27 / √100 = 1.227 Å। सही उत्तर (A) है।',
  },
  {
    id: 'ps-phy-04',
    chapter: 'Thermodynamics & Kinetic Theory',
    chapterHindi: 'ऊष्मागतिकी एवं गैसों का अणुगति सिद्धांत',
    subject: 'Physics',
    weightage: '⚡ 12-16 Marks',
    topSubtopics: ['Carnot Efficiency', 'First Law ΔQ = ΔU + W', 'Degrees of Freedom', 'Adiabatic P-V Relations'],
    topSubtopicsHindi: ['कार्नो दक्षता', 'प्रथम नियम', 'स्वतंत्रता की कोटि', 'रुद्धोष्म संबंध'],
    formula: 'η = 1 - T₂/T₁;  W = n R T ln(V₂/V₁) (Isothermal);  P V^γ = const',
    formulaHi: 'दक्षता η = 1 - T₂/T₁;  कार्य W = n R T ln(V₂/V₁);  P V^γ = नियतांक',
    trick: 'Always convert Celsius to Kelvin! In cyclic process on P-V graph, Area = Work done.',
    trickHi: 'तापमान सदैव केल्विन में रखें। P-V ग्राफ में बंद लूप का क्षेत्रफल = किया गया कार्य।',
    sampleEn: 'A Carnot engine operates between 27°C and 327°C. Its thermal efficiency is:',
    sampleHi: 'एक कार्नो इंजन 27°C तथा 327°C के मध्य कार्य करता है। इसकी दक्षता होगी:',
    optionsEn: ['50%', '40%', '60%', '25%'],
    optionsHi: ['50%', '40%', '60%', '25%'],
    correctOption: 0,
    solEn: 'T₁ = 327 + 273 = 600 K; T₂ = 27 + 273 = 300 K. η = 1 - 300/600 = 0.50 (50%).',
    solHi: 'T₁ = 600 K, T₂ = 300 K. η = 1 - 300/600 = 50%। सही विकल्प A है।',
  },
  {
    id: 'ps-phy-05',
    chapter: 'Ray & Wave Optics',
    chapterHindi: 'किरण एवं तरंग प्रकाशिकी',
    subject: 'Physics',
    weightage: '⚡ 12-16 Marks',
    topSubtopics: ['Lens Maker Formula', 'Total Internal Reflection', 'YDSE Fringe Width', 'Brewster Law'],
    topSubtopicsHindi: ['लेंस निर्माता सूत्र', 'पूर्ण आंतरिक परावर्तन', 'YDSE फ्रिंज चौड़ाई', 'ब्रूस्टर नियम'],
    formula: '1/f = (μ - 1)(1/R₁ - 1/R₂);  β = λ D / d;  μ = tan i_p',
    formulaHi: '1/f = (μ - 1)(1/R₁ - 1/R₂);  β = λ D / d;  μ = tan i_p',
    trick: 'In YDSE, if medium of refractive index μ is introduced, fringe width becomes β/μ.',
    trickHi: 'YDSE में माध्यम भरने पर फ्रिंज चौड़ाई β/μ हो जाती है।',
    sampleEn: 'In a YDSE experiment, distance between slits is d = 0.5 mm and screen is D = 1 m away. For λ = 500 nm, fringe width β is:',
    sampleHi: 'YDSE में d = 0.5 मिमी तथा D = 1 मी है। λ = 500 नैनोमीटर हेतु फ्रिंज चौड़ाई β होगी:',
    optionsEn: ['1.0 mm', '0.5 mm', '2.0 mm', '0.25 mm'],
    optionsHi: ['1.0 मिमी', '0.5 मिमी', '2.0 मिमी', '0.25 मिमी'],
    correctOption: 0,
    solEn: 'β = λ D / d = (500 × 10⁻⁹ × 1) / (0.5 × 10⁻³) = 10⁻³ m = 1.0 mm.',
    solHi: 'β = (500 × 10⁻⁹ × 1) / (0.5 × 10⁻³) = 1.0 मिमी।',
  },
  {
    id: 'ps-phy-06',
    chapter: 'Current Electricity & Circuit Networks',
    chapterHindi: 'विद्युत धारा एवं परिपथ नेटवर्क',
    subject: 'Physics',
    weightage: '🔥 12-16 Marks',
    topSubtopics: ['Kirchhoff Laws', 'Wheatstone Bridge', 'Meter Bridge', 'Internal Resistance'],
    topSubtopicsHindi: ['किरचॉफ नियम', 'व्हीटस्टोन सेतु', 'मीटर सेतु', 'आंतरिक प्रतिरोध'],
    formula: 'V = E - I r;  R = ρ l / A;  P = V²/R = I²R',
    formulaHi: 'V = E - I r;  प्रतिरोध R = ρ l / A;  शक्ति P = I²R',
    trick: 'For maximum power transfer from battery to external load, external R MUST equal internal r.',
    trickHi: 'अधिकतम शक्ति स्थानांतरण हेतु बाह्य प्रतिरोध R = आंतरिक प्रतिरोध r होना चाहिए।',
    sampleEn: 'A cell of EMF E = 6 V and internal resistance r = 2 Ω is connected to a variable resistor R. Maximum power delivered to R is:',
    sampleHi: 'E = 6 V तथा r = 2 Ω का सेल परिवर्ती प्रतिरोध R से जुड़ा है। R को दी गई अधिकतम शक्ति होगी:',
    optionsEn: ['4.5 W', '9.0 W', '18.0 W', '2.25 W'],
    optionsHi: ['4.5 W', '9.0 W', '18.0 W', '2.25 W'],
    correctOption: 0,
    solEn: 'Maximum power occurs at R = r = 2 Ω. P_max = E² / (4r) = 36 / (4 × 2) = 4.5 W.',
    solHi: 'R = r = 2 Ω पर P_max = E² / (4r) = 36 / 8 = 4.5 W.',
  },
  {
    id: 'ps-phy-07',
    chapter: 'Gravitation & Kepler Laws',
    chapterHindi: 'गुरुत्वाकर्षण एवं केपलर नियम',
    subject: 'Physics',
    weightage: '🔥 8-12 Marks',
    topSubtopics: ['Orbital & Escape Velocity', 'Gravitational Potential', 'Kepler 3rd Law T² ∝ R³', 'Variation of g with Height & Depth'],
    topSubtopicsHindi: ['कक्षीय व पलायन वेग', 'गुरुत्वीय विभव', 'केपलर तृतीय नियम', 'g का मान परिवर्तन'],
    formula: 'v_e = √(2 g R);  v_o = √(g R);  g\' = g(1 - 2h/R) = g(1 - d/R)',
    formulaHi: 'पलायन वेग v_e = √(2 g R);  g\' = g(1 - 2h/R)',
    trick: 'Escape velocity from earth surface is always √2 × orbital velocity = 11.2 km/s.',
    trickHi: 'पलायन वेग = √2 × कक्षीय वेग = 11.2 किमी/सेकंड होता है।',
    sampleEn: 'The escape velocity from earth is v_e = 11.2 km/s. If a body is projected with speed 2 v_e, its speed in interstellar space is:',
    sampleHi: 'पृथ्वी से पलायन वेग v_e = 11.2 किमी/सेकंड है। यदि एक पिंड को 2 v_e चाल से प्रक्षेपित किया जाए तो अंतरिक्ष में इसकी चाल होगी:',
    optionsEn: ['√3 v_e (19.4 km/s)', 'v_e (11.2 km/s)', '2 v_e (22.4 km/s)', '√5 v_e (25 km/s)'],
    optionsHi: ['√3 v_e (19.4 किमी/से)', 'v_e (11.2 किमी/से)', '2 v_e (22.4 किमी/से)', '√5 v_e (25 किमी/से)'],
    correctOption: 0,
    solEn: 'By energy conservation: 1/2 m v_∞² = 1/2 m (2 v_e)² - 1/2 m v_e² = 1/2 m (3 v_e²) ⇒ v_∞ = √3 v_e.',
    solHi: 'ऊर्जा संरक्षण से: v_∞ = √(v² - v_e²) = √(4v_e² - v_e²) = √3 v_e।',
  },
  {
    id: 'ps-phy-08',
    chapter: 'Kinematics 1D, 2D & Projectile Motion',
    chapterHindi: 'शुद्ध गतिकी एवं प्रक्षेप्य गति',
    subject: 'Physics',
    weightage: '🔥 8-12 Marks',
    topSubtopics: ['Maximum Height & Range', 'Trajectory Equation', 'Relative Velocity in 2D', 'Velocity at Instant'],
    topSubtopicsHindi: ['अधिकतम ऊंचाई व परास', 'प्रक्षेप्य पथ समीकरण', '2D आपेक्षिक वेग', 'तात्क्षणिक वेग'],
    formula: 'R = u² sin(2θ) / g;  H = u² sin²θ / (2g);  y = x tan θ - g x² / (2 u² cos² θ)',
    formulaHi: 'परास R = u² sin(2θ) / g;  ऊंचाई H = u² sin²θ / (2g)',
    trick: 'Range is identical for complementary angles θ and 90° - θ! Ratio of heights is tan² θ.',
    trickHi: 'पूरक कोणों (θ तथा 90°-θ) पर क्षैतिज परास समान होती है! ऊंचाइयों का अनुपात tan² θ होता है।',
    sampleEn: 'A projectile has same horizontal range for angles of projection 30° and 60°. If heights attained are H₁ and H₂, then H₁ / H₂ is:',
    sampleHi: 'प्रक्षेप्य के 30° तथा 60° कोणों हेतु क्षैतिज परास समान है। प्राप्त अधिकतम ऊंचाइयाँ H₁ व H₂ हों तो H₁ / H₂ होगा:',
    optionsEn: ['1 / 3', '3 / 1', '1 / √3', '1 / 9'],
    optionsHi: ['1 / 3', '3 / 1', '1 / √3', '1 / 9'],
    correctOption: 0,
    solEn: 'H₁ / H₂ = sin²(30°) / sin²(60°) = (1/4) / (3/4) = 1/3.',
    solHi: 'H₁ / H₂ = sin² 30° / sin² 60° = (1/2)² / (√3/2)² = 1/3। सही उत्तर A है।',
  },

  // --- CHEMISTRY (12 High-Yield Chapters) ---
  {
    id: 'ps-chem-01',
    chapter: 'Coordination Compounds & Bonding',
    chapterHindi: 'उपसहसंयोजन यौगिक एवं आबंधन',
    subject: 'Chemistry',
    weightage: '🔥 12-16 Marks',
    topSubtopics: ['Crystal Field Theory', 'Spin-Only Magnetic Moment', 'Isomerism', 'Synergic Bonding'],
    topSubtopicsHindi: ['क्रिस्टल क्षेत्र सिद्धांत', 'चुंबकीय आघूर्ण μ', 'समावयवता', 'सिनर्जिक आबंधन'],
    formula: 'μ = √(n(n + 2)) BM;  Δ_o vs P (Pairing Energy)',
    formulaHi: 'μ = √(n(n + 2)) BM;  Δ_o व P का संबंध',
    trick: 'Unpaired electrons direct table: n=1→1.73; n=2→2.83; n=3→3.87; n=4→4.90; n=5→5.92 BM.',
    trickHi: 'अयुग्मित इलेक्ट्रॉन BM मान: n=1→1.73; n=2→2.83; n=3→3.87; n=4→4.90; n=5→5.92 BM.',
    sampleEn: 'The spin-only magnetic moment of [Fe(H₂O)₆]²⁺ (Fe²⁺ high-spin, d⁶) is:',
    sampleHi: '[Fe(H₂O)₆]²⁺ (Fe²⁺ उच्च-चक्रण, d⁶) का चुंबकीय आघूर्ण होगा:',
    optionsEn: ['4.90 BM', '5.92 BM', '2.83 BM', '0 BM'],
    optionsHi: ['4.90 BM', '5.92 BM', '2.83 BM', '0 BM'],
    correctOption: 0,
    solEn: 'High spin d⁶ in octahedral field has configuration (t₂g)⁴ (eg)². Number of unpaired electrons n = 4. μ = √(4 × 6) = √24 = 4.90 BM.',
    solHi: 'उच्च चक्रण d⁶ में 4 अयुग्मित इलेक्ट्रॉन होते हैं। μ = √(4 × 6) = 4.90 BM.',
  },
  {
    id: 'ps-chem-02',
    chapter: 'Organic Reaction Mechanisms & Carbonyls',
    chapterHindi: 'कार्बनिक अभिक्रिया क्रियाविधि एवं कार्बोनिल यौगिक',
    subject: 'Chemistry',
    weightage: '🔥 16-20 Marks',
    topSubtopics: ['Aldol Condensation', 'Cannizzaro Disproportionation', 'Grignard Additions', 'SN1 vs SN2'],
    topSubtopicsHindi: ['एल्डोल संघनन', 'कैनिजारो अभिक्रिया', 'ग्रिग्नार्ड अभिकर्मक', 'SN1 बनाम SN2'],
    formula: 'Aldol: α-H required; Cannizzaro: No α-H (HCHO, PhCHO)',
    formulaHi: 'एल्डोल: α-H आवश्यक; कैनिजारो: α-H अनुपस्थित',
    trick: 'No α-H + Concentrated Alkali = Cannizzaro. Presence of α-H + Dilute Alkali = Aldol!',
    trickHi: 'α-H अनुपस्थित = कैनिजारो। α-H उपस्थित = एल्डोल संघनन!',
    sampleEn: 'Which of the following compounds gives a positive Iodoform test with I₂ and NaOH?',
    sampleHi: 'निम्नलिखित में से कौन-सा यौगिक I₂ तथा NaOH के साथ धनात्मक आयोडोफॉर्म परीक्षण देता है?',
    optionsEn: ['Acetaldehyde (CH₃CHO)', 'Benzaldehyde (PhCHO)', 'Methanol (CH₃OH)', 'Diethyl ether'],
    optionsHi: ['ऐसीटैल्डिहाइड (CH₃CHO)', 'बेन्जैल्डिहाइड (PhCHO)', 'मेथनॉल (CH₃OH)', 'डाइऐथिल ईथर'],
    correctOption: 0,
    solEn: 'Only compounds containing CH₃-C=O or CH₃-CH(OH)- group give positive iodoform test. Acetaldehyde satisfies this.',
    solHi: 'CH₃-C=O समूह उपस्थित होने के कारण ऐसीटैल्डिहाइड पीला CHI₃ अवक्षेप देता है।',
  },
  {
    id: 'ps-chem-03',
    chapter: 'Electrochemistry & Ionic Solutions',
    chapterHindi: 'विद्युत रसायन एवं आयनिक विलयन',
    subject: 'Chemistry',
    weightage: '🔥 12-16 Marks',
    topSubtopics: ['Nernst Equation', 'Faraday Laws of Electrolysis', 'Kohlrausch Law', 'Conductivity'],
    topSubtopicsHindi: ['नेर्नस्ट समीकरण', 'फैराडे के नियम', 'कोलरॉउश नियम', 'मोलर चालकता'],
    formula: 'E_cell = E° - (0.0591/n) log Q;  m = Z I t;  Λ°_m additive',
    formulaHi: 'E_cell = E° - (0.0591/n) log Q;  m = Z I t;  Λ°_m योज्य',
    trick: 'At equilibrium, E_cell = 0 ⇒ E°_cell = (0.0591 / n) log K_eq.',
    trickHi: 'साम्यावस्था पर E_cell = 0 होता है, अतः E° = (0.0591 / n) log K_eq.',
    sampleEn: 'For galvanic cell with E° = 1.10 V at 298 K, if reaction quotient Q = 10⁻², cell potential E is:',
    sampleHi: '298 K पर गैल्वेनिक सेल हेतु E° = 1.10 V है। यदि Q = 10⁻² हो तो सेल विभव E होगा (n = 2):',
    optionsEn: ['1.159 V', '1.041 V', '1.100 V', '0.000 V'],
    optionsHi: ['1.159 V', '1.041 V', '1.100 V', '0.000 V'],
    correctOption: 0,
    solEn: 'E = 1.10 - (0.0591/2) log(10⁻²) = 1.10 + 0.0591 = 1.159 V.',
    solHi: 'E = 1.10 - (0.0591/2)(-2) = 1.10 + 0.0591 = 1.159 V.',
  },
  {
    id: 'ps-chem-04',
    chapter: 'Chemical Kinetics & Equilibrium',
    chapterHindi: 'रासायनिक बलगतिकी एवं साम्यावस्था',
    subject: 'Chemistry',
    weightage: '⚡ 12-16 Marks',
    topSubtopics: ['Arrhenius Equation', 'First Order Half-Life', 'Le Chatelier Principle', 'Solubility Product K_sp'],
    topSubtopicsHindi: ['आर्हीनियस समीकरण', 'प्रथम कोटि अर्ध-आयु', 'ला-शातेलिए नियम', 'विलेयता गुणनफल'],
    formula: 't_1/2 = 0.693 / k;  k = A e^(-E_a / RT);  K_p = K_c (RT)^Δn',
    formulaHi: 't_1/2 = 0.693 / k;  k = A e^(-E_a / RT);  K_p = K_c (RT)^Δn',
    trick: 'For first order reaction, time to reach 99.9% completion is exactly 10 × t_1/2!',
    trickHi: 'प्रथम कोटि अभिक्रिया को 99.9% पूर्ण होने में ठीक 10 × t_1/2 समय लगता है!',
    sampleEn: 'A first order reaction has rate constant k = 0.0693 min⁻¹. Its half-life period t_1/2 is:',
    sampleHi: 'एक प्रथम कोटि अभिक्रिया का वेग स्थिरांक k = 0.0693 मिनट⁻¹ है। इसकी अर्ध-आयु होगी:',
    optionsEn: ['10 minutes', '5 minutes', '20 minutes', '1 minute'],
    optionsHi: ['10 मिनट', '5 मिनट', '20 मिनट', '1 मिनट'],
    correctOption: 0,
    solEn: 't_1/2 = 0.693 / 0.0693 = 10 minutes.',
    solHi: 't_1/2 = 0.693 / 0.0693 = 10 मिनट। सही उत्तर A है।',
  },
  {
    id: 'ps-chem-05',
    chapter: 'Chemical Bonding & Molecular Structure',
    chapterHindi: 'रासायनिक आबंधन एवं आणविक संरचना',
    subject: 'Chemistry',
    weightage: '🔥 12-16 Marks',
    topSubtopics: ['VSEPR Shapes & Hybridization', 'Molecular Orbital Theory Bond Order', 'Dipole Moments', 'Hydrogen Bonding'],
    topSubtopicsHindi: ['VSEPR आकृति व संकरण', 'MOT आबंध कोटि', 'द्विध्रुव आघूर्ण', 'हाइड्रोजन आबंधन'],
    formula: 'Bond Order = 1/2(N_b - N_a);  μ = q × d;  Steric No = σ + Lone Pair',
    formulaHi: 'आबंध कोटि = 1/2(N_b - N_a);  द्विध्रुव आघूर्ण μ = q × d',
    trick: '14-electron diatomic species (N₂, CO, NO⁺) always have max Bond Order = 3.0. Each electron added or subtracted reduces BO by 0.5!',
    trickHi: '14 इलेक्ट्रॉन प्रजाति (N₂, CO, NO⁺) की आबंध कोटि = 3.0 होती है। प्रत्येक 1 इलेक्ट्रॉन घटने/बढ़ने पर 0.5 कम हो जाती है!',
    sampleEn: 'According to Molecular Orbital Theory, which of the following species has bond order equal to 2.5 and is paramagnetic?',
    sampleHi: 'आणविक कक्षक सिद्धांत के अनुसार, निम्नलिखित में से किसकी आबंध कोटि 2.5 है तथा वह अनुचुंबकीय है?',
    optionsEn: ['O₂⁺ (15 electrons)', 'N₂²⁻ (16 electrons)', 'NO⁻ (16 electrons)', 'CN⁻ (14 electrons)'],
    optionsHi: ['O₂⁺ (15 इलेक्ट्रॉन)', 'N₂²⁻ (16 इलेक्ट्रॉन)', 'NO⁻ (16 इलेक्ट्रॉन)', 'CN⁻ (14 इलेक्ट्रॉन)'],
    correctOption: 0,
    solEn: 'O₂⁺ has 15 electrons. Bond order = 3.0 - 0.5 = 2.5. One unpaired electron in π*2p orbital makes it paramagnetic.',
    solHi: 'O₂⁺ में 15 इलेक्ट्रॉन हैं। आबंध कोटि = 2.5 तथा 1 अयुग्मित इलेक्ट्रॉन के कारण यह अनुचुंबकीय है।',
  },
  {
    id: 'ps-chem-06',
    chapter: 'General Organic Chemistry (GOC) & Acidity Trends',
    chapterHindi: 'सामान्य कार्बनिक रसायन (GOC) एवं अम्लीयता क्रम',
    subject: 'Chemistry',
    weightage: '🔥 12-16 Marks',
    topSubtopics: ['Resonance & Aromaticity (Hückel 4n+2 Rule)', 'Carbocation & Radical Stability', 'Acidity & Basicity Orders', 'Hyperconjugation'],
    topSubtopicsHindi: ['अनुनाद एवं एरोमैटिकता', 'कार्बधनायन स्थायित्व', 'अम्लीयता व क्षारकता', 'अतिसंयुग्मन'],
    formula: 'Acidity ∝ Conjugate Base Stability ∝ -M, -I;  Basicity ∝ +M, +I',
    formulaHi: 'अम्लीयता ∝ संयुग्मी क्षार स्थायित्व ∝ -M प्रभाव',
    trick: 'Orthosubstituted benzoic acids are ALWAYS stronger acids than meta or para due to Ortho Effect (SIR)!',
    trickHi: 'ऑर्थो प्रभाव के कारण ऑर्थो-प्रतिस्थापित बेन्जोइक अम्ल सर्वाधिक अम्लीय होते हैं!',
    sampleEn: 'Which of the following carbocations is most stable?',
    sampleHi: 'निम्नलिखित में से कौन-सा कार्बधनायन सर्वाधिक स्थायी है?',
    optionsEn: ['Tropylium cation (C₇H₇⁺)', 'Triphenylmethyl cation (Ph₃C⁺)', 'tert-Butyl cation ((CH₃)₃C⁺)', 'Allyl cation (CH₂=CH-CH₂⁺)'],
    optionsHi: ['ट्रोपिलियम धनायन (C₇H₇⁺)', 'ट्राइफेनिलमेथिल धनायन (Ph₃C⁺)', 'तृतीयक ब्यूटिल धनायन', 'ऐलिल धनायन'],
    correctOption: 0,
    solEn: 'Tropylium cation (cycloheptatrienyl cation) has (4n + 2) = 6 π electrons in a planar cyclic conjugated ring. It is fully aromatic and exceptionally stable.',
    solHi: 'ट्रोपिलियम धनायन हकल नियम (6π इलेक्ट्रॉन) का पालन करता है तथा एरोमैटिक होने के कारण अत्यधिक स्थायी है।',
  },

  // --- MATHEMATICS (12 High-Yield Chapters) ---
  {
    id: 'ps-math-01',
    chapter: 'Vectors & 3D Analytical Geometry',
    chapterHindi: 'सदिश एवं त्रिविमीय विश्लेषणात्मक ज्यामिति (3D)',
    subject: 'Mathematics',
    weightage: '🔥 16-20 Marks',
    topSubtopics: ['Shortest Distance between Skew Lines', 'Scalar Triple Product', 'Line-Plane Intersection', 'Foot of Perpendicular'],
    topSubtopicsHindi: ['विषमतलीय रेखाओं की न्यूनतम दूरी', 'अदिश त्रिगुणन', 'समतल-रेखा प्रतिच्छेदन', 'लंबपाद'],
    formula: 'd = |(a₂ - a₁) · (b₁ × b₂)| / |b₁ × b₂|;  [a b c] = det(a, b, c)',
    formulaHi: 'न्यूनतम दूरी d = |(a₂ - a₁) · (b₁ × b₂)| / |b₁ × b₂|;  [a b c] = det',
    trick: 'Shortest distance between skew lines appears in EVERY JEE paper. Compute scalar triple product directly in 45s!',
    trickHi: 'न्यूनतम दूरी का प्रश्न प्रतिवर्ष निश्चित आता है। सारणिक से 45 सेकंड में मान निकालें!',
    sampleEn: 'Shortest distance between lines r = (i + 2j + 3k) + λ(2i + 3j + 4k) and r = (2i + 4j + 5k) + μ(3i + 4j + 5k) is:',
    sampleHi: 'रेखाओं r = (i + 2j + 3k) + λ(2i + 3j + 4k) तथा r = (2i + 4j + 5k) + μ(3i + 4j + 5k) के मध्य न्यूनतम दूरी होगी:',
    optionsEn: ['1 / √6', '2 / √6', '1 / 3', '√6'],
    optionsHi: ['1 / √6', '2 / √6', '1 / 3', '√6'],
    correctOption: 0,
    solEn: 'a₂ - a₁ = i + 2j + 2k. b₁ × b₂ = -i + 2j - k. Numerator = |-1 + 4 - 2| = 1. Denominator = √6. d = 1/√6.',
    solHi: 'd = |(1,2,2) · (-1,2,-1)| / √6 = 1 / √6. सही विकल्प A है।',
  },
  {
    id: 'ps-math-02',
    chapter: 'Definite Integrals & Calculus',
    chapterHindi: 'निश्चित समाकलन एवं कलन सिद्धांत',
    subject: 'Mathematics',
    weightage: '🔥 16 Marks Guaranteed',
    topSubtopics: ['King\'s Property', 'Leibnitz Rule', 'Limit of Sum', 'Area Under Curves'],
    topSubtopicsHindi: ['किंग्स प्रॉपर्टी', 'लेबनिज नियम', 'योग की सीमा', 'क्षेत्रफल'],
    formula: '∫[a to b] f(x) dx = ∫[a to b] f(a + b - x) dx;  Area = ∫ (y_upper - y_lower) dx',
    formulaHi: '∫[a to b] f(x) dx = ∫[a to b] f(a + b - x) dx;  क्षेत्रफल = ∫ (y₁ - y₂) dx',
    trick: 'If integrand is f(x) / (f(x) + f(a + b - x)), answer is ALWAYS (b - a) / 2 in 2 seconds!',
    trickHi: 'यदि व्यंजक f(x)/(f(x)+f(a+b-x)) रूप का हो तो उत्तर सदैव (b - a) / 2 होता है!',
    sampleEn: 'Evaluate definite integral I = ∫[0 to π/2] (sin⁴ x) / (sin⁴ x + cos⁴ x) dx:',
    sampleHi: 'निश्चित समाकलन I = ∫[0 से π/2] (sin⁴ x) / (sin⁴ x + cos⁴ x) dx का मान होगा:',
    optionsEn: ['π / 4', 'π / 2', 'π / 8', '0'],
    optionsHi: ['π / 4', 'π / 2', 'π / 8', '0'],
    correctOption: 0,
    solEn: 'By King\'s property, adding both gives 2I = ∫[0 to π/2] 1 dx = π/2 ⇒ I = π/4.',
    solHi: 'किंग्स प्रॉपर्टी लगाने पर 2I = π/2, अतः I = π/4.',
  },
  {
    id: 'ps-math-03',
    chapter: 'Matrices & System of Linear Equations',
    chapterHindi: 'आव्यूह, सारणिक एवं रैखिक समीकरण निकाय',
    subject: 'Mathematics',
    weightage: '🔥 12-16 Marks',
    topSubtopics: ['Cramer Rule & Consistency', 'Adjoint Determinant det(adj A)', 'Matrix Inversion', 'Eigenvalues'],
    topSubtopicsHindi: ['क्रेमर नियम व संगतता', 'det(adj A) गुणधर्म', 'व्युत्क्रम आव्यूह', 'आइगेन मान'],
    formula: 'det(adj A) = (det A)^(n - 1);  det(kA) = k^n det(A);  A · adj(A) = (det A) I',
    formulaHi: 'det(adj A) = (det A)^(n - 1);  det(kA) = k^n det(A)',
    trick: 'For a 3×3 matrix, det(adj A) = (det A)² directly!',
    trickHi: '3×3 आव्यूह के लिए det(adj A) = (det A)² तुरंत याद रखें!',
    sampleEn: 'Let A be a 3 × 3 matrix such that det(A) = 3. What is the value of det(adj(A))?',
    sampleHi: 'माना A एक 3 × 3 आव्यूह है जिसका det(A) = 3 है। det(adj(A)) का मान क्या होगा?',
    optionsEn: ['9', '3', '27', '81'],
    optionsHi: ['9', '3', '27', '81'],
    correctOption: 0,
    solEn: 'det(adj A) = (det A)^(3 - 1) = (det A)² = 3² = 9.',
    solHi: 'det(adj A) = 3² = 9। सही उत्तर A है।',
  },
  {
    id: 'ps-math-04',
    chapter: 'Coordinate Geometry & Conic Sections',
    chapterHindi: 'निर्देशांक ज्यामिति एवं शांकव परिच्छेद',
    subject: 'Mathematics',
    weightage: '⚡ 12-16 Marks',
    topSubtopics: ['Parabola Tangents', 'Ellipse Eccentricity', 'Hyperbola Asymptotes', 'Circles Orthogonality'],
    topSubtopicsHindi: ['परवलय स्पर्श रेखा', 'दीर्घवृत्त उत्केंद्रता', 'अतिपरवलय अनंतस्पर्शी', 'वृत्तों की लंबकोणीयता'],
    formula: 'y = m x + a/m (Parabola);  b² = a²(1 - e²) (Ellipse);  b² = a²(e² - 1) (Hyperbola)',
    formulaHi: 'y = m x + a/m;  दीर्घवृत्त: b² = a²(1 - e²);  अतिपरवलय: b² = a²(e² - 1)',
    trick: 'Condition of tangency y = mx + c to parabola y² = 4ax is c = a/m. To ellipse x²/a² + y²/b² = 1 is c² = a²m² + b².',
    trickHi: 'परवलय स्पर्श शर्त: c = a/m; दीर्घवृत्त स्पर्श शर्त: c² = a²m² + b².',
    sampleEn: 'The eccentricity of the ellipse 4x² + 9y² = 36 is:',
    sampleHi: 'दीर्घवृत्त 4x² + 9y² = 36 की उत्केंद्रता e होगी:',
    optionsEn: ['√5 / 3', '√5 / 2', '2 / 3', '1 / 2'],
    optionsHi: ['√5 / 3', '√5 / 2', '2 / 3', '1 / 2'],
    correctOption: 0,
    solEn: 'Divide by 36: x²/9 + y²/4 = 1 ⇒ a² = 9, b² = 4. e = √(1 - b²/a²) = √(1 - 4/9) = √5 / 3.',
    solHi: 'a² = 9, b² = 4. e = √(1 - 4/9) = √5 / 3। सही उत्तर A है।',
  },
  {
    id: 'ps-math-05',
    chapter: 'Limits, Continuity & Differentiability',
    chapterHindi: 'सीमा, सांतत्य एवं अवकलनीयता',
    subject: 'Mathematics',
    weightage: '🔥 12-16 Marks',
    topSubtopics: ['0/0 & ∞/∞ L\'Hôpital Rule', '1^∞ Standard Form', 'Intermediate Value Theorem', 'Differentiability Corner Points'],
    topSubtopicsHindi: ['एल हॉस्पिटल नियम', '1^∞ मानक सीमा', 'सांतत्य परीक्षण', 'अवकलनीयता'],
    formula: 'lim(x→0) (1 + f(x))^(1/g(x)) = e^(lim f(x)/g(x));  lim(x→0) sin x / x = 1',
    formulaHi: '1^∞ सीमा: e^(lim f(x)/g(x));  lim sin x / x = 1',
    trick: 'For 1^∞ form, convert immediately to e^(lim (base - 1) × power) in one step!',
    trickHi: '1^∞ रूप मिलते ही e^(lim (आधार - 1) × घात) से 10 सेकंड में हल करें!',
    sampleEn: 'Evaluate the limit L = lim(x→0) (cos x)^(1 / x²):',
    sampleHi: 'सीमा L = lim(x→0) (cos x)^(1 / x²) का मान ज्ञात कीजिए:',
    optionsEn: ['e^(-1/2)', 'e^(1/2)', 'e^(-1)', '1'],
    optionsHi: ['e^(-1/2)', 'e^(1/2)', 'e^(-1)', '1'],
    correctOption: 0,
    solEn: 'Form 1^∞. L = e^(lim(x→0) (cos x - 1) / x²) = e^(lim(x→0) (-2 sin²(x/2)) / x²) = e^(-1/2).',
    solHi: '1^∞ रूप: L = e^(lim (cos x - 1)/x²) = e^(-1/2)। सही विकल्प A है।',
  },
  {
    id: 'ps-math-06',
    chapter: 'Complex Numbers & Quadratic Equations',
    chapterHindi: 'सम्मिश्र संख्याएँ एवं द्विघात समीकरण',
    subject: 'Mathematics',
    weightage: '🔥 12-16 Marks',
    topSubtopics: ['Cube Roots of Unity (1, ω, ω²)', 'De Moivre Theorem', 'Locus in Argand Plane |z - z₀| = r', 'Common Roots Condition'],
    topSubtopicsHindi: ['इकाई के घनमूल', 'डी मोइवर प्रमेय', 'आर्गंड तल पर बिंदुपथ', 'उभयनिष्ठ मूल'],
    formula: '1 + ω + ω² = 0, ω³ = 1;  |z - z₁| / |z - z₂| = k (Circle if k≠1);  e^(iθ) = cos θ + i sin θ',
    formulaHi: '1 + ω + ω² = 0, ω³ = 1;  |z - z₁| = r (वृत्त)',
    trick: 'If |z - z₁| = |z - z₂|, locus of z is always the perpendicular bisector of segment joining z₁ and z₂!',
    trickHi: '|z - z₁| = |z - z₂| का बिंदुपथ सदैव दोनों बिंदुओं को मिलाने वाले रेखाखंड का लंब समद्विभाजक होता है!',
    sampleEn: 'If ω is a complex cube root of unity, then the value of (1 - ω + ω²)⁵ + (1 + ω - ω²)⁵ is:',
    sampleHi: 'यदि ω इकाई का काल्पनिक घनमूल है, तो (1 - ω + ω²)⁵ + (1 + ω - ω²)⁵ का मान होगा:',
    optionsEn: ['32', '-32', '64', '-64'],
    optionsHi: ['32', '-32', '64', '-64'],
    correctOption: 0,
    solEn: 'Since 1 + ω² = -ω: (1 - ω + ω²) = -2ω ⇒ (-2ω)⁵ = -32 ω² (as ω⁵ = ω²). Similarly, 1 + ω = -ω² ⇒ (-2ω²)⁵ = -32 ω⁴ = -32 ω. Sum = -32(ω² + ω) = -32(-1) = 32.',
    solHi: '1 + ω² = -ω रखने पर: (-2ω)⁵ + (-2ω²)⁵ = -32(ω² + ω) = -32(-1) = 32।',
  },
];

// Build all chapter practice sheets (each with exactly 20 bilingual questions with distinct options and balanced answers)
export const chapterPracticeSheets: PYQSheetItem[] = allChaptersMeta.map((meta) => {
  return {
    id: `sheet-${meta.id}`,
    chapter: `${meta.chapter} (20 Qs Practice Sheet)`,
    chapterHindi: `${meta.chapterHindi} (20 प्रश्न अभ्यास शीट)`,
    subject: meta.subject,
    yearCoverage: '2010–2026',
    questionsCount: 20,
    totalMarks: 80,
    topSubtopics: meta.topSubtopics,
    topSubtopicsHindi: meta.topSubtopicsHindi,
    exemplarQuestions: get20QuestionsForChapter(meta),
  };
});

// Convert all chapter practice sheets into interactive BookItems for the Library
export const chapterPracticeSheetsAsBooks: BookItem[] = chapterPracticeSheets.map((sheet) => {
  const isPhy = sheet.subject === 'Physics';
  const isChem = sheet.subject === 'Chemistry';

  const coverGradient = isPhy
    ? 'from-blue-700 via-indigo-800 to-slate-900'
    : isChem
    ? 'from-emerald-700 via-teal-800 to-slate-900'
    : 'from-violet-700 via-purple-900 to-slate-900';

  const q1 = sheet.exemplarQuestions[0];

  return {
    id: `book-sheet-${sheet.id}`,
    title: `${sheet.chapterHindi} [20 Solved PYQs PDF]`,
    author: `JEEPulse Academic Team · 2010–2026 Official Archive`,
    subject: sheet.subject,
    category: 'PYQ Practice Sheet',
    totalPages: 24,
    rating: 4.98,
    questionCount: 20,
    yearCoverage: '2010 – 2026',
    coverColor: coverGradient,
    description: `Official chapter practice sheet in PDF format: 20 curated authentic past questions for ${sheet.chapter} with complete bilingual solutions (Hindi & English), key formula sheets, and Kota AIR shortcuts.`,
    chapters: [
      `1. Full 20 Solved Questions PDF Sheet (${sheet.chapter})`,
      `2. Step-by-Step Derivations & Verified Answer Key (Bilingual)`,
      `3. Kota AIR Speed Hacks & High-Yield Formulas`,
    ],
    sampleContent: `# ${sheet.chapter} — 20 Solved PYQ Practice Sheet (Bilingual)
## विषय / Subject: ${sheet.subject} | वर्ष कवरेज: 2010 – 2026 | कुल अंक: 80 (+4 / -1 Marking)

### 📌 प्रमुख उपविषय / High-Yield Subtopics:
${sheet.topSubtopics.map((t, idx) => `${idx + 1}. ${t} (${sheet.topSubtopicsHindi[idx] || t})`).join('\n')}

---

### [Sample Question 1 from 20-Question Sheet]
**[EN]** ${q1.questionEn}
**[HI]** ${q1.questionHi}

**Options:**
- (A) ${q1.optionsEn[0]} | [HI] ${q1.optionsHi[0]}
- (B) ${q1.optionsEn[1]} | [HI] ${q1.optionsHi[1]}
- (C) ${q1.optionsEn[2]} | [HI] ${q1.optionsHi[2]}
- (D) ${q1.optionsEn[3]} | [HI] ${q1.optionsHi[3]}

**Correct Answer:** Option (${['A', 'B', 'C', 'D'][q1.correctOption]})

**[EN Solution]:**
${q1.solutionEn}

**[HI हल]:**
${q1.solutionHi}

💡 **Kota Ranker Hack:** ${q1.topperTrickEn}
`,
    exemplarQuestions: sheet.exemplarQuestions,
  };
});
