import { TestCatalogItem } from './generateTestQuestions';
export type { TestCatalogItem };

// Core topics configuration for systematic 1000-test generation
interface TopicMeta {
  chapter: string;
  chapterHindi: string;
  subject: 'Physics' | 'Chemistry' | 'Mathematics';
  weightageTag: string;
  weightageTagHindi: string;
  expectedMarks: string;
  highYieldTips: string;
  highYieldTipsHindi: string;
}

const highYieldTopics: TopicMeta[] = [
  // PHYSICS (High ROI)
  {
    chapter: 'Modern Physics & Dual Nature',
    chapterHindi: 'आधुनिक भौतिकी एवं विकिरण की द्वैत प्रकृति',
    subject: 'Physics',
    weightageTag: '🔥 16-20 Marks Guaranteed',
    weightageTagHindi: '🔥 16-20 अंक पक्के',
    expectedMarks: '16 Marks',
    highYieldTips: 'High-yield: De Broglie wavelength λ = h/p and photoelectric equation solve 80% of questions in <60 seconds.',
    highYieldTipsHindi: 'उच्च-अंक: दे ब्रॉग्ली तरंगदैर्घ्य λ = h/p व प्रकाश वैद्युत समीकरण से 80% प्रश्न 60 सेकंड में हल होते हैं।',
  },
  {
    chapter: 'Rotational Motion & Dynamics',
    chapterHindi: 'घूर्णन गति एवं दृढ़ पिंड गतिकी',
    subject: 'Physics',
    weightageTag: '🔥 12-16 Marks · Top Weightage',
    weightageTagHindi: '🔥 12-16 अंक · उच्च वेटेज',
    expectedMarks: '16 Marks',
    highYieldTips: 'Pure rolling condition a_com = g sin θ / (1 + k²/R²). Memorize cylinder (2/3), sphere (5/7) to save 3 minutes.',
    highYieldTipsHindi: 'शुद्ध लोटनी गति: बेलन (2/3) व गोले (5/7) के अनुपात याद रखें, 3 मिनट की बचत होगी।',
  },
  {
    chapter: 'Electrodynamics & Capacitors',
    chapterHindi: 'विद्युत चुंबकत्व एवं संधारित्र परिपथ',
    subject: 'Physics',
    weightageTag: '🔥 16-20 Marks Guaranteed',
    weightageTagHindi: '🔥 16-20 अंक पक्के',
    expectedMarks: '20 Marks',
    highYieldTips: 'Capacitor with dielectric: C = k·C₀. In RC charging circuit q(t) = Q₀(1 - e^(-t/RC)), direct formula yields instant 4 marks.',
    highYieldTipsHindi: 'परावैद्युत युक्त संधारित्र व RC परिपथ के सीधे सूत्र याद रखें, तुरंत 4 अंक प्राप्त करें।',
  },
  {
    chapter: 'Thermodynamics & Heat Transfer',
    chapterHindi: 'ऊष्मागतिकी एवं ऊष्मा संचरण',
    subject: 'Physics',
    weightageTag: '⚡ 12-16 Marks · Fast-Score',
    weightageTagHindi: '⚡ 12-16 अंक · तीव्र स्कोर',
    expectedMarks: '16 Marks',
    highYieldTips: 'Carnot efficiency η = 1 - T₂/T₁ and adiabatic work W = (P₁V₁ - P₂V₂)/(γ - 1). Guaranteed predictable questions.',
    highYieldTipsHindi: 'कार्नो दक्षता व रुद्धोष्म कार्य के सूत्र से हर वर्ष निश्चित प्रश्न आते हैं।',
  },
  {
    chapter: 'Optics & Wave Interference',
    chapterHindi: 'प्रकाशिकी एवं तरंग व्यतिकरण (YDSE)',
    subject: 'Physics',
    weightageTag: '🎯 12 Marks · Predictable Pattern',
    weightageTagHindi: '🎯 12 अंक · सुनिश्चित पैटर्न',
    expectedMarks: '12 Marks',
    highYieldTips: 'YDSE fringe shift Δy = (μ - 1)t D/d and lens maker formula 1/f = (μ - 1)(1/R₁ - 1/R₂).',
    highYieldTipsHindi: 'YDSE फ्रिंज विस्थापन व लेंस निर्माता सूत्र से सीधे 4 अंक प्राप्त करें।',
  },
  {
    chapter: 'Current Electricity & Circuits',
    chapterHindi: 'धारा विद्युत एवं परिपथ विश्लेषण',
    subject: 'Physics',
    weightageTag: '⚡ 12 Marks · High Speed',
    weightageTagHindi: '⚡ 12 अंक · उच्च गति',
    expectedMarks: '12 Marks',
    highYieldTips: 'Nodal voltage analysis eliminates lengthy Kirchhoff loop equations in 45 seconds.',
    highYieldTipsHindi: 'नोडल वोल्टता विधि से किरचॉफ के लंबे समीकरण 45 सेकंड में हल हो जाते हैं।',
  },

  // CHEMISTRY (High ROI)
  {
    chapter: 'Coordination Compounds & Bonding',
    chapterHindi: 'उपसहसंयोजन यौगिक एवं आबंधन',
    subject: 'Chemistry',
    weightageTag: '🔥 16-20 Marks Guaranteed',
    weightageTagHindi: '🔥 16-20 अंक पक्के',
    expectedMarks: '16 Marks',
    highYieldTips: 'CFT splitting: strong field ligands cause pairing (t2g vs eg). Magnetic moment μ = √(n(n+2)) BM in 30 seconds.',
    highYieldTipsHindi: 'CFT क्रिस्टल क्षेत्र सिद्धांत: प्रबल क्षेत्र लिगैंड युग्मन कराते हैं। चुंबकीय आघूर्ण 30 सेकंड में निकालें।',
  },
  {
    chapter: 'Organic Reaction Mechanisms & Carbonyls',
    chapterHindi: 'कार्बनिक अभिक्रिया क्रियाविधि एवं कार्बोनिल यौगिक',
    subject: 'Chemistry',
    weightageTag: '🔥 20+ Marks · Highest Weightage',
    weightageTagHindi: '🔥 20+ अंक · सर्वाधिक वेटेज',
    expectedMarks: '24 Marks',
    highYieldTips: 'Aldol condensation (enolate attack) & Cannizzaro for non-enolizable aldehydes. 100% predictable in JEE.',
    highYieldTipsHindi: 'एल्डोल संघनन एवं कैनिजारो अभिक्रिया से प्रतिवर्ष 2 से 3 प्रश्न निश्चित आते हैं।',
  },
  {
    chapter: 'Electrochemistry & Solutions',
    chapterHindi: 'विद्युत रसायन एवं विलयन',
    subject: 'Chemistry',
    weightageTag: '🔥 16 Marks Guaranteed',
    weightageTagHindi: '🔥 16 अंक पक्के',
    expectedMarks: '16 Marks',
    highYieldTips: 'Nernst Eq E = E° - (0.0591/n) log Q. Colligative property ΔTb = i·Kb·m. Watch Van\'t Hoff factor i!',
    highYieldTipsHindi: 'नेर्नस्ट समीकरण व अणुसंख्य गुणधर्म: वांट हॉफ गुणक i का सही प्रयोग तुरंत सही उत्तर देता है।',
  },
  {
    chapter: 'Chemical Kinetics & Equilibrium',
    chapterHindi: 'रासायनिक बलगतिकी एवं साम्यावस्था',
    subject: 'Chemistry',
    weightageTag: '⚡ 12-16 Marks · Calculation Friendly',
    weightageTagHindi: '⚡ 12-16 अंक · गणना अनुकूल',
    expectedMarks: '16 Marks',
    highYieldTips: 'First-order kinetics t_1/2 = 0.693/k is independent of initial concentration. Arrhenius log(k₂/k₁) = Ea/2.303R(1/T₁ - 1/T₂).',
    highYieldTipsHindi: 'प्रथम कोटि अभिक्रिया की अर्ध-आयु प्रारंभिक सांद्रता पर निर्भर नहीं करती, त्वरित गणना संभव है।',
  },
  {
    chapter: 'Chemical Bonding & Molecular Orbitals',
    chapterHindi: 'रासायनिक आबंधन एवं आण्विक कक्षक सिद्धांत (MOT)',
    subject: 'Chemistry',
    weightageTag: '🎯 12-16 Marks · Conceptual High Yield',
    weightageTagHindi: '🎯 12-16 अंक · अवधारणा उच्च अंक',
    expectedMarks: '16 Marks',
    highYieldTips: 'MOT bond order = (Nb - Na)/2. Super trick: 14 electrons = bond order 3.0, each e⁻ diff changes by 0.5.',
    highYieldTipsHindi: 'MOT बॉन्ड ऑर्डर ट्रिक: 14 इलेक्ट्रॉन = 3.0, प्रत्येक इलेक्ट्रॉन बदलने पर 0.5 का अंतर आता है।',
  },

  // MATHEMATICS (High ROI)
  {
    chapter: 'Vectors & 3D Geometry',
    chapterHindi: 'सदिश बीजगणित एवं त्रिविमीय ज्यामिति (3D)',
    subject: 'Mathematics',
    weightageTag: '🔥 16-20 Marks · Highest Math ROI',
    weightageTagHindi: '🔥 16-20 अंक · गणित का सर्वोच्च वेटेज',
    expectedMarks: '20 Marks',
    highYieldTips: 'Shortest distance between skew lines d = |(a₂ - a₁) · (b₁ × b₂)| / |b₁ × b₂|. Guaranteed 2 questions every paper!',
    highYieldTipsHindi: 'विषमतलीय रेखाओं के मध्य न्यूनतम दूरी का सूत्र याद रखें, प्रतिवर्ष 8 अंक पक्के मिलते हैं।',
  },
  {
    chapter: 'Definite Integration & Area Under Curves',
    chapterHindi: 'निश्चित समाकलन एवं वक्रों से घिरा क्षेत्रफल',
    subject: 'Mathematics',
    weightageTag: '🔥 16 Marks Guaranteed',
    weightageTagHindi: '🔥 16 अंक पक्के',
    expectedMarks: '16 Marks',
    highYieldTips: 'King\'s Property: ∫[a to b] f(x) dx = ∫[a to b] f(a+b-x) dx. Leibniz rule for differentiation under integral sign.',
    highYieldTipsHindi: 'किंग्स प्रॉपर्टी: f(x) को f(a+b-x) से बदलकर जोड़ने पर 80% समाकल 30 सेकंड में शून्य या सरल हो जाते हैं।',
  },
  {
    chapter: 'Matrices & Determinants',
    chapterHindi: 'आव्यूह एवं सारणिक (रैखिक समीकरण निकाय)',
    subject: 'Mathematics',
    weightageTag: '⚡ 12-16 Marks · Direct Score',
    weightageTagHindi: '⚡ 12-16 अंक · सीधा स्कोर',
    expectedMarks: '16 Marks',
    highYieldTips: 'Cramer\'s rule: Δ = 0 with Δx = Δy = Δz = 0 implies infinite solutions. Direct rank and characteristic equation.',
    highYieldTipsHindi: 'क्रेमर नियम व आव्यूह के गुणधर्म से समीकरण निकाय के प्रश्न न्यूनतम समय में हल होते हैं।',
  },
  {
    chapter: 'Differential Equations',
    chapterHindi: 'अवकल समीकरण (रैखिक एवं समघाती रूप)',
    subject: 'Mathematics',
    weightageTag: '⚡ 12 Marks · Predictable Step-by-Step',
    weightageTagHindi: '⚡ 12 अंक · सुनिश्चित चरण',
    expectedMarks: '12 Marks',
    highYieldTips: 'Linear D.E. dy/dx + P y = Q: Integrating factor I.F. = e^(∫P dx), solution y · I.F. = ∫(Q · I.F.) dx + C.',
    highYieldTipsHindi: 'प्रथम कोटि रैखिक अवकल समीकरण में समाकलन गुणक (I.F.) सीधे निकालें और तुरंत हल पाएं।',
  },
  {
    chapter: 'Conic Sections & Common Tangents',
    chapterHindi: 'शांकव परिच्छेद एवं उभयनिष्ठ स्पर्श रेखाएं',
    subject: 'Mathematics',
    weightageTag: '🎯 16 Marks · Advanced Favorite',
    weightageTagHindi: '🎯 16 अंक · एडवांस्ड का पसंदीदा',
    expectedMarks: '16 Marks',
    highYieldTips: 'Condition of tangency: y = mx + c. Parabola c = a/m; Circle c² = r²(1 + m²); Ellipse c² = a²m² + b².',
    highYieldTipsHindi: 'स्पर्श रेखा की प्रतिबंधक स्थितियाँ याद रखें, उभयनिष्ठ स्पर्श रेखा 20 सेकंड में निकलती है।',
  },
];

// Helper to generate the exact 1000 tests registry with deterministic metadata
const generate1000TestsCatalog = (): TestCatalogItem[] => {
  const tests: TestCatalogItem[] = [];

  for (let num = 1; num <= 1000; num++) {
    const id = `test-${num.toString().padStart(4, '0')}`;
    let category: TestCatalogItem['category'];
    let subject: TestCatalogItem['subject'];
    let examType: TestCatalogItem['examType'] = num % 4 === 0 ? 'JEE Advanced' : 'JEE Main';
    let difficulty: TestCatalogItem['difficulty'] = 'Hard / IIT Advanced Level';
    let chapter = '';
    let chapterHindi = '';
    let weightageTag = '';
    let weightageTagHindi = '';
    let highYieldTips = '';
    let highYieldTipsHindi = '';
    let title = '';
    let titleHindi = '';
    let isChapterTest = true;

    // TRACK 1: Tests 1 - 250 -> 🔥 High-Yield Super Score Series (Most Weightage Topics)
    if (num <= 250) {
      category = 'high_yield_ranker';
      const topicMeta = highYieldTopics[(num - 1) % highYieldTopics.length];
      subject = topicMeta.subject;
      chapter = topicMeta.chapter;
      chapterHindi = topicMeta.chapterHindi;
      weightageTag = topicMeta.weightageTag;
      weightageTagHindi = topicMeta.weightageTagHindi;
      highYieldTips = topicMeta.highYieldTips;
      highYieldTipsHindi = topicMeta.highYieldTipsHindi;
      difficulty = num % 3 === 0 ? 'JEE Advanced Paper-1' : 'Hard / IIT Advanced Level';
      examType = num % 3 === 0 ? 'JEE Advanced' : 'JEE Main';
      
      const subNumber = Math.floor((num - 1) / highYieldTopics.length) + 1;
      title = `Test #${num.toString().padStart(3, '0')}: ${chapter} · 75-Q High-Yield Drill [Part ${subNumber}]`;
      titleHindi = `टेस्ट #${num.toString().padStart(3, '0')}: ${chapterHindi} · 75-प्रश्न उच्च-अंक अभ्यास [भाग ${subNumber}]`;
    }
    // TRACK 2: Tests 251 - 600 -> 🎯 Chapter-Wise Hard & Advanced Drills (350 Tests)
    else if (num <= 600) {
      category = 'chapter';
      const topicMeta = highYieldTopics[(num - 251) % highYieldTopics.length];
      subject = topicMeta.subject;
      chapter = topicMeta.chapter;
      chapterHindi = topicMeta.chapterHindi;
      weightageTag = '🎯 Chapter Deep-Dive · Hard 75-Q';
      weightageTagHindi = '🎯 अध्याय गहन अभ्यास · कठिन 75-प्रश्न';
      highYieldTips = `Solve this 75-question drill to master every concept and trap tested in JEE from 2010 to 2026.`;
      highYieldTipsHindi = `2010 से 2026 तक पूछे गए सभी कठिन प्रारूपों को हल करके अध्याय में 100% सटीकता हासिल करें।`;
      difficulty = num % 2 === 0 ? 'Hard / IIT Advanced Level' : 'High Rank Predictor';
      examType = num % 2 === 0 ? 'JEE Advanced' : 'JEE Main';

      const drillNum = num - 250;
      title = `Test #${num}: ${chapter} · Advanced Chapter Mastery (75 Questions · Set ${drillNum})`;
      titleHindi = `टेस्ट #${num}: ${chapterHindi} · एडवांस्ड अध्याय महारथ (75 प्रश्न · सेट ${drillNum})`;
    }
    // TRACK 3: Tests 601 - 750 -> ⚡ JEE Advanced Rank Booster Super Tests (150 Tests)
    else if (num <= 750) {
      category = 'hard_advanced';
      const topicMeta = highYieldTopics[(num - 601) % highYieldTopics.length];
      subject = topicMeta.subject;
      chapter = `${topicMeta.chapter} & Multi-Concept Links`;
      chapterHindi = `${topicMeta.chapterHindi} व बहु-अवधारणा संयोजन`;
      weightageTag = '⚡ JEE Advanced Rank Booster · Elite Hard';
      weightageTagHindi = '⚡ जेईई एडवांस्ड रैंक बूस्टर · शीर्ष स्तर';
      highYieldTips = 'Strict negative marking (-1). Focus on identifying solvable questions first and eliminate wrong options via limits/dimensions.';
      highYieldTipsHindi = 'ऋणात्मक अंकन से बचें। पहले सरल व मध्यम प्रश्नों को पहचानें और सीमा/विमा से विकल्प निष्कासित करें।';
      difficulty = 'JEE Advanced Paper-1';
      examType = 'JEE Advanced';

      const advNum = num - 600;
      title = `Test #${num}: JEE Advanced Elite 75-Q Rank Booster · Series ${advNum} (${chapter})`;
      titleHindi = `टेस्ट #${num}: जेईई एडवांस्ड एलीट 75-प्रश्न रैंक बूस्टर · सीरीज ${advNum} (${chapterHindi})`;
    }
    // TRACK 4: Tests 751 - 900 -> 📅 2010–2026 Shift-Wise Full Syllabus CBT Mocks (150 Tests)
    else if (num <= 900) {
      category = 'grand_mock';
      subject = 'All Subjects';
      isChapterTest = false;
      const targetYear = 2026 - ((num - 751) % 17);
      const shift = ((num - 751) % 2) + 1;
      chapter = `Full Syllabus (Physics + Chemistry + Math)`;
      chapterHindi = `संपूर्ण पाठ्यक्रम (भौतिकी + रसायन + गणित)`;
      weightageTag = `📅 ${targetYear} Shift-${shift} Full NTA Mock`;
      weightageTagHindi = `📅 ${targetYear} शिफ्ट-${shift} संपूर्ण NTA मॉक`;
      highYieldTips = 'Time strategy: 45m Chem, 50m Phy, 65m Math, 20m revision. Targeting 200+ marks in 180 minutes.';
      highYieldTipsHindi = 'समय रणनीति: 45 मि रसायन, 50 मि भौतिकी, 65 मि गणित, 20 मि पुनरीक्षण। 200+ अंक का लक्ष्य।';
      difficulty = num % 3 === 0 ? 'JEE Advanced Paper-1' : 'Hard / IIT Advanced Level';
      examType = num % 3 === 0 ? 'JEE Advanced' : 'JEE Main';

      title = `Test #${num}: JEE ${targetYear} Shift-${shift} Grand CBT Mock (75 Qs · 300 Marks)`;
      titleHindi = `टेस्ट #${num}: जेईई ${targetYear} शिफ्ट-${shift} संपूर्ण CBT मॉक (75 प्रश्न · 300 अंक)`;
    }
    // TRACK 5: Tests 901 - 1000 -> 🧠 Topper's Speed & Tricky Traps Marathon (100 Tests)
    else {
      category = 'tricky_traps';
      const topicMeta = highYieldTopics[(num - 901) % highYieldTopics.length];
      subject = topicMeta.subject;
      chapter = topicMeta.chapter;
      chapterHindi = topicMeta.chapterHindi;
      weightageTag = '🧠 Tricky Traps & Speed Drill';
      weightageTagHindi = '🧠 कठिन जाल व गति अभ्यास';
      highYieldTips = 'Topper tip: Read questions with negative words ("NOT", "INCORRECT") carefully. Use dimensional elimination in <15s.';
      highYieldTipsHindi: 'टॉपर सलाह: "नहीं" या "गलत" शब्दों वाले प्रश्नों को ध्यान से पढ़ें। विमा निष्कासन से 15 सेकंड में उत्तर पाएं।';
      difficulty = 'Hard / IIT Advanced Level';
      examType = 'JEE Main';

      const trapNum = num - 900;
      title = `Test #${num}: Topper's Speed & Negative Marking Prevention Drill #${trapNum} (${chapter})`;
      titleHindi = `टेस्ट #${num}: टॉपर गति व ऋणात्मक अंक बचाव अभ्यास #${trapNum} (${chapterHindi})`;
    }

    tests.push({
      id,
      testNumber: num,
      title,
      titleHindi,
      subject,
      chapter,
      chapterHindi,
      examType,
      durationMinutes: 180,
      totalQuestions: 75,
      totalMarks: 300,
      difficulty,
      category,
      weightageTag,
      weightageTagHindi,
      highYieldTips,
      highYieldTipsHindi,
      description: `Rigorous 75-question test with authentic +4 / -1 JEE scoring scheme. Contains high-yield concepts from 2010 to 2026 curated to maximize marks in minimal time. Includes step-by-step derivations and topper tricks in both English and Hindi.`,
      descriptionHindi: `प्रामाणिक +4 / -1 जेईई अंकन योजना के साथ 75 प्रश्नों का गहन टेस्ट। न्यूनतम समय में अधिकतम अंक प्राप्त करने के लिए 2010 से 2026 के उच्च-अंक विषय। अंग्रेजी व हिंदी दोनों में चरणबद्ध हल व टॉपर शॉर्टकट ट्रिक सम्मिलित।`,
      isChapterTest,
      yearRange: '2010–2026',
    });
  }

  return tests;
};

// Singleton 1000 tests catalog
export const ALL_1000_TESTS: TestCatalogItem[] = generate1000TestsCatalog();

/**
 * Filter and search the 1000 tests catalog
 */
export const queryTestsCatalog = (options: {
  searchQuery?: string;
  category?: string;
  subject?: string;
  page?: number;
  pageSize?: number;
}): {
  tests: TestCatalogItem[];
  totalCount: number;
  totalPages: number;
  currentPage: number;
} => {
  const { searchQuery = '', category = 'all', subject = 'All', page = 1, pageSize = 18 } = options;

  let filtered = ALL_1000_TESTS;

  // Filter by Category
  if (category && category !== 'all') {
    filtered = filtered.filter(t => t.category === category);
  }

  // Filter by Subject
  if (subject && subject !== 'All') {
    filtered = filtered.filter(t => t.subject === subject || t.subject === 'All Subjects');
  }

  // Filter by Search Query (supports "142", "#142", "Modern Physics", "Vectors", etc.)
  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase().trim();
    // Check if user typed test number like "142" or "#142" or "test 142"
    const numMatch = q.match(/\d+/);
    const targetNum = numMatch ? parseInt(numMatch[0], 10) : null;

    filtered = filtered.filter(t => {
      if (targetNum !== null && t.testNumber === targetNum) return true;
      return (
        t.title.toLowerCase().includes(q) ||
        t.titleHindi.toLowerCase().includes(q) ||
        t.chapter.toLowerCase().includes(q) ||
        t.chapterHindi.toLowerCase().includes(q) ||
        t.weightageTag.toLowerCase().includes(q) ||
        t.id.toLowerCase().includes(q)
      );
    });
  }

  const totalCount = filtered.length;
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));
  const validPage = Math.min(Math.max(1, page), totalPages);
  const start = (validPage - 1) * pageSize;
  const tests = filtered.slice(start, start + pageSize);

  return {
    tests,
    totalCount,
    totalPages,
    currentPage: validPage,
  };
};

/**
 * Quick access to find a test by ID or Number
 */
export const getCatalogTestByIdOrNumber = (identifier: string | number): TestCatalogItem | undefined => {
  if (typeof identifier === 'number') {
    return ALL_1000_TESTS.find(t => t.testNumber === identifier);
  }
  const num = parseInt(identifier.replace(/\D/g, ''), 10);
  if (!isNaN(num)) {
    const byNum = ALL_1000_TESTS.find(t => t.testNumber === num);
    if (byNum) return byNum;
  }
  return ALL_1000_TESTS.find(t => t.id === identifier);
};
