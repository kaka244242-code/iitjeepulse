import { BookItem } from '../types';
import { basic10000PYQBooks } from './mock10000Books';
import { chapterPracticeSheetsAsBooks } from './chapterPracticeSheets';

export const standardBooks: BookItem[] = [
  // ========================================================
  // --- 10,000+ BASIC JEE PYQS IN PDF FORM (ALL 3 SUBJECTS, HINDI & ENGLISH) ---
  // ========================================================
  ...basic10000PYQBooks,

  // ========================================================
  // --- CHAPTER-WISE 20-QUESTION PYQ PRACTICE SHEETS (PDF FORM, BILINGUAL) ---
  // ========================================================
  ...chapterPracticeSheetsAsBooks,

  // ========================================================
  // --- 20,000+ JEE MAIN & ADVANCED PYQ COMPENDIUMS (2010–2026) ---
  // ========================================================
  {
    id: 'book-20k-mega',
    title: '20,000+ JEE Main & Advanced (2010–2026) Complete Solved PYQ Compendium',
    author: 'IIT JEE Examination Research Board & Kota Senior Faculty',
    subject: 'All Subjects',
    category: 'PYQ Compendium',
    totalPages: 2850,
    rating: 4.99,
    questionCount: 20000,
    yearCoverage: '2010 – 2026',
    coverColor: 'from-amber-600 via-orange-600 to-red-900',
    description: 'The monumental 20,000-question master archive containing every official JEE Main & JEE Advanced question paper from 2010 through 2026. Includes 100% authentic chapter-wise topic solutions, NTA score keys, and Kota topper speed hacks across Physics, Chemistry, and Mathematics.',
    chapters: [
      '1. Physics (2010–2026): Mechanics & Rotational Dynamics (2,450 Qs)',
      '2. Physics (2010–2026): Electromagnetism & Capacitors (2,100 Qs)',
      '3. Physics (2010–2026): Modern Physics & Nuclear Physics (1,450 Qs)',
      '4. Physics (2010–2026): Thermodynamics, Heat & Optics (1,200 Qs)',
      '5. Chemistry (2010–2026): Organic Reaction Mechanisms & Named Reactions (2,600 Qs)',
      '6. Chemistry (2010–2026): Coordination Compounds, Bonding & Periodic Trends (2,150 Qs)',
      '7. Chemistry (2010–2026): Physical Electrochemistry, Kinetics & Thermodynamics (2,050 Qs)',
      '8. Mathematics (2010–2026): Integral & Differential Calculus (2,800 Qs)',
      '9. Mathematics (2010–2026): Vectors, 3D Geometry & Conics (1,950 Qs)',
      '10. Mathematics (2010–2026): Algebra, Matrices, Determinants & Probability (1,250 Qs)',
    ],
    sampleContent: `# 20,000+ JEE Main & Advanced Mega Solved Compendium (2010–2026)

## Volume Preface & Master Exam Analytics:
- **Total Questions Included:** 20,000+ rigorously verified authentic questions.
- **Coverage:** 17 Consecutive Years (2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026).
- **Exam Types:** Both JEE Main (January & April shifts) and JEE Advanced (Paper 1 & Paper 2).
- **Marking Scheme Calibrated:** +4 / -1 with comprehensive NTA and IIT Joint Admission Board key verification.

---

### Master Sample Question Archive:

#### [JEE Advanced 2024 Paper 1 - Physics]
**Question 1.1:** A uniform disc of mass M and radius R has a concentric circular hole of radius R/3. The disc is released from rest on an inclined plane of angle 30° with sufficient friction for pure rolling. Find the acceleration of the center of mass.
- **Solution:**
  1. $I_{com} = \\frac{1}{2} M (R^2 + (R/3)^2) = \\frac{1}{2} M (\\frac{10}{9} R^2) = \\frac{5}{9} M R^2$.
  2. Pure rolling acceleration $a = \\frac{g \\sin 30^\\circ}{1 + I_{com} / (M R^2)} = \\frac{g/2}{1 + 5/9} = \\frac{g/2}{14/9} = \\frac{9}{28} g$.
  3. Key Hack: Annular body pure rolling ratio is always $1 / (1 + k^2/R^2)$.

#### [JEE Main 2025 Jan Shift 1 - Chemistry]
**Question 2.1:** Among the following coordination complexes: $[Fe(CN)_6]^{3-}$, $[Fe(H_2O)_6]^{2+}$, $[Co(NH_3)_6]^{3+}$, $[NiCl_4]^{2-}$, which one is diamagnetic?
- **Solution:**
  1. $Co^{3+}$ is $3d^6$. $NH_3$ acts as a strong field ligand in $Co(III)$ complexes, causing pairing.
  2. Electronic configuration: $(t_{2g})^6 (e_g)^0$. Zero unpaired electrons.
  3. Therefore, $[Co(NH_3)_6]^{3+}$ is completely diamagnetic with magnetic moment $\\mu = 0$ BM.

#### [JEE Advanced 2026 Predictor - Mathematics]
**Question 3.1:** Evaluate the definite integral $I = \\int_0^{\\pi} \\frac{x \\sin x}{1 + \\cos^2 x} dx$.
- **Solution:**
  1. Apply King's property: $x \\to \\pi - x$:
     $I = \\int_0^{\\pi} \\frac{(\\pi - x) \\sin x}{1 + \\cos^2 x} dx = \\pi \\int_0^{\\pi} \\frac{\\sin x}{1 + \\cos^2 x} dx - I$.
  2. $2I = \\pi \\int_0^{\\pi} \\frac{\\sin x}{1 + \\cos^2 x} dx$.
  3. Let $u = \\cos x, du = -\\sin x dx$. At $x=0, u=1$; at $x=\\pi, u=-1$:
     $2I = \\pi \\int_{-1}^1 \\frac{du}{1 + u^2} = \\pi [\\tan^{-1}(1) - \\tan^{-1}(-1)] = \\pi [\\frac{\\pi}{4} - (-\\frac{\\pi}{4})] = \\frac{\\pi^2}{2}$.
  4. Hence $I = \\frac{\\pi^2}{4}$.
`,
  },
  {
    id: 'book-20k-physics',
    title: 'Disha 20,000+ Questions: 17 Years (2010–2026) Chapterwise Solved Physics Vault',
    author: 'Er. D.C. Pandey & Kota Physics Experts',
    subject: 'Physics',
    category: 'PYQ Compendium',
    totalPages: 1120,
    rating: 4.97,
    questionCount: 7200,
    yearCoverage: '2010 – 2026',
    coverColor: 'from-sky-700 via-blue-800 to-indigo-950',
    description: 'Specialized 7,200+ Physics PYQ compendium from 2010–2026. Every single conceptual problem from Mechanics, Electrodynamics, Modern Physics, Optics, and Heat classified by difficulty and solved with diagrammatic steps.',
    chapters: [
      '1. Units, Dimensions & Error Analysis (380 Qs)',
      '2. Kinematics 1D & 2D Projectile Motion (520 Qs)',
      '3. Laws of Motion & Friction Dynamics (640 Qs)',
      '4. Work, Energy & Power (510 Qs)',
      '5. Center of Mass, Momentum & Collisions (580 Qs)',
      '6. Rotational Motion & Rigid Body Dynamics (820 Qs)',
      '7. Gravitation & Kepler Laws (420 Qs)',
      '8. Fluid Statics, Dynamics & Surface Tension (460 Qs)',
      '9. Thermal Physics, Kinetic Theory & Thermodynamics (710 Qs)',
      '10. Electrostatics & Gauss Law (790 Qs)',
      '11. Current Electricity & Circuit Networks (680 Qs)',
      '12. Magnetic Effects of Current & EMI (780 Qs)',
      '13. Ray & Wave Optics (690 Qs)',
      '14. Modern Physics, X-Rays & Semiconductors (710 Qs)',
    ],
    sampleContent: `# 20,000+ Physics Vault (2010–2026)

## Chapter: Rotational Motion (Solved Archives)
### Core Master Formulae for 2010–2026:
1. Pure Rolling on rough incline: $a = \\frac{g \\sin \\theta}{1 + k^2/R^2}$, Friction $f = \\frac{M g \\sin \\theta}{1 + R^2/k^2}$.
2. Angular Momentum Conservation: $\\vec{L}_O = \\vec{L}_{com} + \\vec{r}_{com} \\times M \\vec{v}_{com}$.
3. Radius of Gyration: $k = \\sqrt{I / M}$. Ring: $k = R$, Disc: $k = R/\\sqrt{2}$, Solid Sphere: $k = \\sqrt{2/5} R$.
`,
  },
  {
    id: 'book-20k-chemistry',
    title: 'Arihant 20,000+ Questions: 17 Years (2010–2026) Chapterwise Solved Chemistry Vault',
    author: 'Dr. O.P. Tandon & Kota Chemistry Faculty',
    subject: 'Chemistry',
    category: 'PYQ Compendium',
    totalPages: 1040,
    rating: 4.96,
    questionCount: 6800,
    yearCoverage: '2010 – 2026',
    coverColor: 'from-emerald-700 via-teal-800 to-slate-950',
    description: 'Comprehensive 6,800+ Chemistry questions archive covering Organic Mechanism Pathways, Coordination Chemistry, Chemical Bonding, Electrochemistry, Chemical Kinetics, and P-block trends from 2010 to 2026.',
    chapters: [
      '1. Mole Concept, Redox & Stoichiometry (420 Qs)',
      '2. Atomic Structure & Quantum Numbers (480 Qs)',
      '3. Chemical Bonding & Molecular Orbital Theory (720 Qs)',
      '4. Thermodynamics & Chemical Equilibrium (650 Qs)',
      '5. Ionic Equilibrium & pH Calculations (590 Qs)',
      '6. Electrochemistry & Nernst Equation (640 Qs)',
      '7. Chemical Kinetics & Nuclear Chemistry (610 Qs)',
      '8. Coordination Compounds & Crystal Field Theory (780 Qs)',
      '9. P, D & F Block Transition Elements (650 Qs)',
      '10. General Organic Chemistry & Reaction Intermediates (820 Qs)',
      '11. Hydrocarbons, Halides & Grignard Reagents (680 Qs)',
      '12. Carbonyls, Carboxylic Acids & Amines (760 Qs)',
    ],
    sampleContent: `# 20,000+ Chemistry Vault (2010–2026)

## Chapter: Coordination Compounds & Bonding (Solved Archives)
### Crystal Field Splitting High-Yield Rules:
- Octahedral field splits d-orbitals into lower $t_{2g}$ (triply degenerate: $d_{xy}, d_{yz}, d_{zx}$) and higher $e_g$ (doubly degenerate: $d_{x^2-y^2}, d_{z^2}$).
- CFSE = $(-0.4 n_{t_{2g}} + 0.6 n_{e_g}) \\Delta_o + m P$.
- Strong field ligands (CN⁻, CO, en, NO₂⁻) cause low-spin configurations with pairing.
`,
  },
  {
    id: 'book-20k-maths',
    title: 'Cengage 20,000+ Questions: 17 Years (2010–2026) Chapterwise Solved Mathematics Vault',
    author: 'G. Tewani & IIT Alumni Math Forum',
    subject: 'Mathematics',
    category: 'PYQ Compendium',
    totalPages: 1180,
    rating: 4.98,
    questionCount: 6500,
    yearCoverage: '2010 – 2026',
    coverColor: 'from-violet-700 via-purple-900 to-slate-950',
    description: 'Exhaustive 6,500+ Mathematics question compendium from 2010–2026. Features rigorous step-by-step calculus derivations, 3D line-plane intersection problems, matrix algebra hacks, and probability distribution sets.',
    chapters: [
      '1. Functions, Relations & Transformations (450 Qs)',
      '2. Limits, Continuity & Differentiability (620 Qs)',
      '3. Application of Derivatives & Tangents (580 Qs)',
      '4. Indefinite & Definite Integrals (840 Qs)',
      '5. Area Under Curves & Differential Equations (690 Qs)',
      '6. Straight Lines & Circles (540 Qs)',
      '7. Parabola, Ellipse & Hyperbola Conics (710 Qs)',
      '8. Vector Algebra & 3D Analytical Geometry (780 Qs)',
      '9. Matrices, Determinants & System of Equations (620 Qs)',
      '10. Complex Numbers & Quadratic Equations (670 Qs)',
    ],
    sampleContent: `# 20,000+ Mathematics Vault (2010–2026)

## Chapter: Definite Integration & Area (Solved Archives)
### Master Speed Formulas:
1. Area enclosed between $y^2 = 4ax$ and $y = mx$ is $\\frac{8a^2}{3m^3}$.
2. King's Property: $\\int_a^b f(x) dx = \\int_a^b f(a + b - x) dx$.
3. Shortest distance between skew lines $\\vec{r} = \\vec{a}_1 + \\lambda \\vec{b}_1$ and $\\vec{r} = \\vec{a}_2 + \\mu \\vec{b}_2$:
   $d = \\frac{|(\\vec{a}_2 - \\vec{a}_1) \\cdot (\\vec{b}_1 \\times \\vec{b}_2)|}{|\\vec{b}_1 \\times \\vec{b}_2|}$.
`,
  },

  // ========================================================
  // --- STANDARD TEXTBOOKS & ADVANCED PROBLEM BOOKS ---
  // ========================================================
  {
    id: 'book-hcv',
    title: 'Concepts of Physics (Vol 1 & 2)',
    author: 'Prof. H.C. Verma',
    subject: 'Physics',
    category: 'Textbook',
    totalPages: 462,
    rating: 4.98,
    coverColor: 'from-amber-600 to-orange-800',
    description: 'The indisputable bible of IIT JEE Physics. Renowned for clarifying fundamental conceptual mechanics, electrostatics, optics, and modern physics with everyday intuitive examples.',
    chapters: [
      'Introduction to Physics & Vectors',
      'Rest and Motion: Kinematics',
      'The Forces & Newton’s Laws of Motion',
      'Friction & Circular Motion',
      'Work and Energy',
      'Center of Mass & Linear Momentum',
      'Rotational Mechanics',
      'Gravitation & Simple Harmonic Motion',
      'Fluid Mechanics & Surface Tension',
      'Heat, Temperature & First Law of Thermodynamics',
      'Wave Motion & Sound Waves',
      'Electric Field and Potential',
      'Capacitors & Gauss’s Law',
      'Electric Current in Conductors',
      'Magnetic Field & Electromagnetic Induction',
      'Optics & Optical Instruments',
    ],
    sampleContent: `# Concepts of Physics - Core Highlights

## Chapter 10: Rotational Mechanics (Excerpts)
Physics is not merely memorization of formulas; it is developing the mental eye to observe nature.

### Key Conceptual Postulates:
1. When a rigid body rotates about an axis fixed in an inertial frame, every particle of the body moves in a circle with the same angular velocity ω.
2. The relation v = ω r holds for each particle, but v differs depending on distance r from the axis.
3. Torque τ = dL/dt. Just as force is the rate of change of linear momentum, torque is the rate of change of angular momentum.
`,
  },
  {
    id: 'book-irodov',
    title: 'Problems in General Physics',
    author: 'I.E. Irodov',
    subject: 'Physics',
    category: 'Problem Book',
    totalPages: 388,
    rating: 4.92,
    coverColor: 'from-blue-700 to-indigo-950',
    description: 'The supreme benchmark for JEE Advanced rankers seeking Top 500 AIR. Intense multi-concept problems challenging physical intuition, differential setups, and coordinate mastery.',
    chapters: [
      '1.1 Kinematics of Particles & Rigid Bodies',
      '1.2 Fundamental Equation of Dynamics',
      '1.3 Laws of Conservation of Energy, Momentum, Angular Momentum',
      '1.4 Universal Gravitation',
      '1.5 Dynamics of a Solid Body',
      '1.7 Hydrodynamics',
      '2.1 Equation of the Gas State & Processes',
      '3.1 Constant Electric Field in Vacuum',
      '3.4 Magnetic Field in Vacuum & Ampère’s Law',
      '3.5 Electromagnetic Induction & Maxwell’s Equations',
    ],
    sampleContent: `# Irodov: Problems in General Physics

## Selected Problems with Strategy:
### Problem 1.1: Relative Pursuit Motion
A point moves on the plane xy according to the law x = at, y = at(1 - αt), where a and α are positive constants. Find the equation of the trajectory y(x).
- Solution: Since x = at, t = x/a. Substitute into y: y = x(1 - αx/a) = x - (α/a)x² (parabola).
`,
  },
  {
    id: 'book-msc',
    title: 'Advanced Problems in Organic Chemistry',
    author: 'M.S. Chouhan',
    subject: 'Chemistry',
    category: 'Problem Book',
    totalPages: 520,
    rating: 4.94,
    coverColor: 'from-emerald-700 to-teal-950',
    description: 'Designed exclusively for JEE Advanced aspirants. Packed with stereochemical pitfalls, rearranged carbocations, multi-step conversions, and structural identification mysteries.',
    chapters: [
      'General Organic Chemistry (GOC)',
      'Isomerism (Stereo & Structural)',
      'Grignard Reagents & Organometallics',
      'Hydrocarbons (Alkanes, Alkenes, Alkynes)',
      'Alkyl & Aryl Halides (SN1, SN2, E1, E2)',
      'Alcohols, Phenols & Ethers',
      'Aldehydes and Ketones (Nucleophilic Addition & Condensations)',
      'Carboxylic Acids and Derivatives',
      'Nitrogen Containing Compounds (Amines & Diazonium Salts)',
      'Aromatic Compounds & Electrophilic Substitution',
    ],
    sampleContent: `# M.S. Chouhan: Organic Mastery

## Carbocation Rearrangement Golden Rules:
1. Ring Expansion Rule: 4-membered ring bearing adjacent C⁺ expands to 5-membered ring.
2. 5-membered ring expands to 6-membered ring.
3. Migratory Aptitude in Pinacol-Pinacolone: p-Anisyl > p-Tolyl > Phenyl > p-Chlorophenyl > p-Nitrophenyl.
`,
  },
  {
    id: 'book-cengage-math',
    title: 'Cengage Advanced Mathematics (Calculus & Coordinate)',
    author: 'G. Tewani',
    subject: 'Mathematics',
    category: 'Textbook',
    totalPages: 610,
    rating: 4.91,
    coverColor: 'from-rose-700 to-red-950',
    description: 'Thorough coverage of advanced algebra, analytical coordinate geometry, vector calculus, and functions with thousands of graded IIT JEE Advanced exercises.',
    chapters: [
      'Functions and Graphs',
      'Limits, Continuity and Differentiability',
      'Application of Derivatives (Tangent, Normal, Monotonicity)',
      'Indefinite and Definite Integration',
      'Area Under Curves & Differential Equations',
      'Parabola, Ellipse & Hyperbola',
      'Vectors & 3D Analytical Geometry',
      'Complex Numbers & Polynomials',
      'Permutations, Combinations & Probability',
      'Matrices, Determinants & System of Linear Equations',
    ],
    sampleContent: `# Cengage Advanced Mathematics

## Chapter: Definite Integration & Area
### Standard Formula for Parabola:
The area bounded by the parabola y² = 4ax and its focal chord making angle α with the axis of the parabola is:
Area = (8/3) a² (cosec³ α). When the chord is the latus rectum (α = 90°), Area = (8/3) a²!
`,
  },
];
