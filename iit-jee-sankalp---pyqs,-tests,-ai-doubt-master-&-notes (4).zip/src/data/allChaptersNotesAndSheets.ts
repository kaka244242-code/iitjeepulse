import { Subject } from '../types';

export interface KeyFormulaItem {
  name: string;
  nameHindi: string;
  formula: string;
  notes: string;
  notesHindi: string;
}

export interface ChapterShortNote {
  id: string;
  chapter: string;
  chapterHindi: string;
  subject: Subject;
  readTimeMinutes: number;
  weightage: string;
  weightageHindi: string;
  summary: string;
  summaryHindi: string;
  keyFormulas: KeyFormulaItem[];
  highYieldTricks: string[];
  highYieldTricksHindi: string[];
  commonTraps: string[];
  commonTrapsHindi: string[];
}

export interface PYQSheetItem {
  id: string;
  chapter: string;
  chapterHindi: string;
  subject: Subject;
  yearCoverage: string;
  questionsCount: number;
  totalMarks: number;
  topSubtopics: string[];
  topSubtopicsHindi: string[];
  exemplarQuestions: {
    year: number;
    exam: string;
    questionEn: string;
    questionHi: string;
    optionsEn: string[];
    optionsHi: string[];
    correctOption: number;
    solutionEn: string;
    solutionHi: string;
    topperTrickEn: string;
    topperTrickHi: string;
  }[];
}

// =========================================================================
// 1. ALL CHAPTERS SHORT NOTES (PHYSICS, CHEMISTRY, MATHEMATICS)
// =========================================================================
export const allChaptersShortNotes: ChapterShortNote[] = [
  // --- PHYSICS ---
  {
    id: 'sn-phy-01',
    chapter: 'Rotational Motion & Mechanics',
    chapterHindi: 'घूर्णन गति एवं दृढ़ पिंड गतिकी',
    subject: 'Physics',
    readTimeMinutes: 10,
    weightage: '🔥 12-16 Marks · Top Weightage',
    weightageHindi: '🔥 12-16 अंक · उच्च वेटेज',
    summary: 'Pure rolling, moment of inertia of continuous bodies, angular momentum conservation, and toppling conditions on inclined planes.',
    summaryHindi: 'शुद्ध लोटनी गति, जड़त्व आघूर्ण, कोणीय संवेग संरक्षण और आनत तल पर पलटने (toppling) की शर्तें।',
    keyFormulas: [
      {
        name: 'Pure Rolling Acceleration',
        nameHindi: 'शुद्ध लोटनी गति में त्वरण',
        formula: 'a_com = (g sin θ) / (1 + k²/R²)',
        notes: 'Ring: (1/2)g sin θ; Cylinder/Disc: (2/3)g sin θ; Solid Sphere: (5/7)g sin θ',
        notesHindi: 'रिंग: 1/2; डिस्क/बेलन: 2/3; ठोस गोला: 5/7 अनुपात सीधे याद रखें',
      },
      {
        name: 'Angular Momentum Conservation',
        nameHindi: 'कोणीय संवेग संरक्षण',
        formula: 'τ_ext = 0 ⇒ L_initial = L_final (about pivot)',
        notes: 'Calculate torque about the fixed pivot to make pivot reaction torque zero',
        notesHindi: 'कीलकित बिंदु (pivot) के परितः बल आघूर्ण शून्य करके संवेग संरक्षित करें',
      },
      {
        name: 'Toppling vs Sliding Condition',
        nameHindi: 'पलटने बनाम फिसलने की स्थिति',
        formula: 'Topple before slide if h / (b/2) > 1 / μ',
        notes: 'Normal force shifts towards leading edge by x = (F · h) / (M g)',
        notesHindi: 'अभिलंब बल आगे की ओर विस्थापित होता है',
      },
    ],
    highYieldTricks: [
      'Standard acceleration ratio: Solid Sphere (5/7) > Disc (2/3) > Ring (1/2). Sphere reaches the bottom first!',
      'Torque τ = I α is valid ONLY about the center of mass or instantaneous center of zero velocity.',
    ],
    highYieldTricksHindi: [
      'मानक त्वरण क्रम: ठोस गोला (5/7) > डिस्क (2/3) > वलय (1/2)। गोला सबसे पहले नीचे पहुंचेगा!',
      'बल आघूर्ण समीकरण केवल द्रव्यमान केंद्र या तात्क्षणिक शून्य वेग केंद्र के परितः मान्य है।',
    ],
    commonTraps: [
      'Applying perpendicular axis theorem to 3D spherical or cylindrical bodies (only valid for 2D laminar bodies!).',
      'Forgetting that static friction can act in the forward direction during rolling with acceleration.',
    ],
    commonTrapsHindi: [
      'लंबवत अक्ष प्रमेय को 3D पिंडों पर लगाना (यह केवल 2D समतल पटल पर मान्य है)।',
      'यह भूल जाना कि लोटनी गति में स्थैतिक घर्षण आगे की दिशा में भी लग सकता है।',
    ],
  },
  {
    id: 'sn-phy-02',
    chapter: 'Electrodynamics & Capacitors',
    chapterHindi: 'विद्युत चुंबकत्व एवं संधारित्र परिपथ',
    subject: 'Physics',
    readTimeMinutes: 12,
    weightage: '🔥 16-20 Marks Guaranteed',
    weightageHindi: '🔥 16-20 अंक पक्के',
    summary: 'Gauss law, capacitor dielectrics, RC charging/discharging transients, and force between conductor plates.',
    summaryHindi: 'गाउस का नियम, परावैद्युत युक्त संधारित्र, RC परिपथ का आवेश प्रवाह और प्लेटों के मध्य आकर्षण बल।',
    keyFormulas: [
      {
        name: 'Capacitance with Dielectric',
        nameHindi: 'परावैद्युत सहित धारिता',
        formula: 'C = (ε₀ A) / (d - t + t/K)',
        notes: 'If dielectric fills entire volume, C = K · C₀',
        notesHindi: 'पूर्ण परावैद्युत भरने पर C = K · C₀ हो जाती है',
      },
      {
        name: 'RC Charging Equation',
        nameHindi: 'RC परिपथ आवेशन समीकरण',
        formula: 'q(t) = Q₀(1 - e^(-t / RC)),  I(t) = I₀ e^(-t / RC)',
        notes: 'At t = τ = RC, charge reaches 63.2% of Q₀',
        notesHindi: 'समय स्थिरांक τ = RC पर 63.2% आवेशन पूर्ण होता है',
      },
      {
        name: 'Force between Capacitor Plates',
        nameHindi: 'संधारित्र प्लेटों के मध्य बल',
        formula: 'F = Q² / (2 A ε₀) = (1/2) Q E_external',
        notes: 'Energy density in electric field u = (1/2) ε₀ E²',
        notesHindi: 'विद्युत क्षेत्र का ऊर्जा घनत्व u = (1/2) ε₀ E²',
      },
    ],
    highYieldTricks: [
      'Battery connected vs disconnected: If battery connected, Voltage V remains constant. If battery removed, Charge Q remains constant!',
      'Split dielectrics: Area split = parallel capacitors. Thickness split = series capacitors.',
    ],
    highYieldTricksHindi: [
      'बैटरी जुड़ी होने पर विभवांतर V नियत रहता है। बैटरी हटाने पर आवेश Q नियत रहता है!',
      'क्षेत्रफल विभाजन = समांतर क्रम, मोटाई विभाजन = श्रेणी क्रम।',
    ],
    commonTraps: [
      'Using F = Q E instead of (1/2) Q E (the plate does not experience its own field!).',
    ],
    commonTrapsHindi: [
      'प्लेटों के बल में F = Q E लिखना (सही मान (1/2) Q E होता है क्योंकि प्लेट स्वयं के क्षेत्र से बल अनुभव नहीं करती)।',
    ],
  },
  {
    id: 'sn-phy-03',
    chapter: 'Modern Physics & Nuclear Reactions',
    chapterHindi: 'आधुनिक भौतिकी एवं नाभिकीय अभिक्रियाएं',
    subject: 'Physics',
    readTimeMinutes: 10,
    weightage: '🔥 16-20 Marks · Highest Return',
    weightageHindi: '🔥 16-20 अंक · सर्वाधिक रिटर्न',
    summary: 'Photoelectric effect, de Broglie matter waves, Bohr atomic transitions, mass defect, and radioactive decay laws.',
    summaryHindi: 'प्रकाश वैद्युत प्रभाव, दे ब्रॉग्ली तरंगें, बोर परमाणु संक्रमण, द्रव्यमान क्षति व रेडियोएक्टिव क्षय नियम।',
    keyFormulas: [
      {
        name: 'Einstein Photoelectric Equation',
        nameHindi: 'आइंस्टीन प्रकाश वैद्युत समीकरण',
        formula: 'K_max = h ν - Φ = e V_s',
        notes: 'Slope of V_s vs ν graph is h/e (universal constant)',
        notesHindi: 'निरोधी विभव बनाम आवृत्ति ग्राफ की ढाल h/e होती है',
      },
      {
        name: 'De Broglie Wavelength',
        nameHindi: 'दे ब्रॉग्ली तरंगदैर्घ्य',
        formula: 'λ = h / p = h / √(2 m q V) = 12.27 / √V Å (for electron)',
        notes: 'For photon E = pc, but for electron E_k = p²/(2m)',
        notesHindi: 'इलेक्ट्रॉन के लिए λ = 12.27 / √V Å सीधे प्रयोग करें',
      },
      {
        name: 'Radioactive Decay Law',
        nameHindi: 'रेडियोएक्टिव क्षय नियम',
        formula: 'N(t) = N₀ e^(-λ t) = N₀ (1/2)^(t / T_1/2)',
        notes: 'Half life T_1/2 = 0.693 / λ. Mean life τ = 1 / λ',
        notesHindi: 'अर्ध-आयु T_1/2 = 0.693 / λ, औसत आयु τ = 1 / λ',
      },
    ],
    highYieldTricks: [
      'Photoelectric current depends solely on INTENSITY, while kinetic energy depends solely on FREQUENCY.',
      'Energy of nth Bohr level: E_n = -13.6 · (Z²/n²) eV. Transitions to n=1 (Lyman, UV), n=2 (Balmer, Visible).',
    ],
    highYieldTricksHindi: [
      'प्रकाश धारा केवल तीव्रता पर निर्भर करती है, जबकि गतिज ऊर्जा केवल आवृत्ति पर!',
      'बोर ऊर्जा स्तर: E_n = -13.6 · (Z²/n²) eV। n=1 लाइमन (UV), n=2 बामर (दृश्य)।',
    ],
    commonTraps: [
      'Confusing stopping potential with work function.',
      'Forgetting that nuclear density is independent of mass number A (approx 2.3 × 10¹⁷ kg/m³).',
    ],
    commonTrapsHindi: [
      'निरोधी विभव और कार्यफलन में भ्रम।',
      'यह भूलना कि नाभिकीय घनत्व द्रव्यमान संख्या A पर निर्भर नहीं करता।',
    ],
  },
  {
    id: 'sn-phy-04',
    chapter: 'Thermodynamics & Heat Transfer',
    chapterHindi: 'ऊष्मागतिकी एवं ऊष्मा संचरण',
    subject: 'Physics',
    readTimeMinutes: 11,
    weightage: '⚡ 12-16 Marks · Predictable',
    weightageHindi: '⚡ 12-16 अंक · सुनिश्चित प्रश्न',
    summary: 'First law of thermodynamics (ΔQ = ΔU + W), Carnot engine efficiency, adiabatic relations, and Stefan-Boltzmann radiation.',
    summaryHindi: 'ऊष्मागतिकी का प्रथम नियम, कार्नो इंजन दक्षता, रुद्धोष्म संबंध व स्टीफन-बोल्ट्ज़मान विकिरण।',
    keyFormulas: [
      {
        name: 'First Law of Thermodynamics',
        nameHindi: 'ऊष्मागतिकी का प्रथम नियम',
        formula: 'ΔQ = n C_v ΔT + W_by_gas',
        notes: 'ΔU = n C_v ΔT is state function (depends only on T₁ and T₂)',
        notesHindi: 'आंतरिक ऊर्जा ΔU केवल ताप परिवर्तन पर निर्भर करती है',
      },
      {
        name: 'Carnot Engine Efficiency',
        nameHindi: 'कार्नो इंजन की दक्षता',
        formula: 'η = 1 - T₂ / T₁ = W / Q₁',
        notes: 'T₁ and T₂ MUST be in Kelvin scale',
        notesHindi: 'तापमान सदैव केल्विन (K) में रखें',
      },
      {
        name: 'Stefan-Boltzmann Radiation Law',
        nameHindi: 'स्टीफन-बोल्ट्ज़मान नियम',
        formula: 'P = e σ A (T⁴ - T₀⁴)',
        notes: 'Newton law of cooling: dT/dt = -k(T - T₀) for small temp diff',
        notesHindi: 'अल्प ताप अंतर हेतु न्यूटन का शीतलन नियम लागू होता है',
      },
    ],
    highYieldTricks: [
      'Ratio of slopes on P-V diagram: Adiabatic slope is ALWAYS γ times the isothermal slope.',
      'Work done in cyclic process = Area enclosed in P-V indicator diagram. Clockwise = Positive (+), Counterclockwise = Negative (-).',
    ],
    highYieldTricksHindi: [
      'P-V ग्राफ में रुद्धोष्म वक्र की ढाल समतापी की तुलना में γ गुना अधिक तीखी होती है।',
      'चक्रीय प्रक्रम में कार्य = P-V ग्राफ का घिरा क्षेत्रफल। दक्षिणावर्त (+) वामावर्त (-)।',
    ],
    commonTraps: [
      'Putting temperature in Celsius instead of Kelvin in Carnot efficiency formula.',
    ],
    commonTrapsHindi: [
      'कार्नो दक्षता में सेल्सियस में तापमान रख देना (हमेशा केल्विन में रखें)।',
    ],
  },

  // --- CHEMISTRY ---
  {
    id: 'sn-chem-01',
    chapter: 'Coordination Compounds & Isomerism',
    chapterHindi: 'उपसहसंयोजन यौगिक एवं समावयवता',
    subject: 'Chemistry',
    readTimeMinutes: 12,
    weightage: '🔥 16-20 Marks Guaranteed',
    weightageHindi: '🔥 16-20 अंक पक्के',
    summary: 'Crystal field theory (CFT) splitting, spectrochemical series, Jahn-Teller effect, magnetic moments, and IUPAC nomenclature.',
    summaryHindi: 'क्रिस्टल क्षेत्र विपाटन (CFT), स्पेक्ट्रोकेमिकल श्रेणी, यान-टेलर प्रभाव, चुंबकीय आघूर्ण व IUPAC नामकरण।',
    keyFormulas: [
      {
        name: 'Spin-Only Magnetic Moment',
        nameHindi: 'केवल चक्रण चुंबकीय आघूर्ण',
        formula: 'μ = √(n(n + 2)) BM',
        notes: 'n = number of unpaired electrons (e.g. n=1: 1.73; n=2: 2.83; n=3: 3.87; n=4: 4.90; n=5: 5.92 BM)',
        notesHindi: 'अयुग्मित इलेक्ट्रॉनों की संख्या से सीधे BM मान निकालें',
      },
      {
        name: 'Crystal Field Stabilization Energy (CFSE)',
        nameHindi: 'क्रिस्टल क्षेत्र स्थायीकरण ऊर्जा',
        formula: 'CFSE_oct = [-0.4 n_t2g + 0.6 n_eg] Δ₀ + m P',
        notes: 'Tetrahedral splitting Δ_t = (4/9) Δ₀',
        notesHindi: 'चतुष्फलकीय विपाटन Δ_t = (4/9) Δ₀ होता है',
      },
    ],
    highYieldTricks: [
      'Spectrochemical Series shortcut: I⁻ < Br⁻ < S²⁻ < Cl⁻ < NO₃⁻ < F⁻ < OH⁻ < C₂O₄²⁻ < H₂O < NCS⁻ < EDTA⁴⁻ < NH₃ < en < NO₂⁻ < CN⁻ < CO.',
      'Strong Jahn-Teller distortion always occurs in d⁹ (Cu²⁺) octahedral complexes.',
    ],
    highYieldTricksHindi: [
      'स्पेक्ट्रोकेमिकल श्रेणी में CN⁻ और CO सबसे प्रबल क्षेत्र लिगैंड हैं जो इलेक्ट्रॉन युग्मन कराते हैं।',
      'Cu²⁺ (d⁹) अष्टफलकीय संकुलों में तीव्र यान-टेलर विकृति पाई जाती है।',
    ],
    commonTraps: [
      'Counting geometric isomers without verifying mirror-image optical activity (cis-[Co(en)₂Cl₂]⁺ is optically active!).',
    ],
    commonTrapsHindi: [
      'cis-[Co(en)₂Cl₂]⁺ के प्रकाशिक सक्रिय होने को भूल जाना।',
    ],
  },
  {
    id: 'sn-chem-02',
    chapter: 'Organic Reaction Mechanisms & Carbonyls',
    chapterHindi: 'कार्बनिक अभिक्रिया क्रियाविधि एवं कार्बोनिल यौगिक',
    subject: 'Chemistry',
    readTimeMinutes: 15,
    weightage: '🔥 20+ Marks · Highest Chem ROI',
    weightageHindi: '🔥 20+ अंक · सर्वाधिक रसायन वेटेज',
    summary: 'Aldol condensation, Cannizzaro reaction, Grignard reagents, nucleophilic addition, and reagent selectivity matrices.',
    summaryHindi: 'एल्डोल संघनन, कैनिजारो अभिक्रिया, ग्रिग्नार्ड अभिकर्मक व न्यूक्लियोफिलिक योग अभिक्रिया।',
    keyFormulas: [
      {
        name: 'Aldol Condensation Criteria',
        nameHindi: 'एल्डोल संघनन की शर्त',
        formula: 'Requires presence of at least one α-Hydrogen',
        notes: 'Product after heating is α,β-unsaturated carbonyl compound',
        notesHindi: 'कम से कम एक α-हाइड्रोजन आवश्यक, गर्म करने पर α,β-असंतृप्त यौगिक बनता है',
      },
      {
        name: 'Cannizzaro Disproportionation',
        nameHindi: 'कैनिजारो असमानुपातन',
        formula: 'Aldehydes with NO α-Hydrogen in conc. KOH',
        notes: 'One molecule oxidizes to Carboxylate, other reduces to Alcohol',
        notesHindi: 'α-हाइड्रोजन रहित एल्डिहाइड का एक अणु अम्ल व दूसरा ऐल्कोहॉल बनाता है',
      },
    ],
    highYieldTricks: [
      'DIBAL-H at -78°C selectively reduces esters and nitriles (R-CN) to aldehydes without over-reducing to alcohols.',
      'Iodoform test (CHI₃ yellow precipitate) is positive ONLY for CH₃-C=O group or CH₃-CH(OH)- group.',
    ],
    highYieldTricksHindi: [
      'DIBAL-H (-78°C) एस्टर और नाइट्राइल को सीधे एल्डिहाइड में बदलता है।',
      'आयोडोफॉर्म परीक्षण केवल CH₃-C=O या CH₃-CH(OH)- समूह वाले यौगिक देते हैं।',
    ],
    commonTraps: [
      'Attempting Cannizzaro on aldehydes that have α-hydrogens (they undergo Aldol instead!).',
    ],
    commonTrapsHindi: [
      'α-हाइड्रोजन युक्त एल्डिहाइड में कैनिजारो लगाना (वे एल्डोल संघनन करते हैं)।',
    ],
  },
  {
    id: 'sn-chem-03',
    chapter: 'Electrochemistry & Solutions',
    chapterHindi: 'विद्युत रसायन एवं विलयन',
    subject: 'Chemistry',
    readTimeMinutes: 12,
    weightage: '🔥 16 Marks Guaranteed',
    weightageHindi: '🔥 16 अंक पक्के',
    summary: 'Nernst equation, Kohlrausch law, Faraday electrolysis, Raoult law, and colligative properties with Van\'t Hoff factor.',
    summaryHindi: 'नेर्नस्ट समीकरण, कोलरॉउश नियम, फैराडे नियम, राउल्ट नियम व अणुसंख्य गुणधर्म।',
    keyFormulas: [
      {
        name: 'Nernst Equation at 298 K',
        nameHindi: '298 K पर नेर्नस्ट समीकरण',
        formula: 'E_cell = E°_cell - (0.0591 / n) log Q',
        notes: 'At equilibrium: E_cell = 0 ⇒ E°_cell = (0.0591 / n) log K_eq',
        notesHindi: 'साम्यावस्था पर E_cell = 0 होता है',
      },
      {
        name: 'Van\'t Hoff Colligative Property',
        nameHindi: 'वांट हॉफ अणुसंख्य गुणधर्म',
        formula: 'ΔT_b = i · K_b · m;  ΔT_f = i · K_f · m;  Π = i · C R T',
        notes: 'Dissociation: i = 1 + (n - 1)α; Association: i = 1 + (1/n - 1)α',
        notesHindi: 'वियोजन: i = 1 + (n-1)α; संयोजन: i = 1 + (1/n-1)α',
      },
    ],
    highYieldTricks: [
      'Kohlrausch Law: Limiting molar conductivity is strictly additive. Λ°_m(NaCl) = λ°(Na⁺) + λ°(Cl⁻).',
      'Electrochemical series mnemonic: Higher reduction potential = stronger oxidizing agent at cathode.',
    ],
    highYieldTricksHindi: [
      'कोलरॉउश नियम: अनंत तनुता पर मोलर चालकता स्वतंत्र आयनों के योग के बराबर होती है।',
      'उच्च अपचयन विभव = प्रबल ऑक्सीकारक।',
    ],
    commonTraps: [
      'Forgetting the Van\'t Hoff factor i when computing osmotic pressure or boiling point elevation of ionic salts.',
    ],
    commonTrapsHindi: [
      'आयनिक लवणों के लिए वांट हॉफ गुणक i भूल जाना।',
    ],
  },

  // --- MATHEMATICS ---
  {
    id: 'sn-math-01',
    chapter: 'Vectors & 3D Geometry',
    chapterHindi: 'सदिश एवं त्रिविमीय ज्यामिति (3D)',
    subject: 'Mathematics',
    readTimeMinutes: 12,
    weightage: '🔥 16-20 Marks · Highest Math ROI',
    weightageHindi: '🔥 16-20 अंक · गणित का सर्वोच्च वेटेज',
    summary: 'Scalar and vector triple products, shortest distance between skew lines, equation of plane, and foot of perpendicular.',
    summaryHindi: 'अदिश व सदिश त्रिगुणन, विषमतलीय रेखाओं के मध्य न्यूनतम दूरी, समतल समीकरण व लंबपाद।',
    keyFormulas: [
      {
        name: 'Shortest Distance between Skew Lines',
        nameHindi: 'विषमतलीय रेखाओं के मध्य न्यूनतम दूरी',
        formula: 'd = |(a₂ - a₁) · (b₁ × b₂)| / |b₁ × b₂|',
        notes: 'If d = 0, lines are coplanar (intersecting)',
        notesHindi: 'यदि d = 0 हो तो रेखाएं समतलीय (प्रतिच्छेदी) होती हैं',
      },
      {
        name: 'Vector Triple Product Expansion (BAC-CAB)',
        nameHindi: 'सदिश त्रिगुणन (BAC-CAB नियम)',
        formula: 'a × (b × c) = (a · c) b - (a · b) c',
        notes: 'Notice vector is in plane of b and c',
        notesHindi: 'परिणामी सदिश b और c के तल में होता है',
      },
      {
        name: 'Foot of Perpendicular on Plane',
        nameHindi: 'समतल पर लंबपाद',
        formula: '(x - x₁)/a = (y - y₁)/b = (z - z₁)/c = -(a x₁ + b y₁ + c z₁ + d) / (a² + b² + c²)',
        notes: 'For image point, multiply right hand side by 2',
        notesHindi: 'प्रतिबिंब बिंदु हेतु दायीं ओर 2 से गुणा करें',
      },
    ],
    highYieldTricks: [
      'Shortest distance formula appears in EVERY JEE Main paper without exception (guaranteed 4 marks in 2 mins).',
      'BAC-CAB rule eliminates tedious coordinate expansions instantly.',
    ],
    highYieldTricksHindi: [
      'न्यूनतम दूरी सूत्र से प्रतिवर्ष हर शिफ्ट में 4 अंक का प्रश्न निश्चित आता है।',
      'BAC-CAB नियम से सीधे मान प्राप्त करें।',
    ],
    commonTraps: [
      'Switching order in cross product: (b₁ × b₂) = -(b₂ × b₁).',
    ],
    commonTrapsHindi: [
      'सदिश गुणन में क्रम परिवर्तन पर ऋण चिह्न भूलना।',
    ],
  },
  {
    id: 'sn-math-02',
    chapter: 'Definite Integrals & Differential Equations',
    chapterHindi: 'निश्चित समाकलन एवं अवकल समीकरण',
    subject: 'Mathematics',
    readTimeMinutes: 14,
    weightage: '🔥 16 Marks Guaranteed',
    weightageHindi: '🔥 16 अंक पक्के',
    summary: 'King\'s property, Leibnitz rule for differentiation under integral sign, limit of a sum, and linear differential equations.',
    summaryHindi: 'किंग्स प्रॉपर्टी, लेबनिज नियम, योग की सीमा व प्रथम कोटि रैखिक अवकल समीकरण।',
    keyFormulas: [
      {
        name: 'King\'s Property',
        nameHindi: 'किंग्स प्रॉपर्टी (मूल गुणधर्म)',
        formula: '∫[a to b] f(x) dx = ∫[a to b] f(a + b - x) dx',
        notes: 'Adding I + I = 2I simplifies 85% of JEE integrals to a constant',
        notesHindi: 'I + I = 2I करने पर 85% समाकल सीधे हल हो जाते हैं',
      },
      {
        name: 'Leibnitz Rule of Differentiation',
        nameHindi: 'लेबनिज अवकलन नियम',
        formula: 'd/dx ∫[u(x) to v(x)] f(t) dt = f(v(x)) v\'(x) - f(u(x)) u\'(x)',
        notes: 'Indispensable for L\'Hopital 0/0 limit problems involving integrals',
        notesHindi: 'समाकल युक्त सीमा (limits) ज्ञात करने में सर्वाधिक प्रयुक्त',
      },
      {
        name: 'Linear Differential Equation',
        nameHindi: 'रैखिक अवकल समीकरण',
        formula: 'dy/dx + P(x) y = Q(x) ⇒ y · e^(∫P dx) = ∫(Q · e^(∫P dx)) dx + C',
        notes: 'Integrating factor IF = e^(∫P(x) dx)',
        notesHindi: 'समाकलन गुणक IF = e^(∫P dx) सीधे निकालें',
      },
    ],
    highYieldTricks: [
      'If f(x) + f(a + b - x) = K, then the integral ∫[a to b] f(x) dx = K · (b - a) / 2.',
      'Definite integral as limit of sum: Replace r/n with x, and 1/n with dx. Lower limit = lim(r_min/n), upper = lim(r_max/n).',
    ],
    highYieldTricksHindi: [
      'यदि f(x) + f(a+b-x) = K हो तो समाकल का मान K · (b - a) / 2 होता है।',
      'योग की सीमा: r/n को x तथा 1/n को dx से प्रतिस्थापित करें।',
    ],
    commonTraps: [
      'Forgetting to multiply by v\'(x) and u\'(x) in Leibnitz differentiation rule.',
    ],
    commonTrapsHindi: [
      'लेबनिज नियम में सीमाओं के अवकलन (v\' और u\') से गुणा करना भूल जाना।',
    ],
  },
  {
    id: 'sn-math-03',
    chapter: 'Matrices, Determinants & Equations',
    chapterHindi: 'आव्यूह, सारणिक एवं समीकरण निकाय',
    subject: 'Mathematics',
    readTimeMinutes: 10,
    weightage: '⚡ 12-16 Marks · Direct Score',
    weightageHindi: '⚡ 12-16 अंक · सीधा स्कोर',
    summary: 'Cramer\'s rule for system of linear equations, adjoint properties, characteristic equation, and trace/determinant relations.',
    summaryHindi: 'क्रेमर नियम, सहखंडज (adjoint) गुणधर्म, अभिलाक्षणिक समीकरण व ट्रेस संबंध।',
    keyFormulas: [
      {
        name: 'Adjoint Properties',
        nameHindi: 'सहखंडज के महत्वपूर्ण गुणधर्म',
        formula: 'det(adj A) = (det A)^(n - 1);  adj(adj A) = (det A)^(n - 2) · A',
        notes: 'For 3×3 matrix (n=3): det(adj A) = (det A)²; det(adj(adj A)) = (det A)⁴',
        notesHindi: '3×3 आव्यूह हेतु det(adj A) = (det A)² याद रखें',
      },
      {
        name: 'Cramer\'s Rule for Consistency',
        nameHindi: 'क्रेमर नियम (संगतता की शर्तें)',
        formula: 'Δ ≠ 0 ⇒ Unique Solution; Δ = 0 with Δ₁=Δ₂=Δ₃=0 ⇒ Infinitely many solutions',
        notes: 'If Δ = 0 and any Δᵢ ≠ 0 ⇒ Inconsistent (No solution)',
        notesHindi: 'यदि Δ = 0 व कोई एक Δᵢ ≠ 0 हो तो कोई हल नहीं होता',
      },
    ],
    highYieldTricks: [
      'For triangular matrix, eigenvalues are simply the main diagonal entries.',
      'Cayley-Hamilton theorem: Every square matrix satisfies its own characteristic equation det(A - λI) = 0.',
    ],
    highYieldTricksHindi: [
      'त्रिभुजीय आव्यूह के आइगेन मान उसके मुख्य विकर्ण के अवयव ही होते हैं।',
      'कैले-हैमिल्टन प्रमेय से आव्यूह का व्युत्क्रम A⁻¹ तुरंत ज्ञात होता है।',
    ],
    commonTraps: [
      'Assuming Δ = 0 and Δx = Δy = Δz = 0 always implies infinite solutions (it could also be parallel planes with no solution!).',
    ],
    commonTrapsHindi: [
      'समानांतर समतलों की स्थिति में कोई हल न होने की जांच न करना।',
    ],
  },
];

// =========================================================================
// 2. ALL CHAPTERS PYQ SHEETS (PHYSICS, CHEMISTRY, MATHEMATICS)
// =========================================================================
export const allChaptersPYQSheets: PYQSheetItem[] = [
  // --- PHYSICS SHEETS ---
  {
    id: 'pyq-sheet-phy-01',
    chapter: 'Rotational Motion & Mechanics Sheet',
    chapterHindi: 'घूर्णन गति एवं यांत्रिकी पीवाईक्यू शीट',
    subject: 'Physics',
    yearCoverage: '2010–2026',
    questionsCount: 75,
    totalMarks: 300,
    topSubtopics: ['Pure Rolling', 'Angular Momentum', 'Moment of Inertia', 'Toppling Condition'],
    topSubtopicsHindi: ['शुद्ध लोटनी गति', 'कोणीय संवेग', 'जड़त्व आघूर्ण', 'पलटने की स्थिति'],
    exemplarQuestions: [
      {
        year: 2026,
        exam: 'JEE Main',
        questionEn: 'A solid cylinder of mass M and radius R rolls without slipping down an incline θ = 30°. Its linear acceleration of center of mass is:',
        questionHi: 'द्रव्यमान M व त्रिज्या R का एक ठोस बेलन 30° आनत तल पर बिना फिसले लुढ़कता है। इसके द्रव्यमान केंद्र का रेखीय त्वरण होगा:',
        optionsEn: ['(2/3) g sin(30°)', '(1/2) g sin(30°)', '(3/4) g sin(30°)', 'g sin(30°)'],
        optionsHi: ['(2/3) g sin(30°)', '(1/2) g sin(30°)', '(3/4) g sin(30°)', 'g sin(30°)'],
        correctOption: 0,
        solutionEn: 'a_com = g sin θ / (1 + I / (M R²)). For solid cylinder, I/(M R²) = 1/2. Thus a = (2/3) g sin(30°) = g/3.',
        solutionHi: 'a_com = g sin θ / (1 + 1/2) = (2/3) g sin(30°) = g/3 m/s².',
        topperTrickEn: 'Direct ratio for solid cylinder is always 2/3. Instant 10-second mark!',
        topperTrickHi: 'ठोस बेलन हेतु गुणांक सदैव 2/3 होता है। 10 सेकंड में उत्तर प्राप्त करें!',
      },
      {
        year: 2024,
        exam: 'JEE Advanced',
        questionEn: 'A rod of mass 2M and length L hinged at O is struck by particle M at distance L/2 with speed v0. Angular velocity just after collision is:',
        questionHi: 'द्रव्यमान 2M व लम्बाई L की छड़ सिरे O पर कीलकित है। कण M दूरी L/2 पर v0 वेग से टकराकर चिपक जाता है। कोणीय वेग होगा:',
        optionsEn: ['3 v0 / (11 L)', '6 v0 / (11 L)', '2 v0 / (7 L)', 'v0 / (2 L)'],
        optionsHi: ['3 v0 / (11 L)', '6 v0 / (11 L)', '2 v0 / (7 L)', 'v0 / (2 L)'],
        correctOption: 1,
        solutionEn: 'Conserve angular momentum about O: M v0 (L/2) = [ (1/3)(2M)L² + M(L/2)² ] ω. Solving gives ω = 6 v0 / (11 L).',
        solutionHi: 'O के परितः कोणीय संवेग: M v0 (L/2) = [ 2/3 M L² + 1/4 M L² ] ω = (11/12) M L² ω. अत: ω = 6 v0 / (11 L).',
        topperTrickEn: 'Pivot torque is zero! Never compute linear momentum conservation when pivot is fixed.',
        topperTrickHi: 'कीलकित बिंदु के परितः बल आघूर्ण शून्य होता है, रेखीय संवेग संरक्षित न करें।',
      },
    ],
  },
  {
    id: 'pyq-sheet-phy-02',
    chapter: 'Modern Physics & Dual Nature Sheet',
    chapterHindi: 'आधुनिक भौतिकी एवं द्वैत प्रकृति पीवाईक्यू शीट',
    subject: 'Physics',
    yearCoverage: '2010–2026',
    questionsCount: 75,
    totalMarks: 300,
    topSubtopics: ['Photoelectric Effect', 'De Broglie Matter Waves', 'Bohr Model Transitions', 'Radioactive Decay'],
    topSubtopicsHindi: ['प्रकाश वैद्युत प्रभाव', 'दे ब्रॉग्ली तरंगें', 'बोर परमाणु मॉडल', 'रेडियोएक्टिव क्षय'],
    exemplarQuestions: [
      {
        year: 2025,
        exam: 'JEE Main',
        questionEn: 'An electron of mass m and photon have the same wavelength λ. The ratio of electron kinetic energy to photon energy E / E_ph is:',
        questionHi: 'द्रव्यमान m के इलेक्ट्रॉन तथा फोटॉन की तरंगदैर्घ्य λ समान है। इलेक्ट्रॉन गतिज ऊर्जा व फोटॉन ऊर्जा का अनुपात E / E_ph होगा:',
        optionsEn: ['v / (2 c)', 'v / c', '2 v / c', 'c / (2 v)'],
        optionsHi: ['v / (2 c)', 'v / c', '2 v / c', 'c / (2 v)'],
        correctOption: 0,
        solutionEn: 'λ = h/(m v) = h c / E_ph ⇒ E_ph = m v c. Electron kinetic energy E = (1/2) m v². Ratio E / E_ph = v / (2 c).',
        solutionHi: 'E = (1/2) p v, E_ph = p c. अनुपात = (p v / 2) / (p c) = v / (2 c).',
        topperTrickEn: 'Use E = pv/2 and E_ph = pc: ratio is instantly v/(2c) in 5 seconds!',
        topperTrickHi: 'E = pv/2 व E_ph = pc का सीधे भाग दें: v/(2c) तुरंत प्राप्त होगा।',
      },
    ],
  },

  // --- CHEMISTRY SHEETS ---
  {
    id: 'pyq-sheet-chem-01',
    chapter: 'Coordination Compounds Sheet',
    chapterHindi: 'उपसहसंयोजन यौगिक पीवाईक्यू शीट',
    subject: 'Chemistry',
    yearCoverage: '2010–2026',
    questionsCount: 75,
    totalMarks: 300,
    topSubtopics: ['CFT Splitting & Pairing', 'Jahn-Teller Distortion', 'Optical & Geometrical Isomers', 'Magnetic Moments'],
    topSubtopicsHindi: ['CFT विपाटन व युग्मन', 'यान-टेलर विकृति', 'समावयवता', 'चुंबकीय आघूर्ण'],
    exemplarQuestions: [
      {
        year: 2026,
        exam: 'JEE Advanced',
        questionEn: 'Which of the following high-spin complexes exhibits strong tetragonal Jahn-Teller distortion in eg orbitals?',
        questionHi: 'निम्नलिखित में से कौन-सा उच्च चक्रण संकुल eg कक्षकों में तीव्र यान-टेलर विकृति प्रदर्शित करता है?',
        optionsEn: ['[Cu(H₂O)₆]²⁺', '[Cr(H₂O)₆]³⁺', '[Mn(H₂O)₆]²⁺', '[Fe(H₂O)₆]²⁺'],
        optionsHi: ['[Cu(H₂O)₆]²⁺', '[Cr(H₂O)₆]³⁺', '[Mn(H₂O)₆]²⁺', '[Fe(H₂O)₆]²⁺'],
        correctOption: 0,
        solutionEn: 'Cu²⁺ is d⁹: (t₂g)⁶ (eg)³. Asymmetric eg filling produces strong tetragonal elongation along z-axis.',
        solutionHi: 'Cu²⁺ का विन्यास d⁹ है: (t₂g)⁶ (eg)³। असममित eg विन्यास प्रबल यान-टेलर विकृति उत्पन्न करता है।',
        topperTrickEn: 'Universal mnemonic: Cu²⁺ (d⁹) is the textbook hallmark of Jahn-Teller distortion.',
        topperTrickHi: 'याद रखें: Cu²⁺ (d⁹) यान-टेलर प्रभाव का सबसे प्रमुख उदाहरण है।',
      },
    ],
  },
  {
    id: 'pyq-sheet-chem-02',
    chapter: 'Organic Reaction Mechanisms Sheet',
    chapterHindi: 'कार्बनिक अभिक्रिया क्रियाविधि पीवाईक्यू शीट',
    subject: 'Chemistry',
    yearCoverage: '2010–2026',
    questionsCount: 75,
    totalMarks: 300,
    topSubtopics: ['Aldol Condensation', 'Cannizzaro Disproportionation', 'Reagents Selectivity', 'Carbocation Rearrangements'],
    topSubtopicsHindi: ['एल्डोल संघनन', 'कैनिजारो अभिक्रिया', 'अभिकर्मक चयनशीलता', 'कार्बधनायन पुनर्विन्यास'],
    exemplarQuestions: [
      {
        year: 2024,
        exam: 'JEE Main',
        questionEn: 'Which aldehyde undergoes Cannizzaro reaction on treatment with 50% aqueous KOH?',
        questionHi: '50% जलीय KOH के साथ उपचारित करने पर कौन-सा एल्डिहाइड कैनिजारो अभिक्रिया करता है?',
        optionsEn: ['Benzaldehyde (C₆H₅CHO)', 'Acetaldehyde (CH₃CHO)', 'Propionaldehyde (CH₃CH₂CHO)', 'Acetone (CH₃COCH₃)'],
        optionsHi: ['बेन्जैल्डिहाइड (C₆H₅CHO)', 'ऐसीटैल्डिहाइड (CH₃CHO)', 'प्रोपियोनैल्डिहाइड (CH₃CH₂CHO)', 'ऐसीटोन (CH₃COCH₃)'],
        correctOption: 0,
        solutionEn: 'Benzaldehyde has zero α-hydrogens, hence undergoes Cannizzaro disproportionation to benzyl alcohol and benzoate.',
        solutionHi: 'बेन्जैल्डिहाइड में कोई α-हाइड्रोजन नहीं होता, अतः यह कैनिजारो अभिक्रिया द्वारा बेन्जिल ऐल्कोहॉल व बेन्जोएट बनाता है।',
        topperTrickEn: 'No α-H = Cannizzaro. Has α-H = Aldol condensation. 5 second question!',
        topperTrickHi: 'α-H अनुपस्थित = कैनिजारो। α-H उपस्थित = एल्डोल। 5 सेकंड का सवाल!',
      },
    ],
  },

  // --- MATHEMATICS SHEETS ---
  {
    id: 'pyq-sheet-math-01',
    chapter: 'Vectors & 3D Geometry Sheet',
    chapterHindi: 'सदिश एवं त्रिविमीय ज्यामिति पीवाईक्यू शीट',
    subject: 'Mathematics',
    yearCoverage: '2010–2026',
    questionsCount: 75,
    totalMarks: 300,
    topSubtopics: ['Shortest Distance Skew Lines', 'Scalar Triple Product', 'Plane & Line Intersection', 'Foot of Perpendicular'],
    topSubtopicsHindi: ['विषमतलीय रेखाओं की न्यूनतम दूरी', 'अदिश त्रिगुणन', 'समतल व रेखा प्रतिच्छेदन', 'लंबपाद'],
    exemplarQuestions: [
      {
        year: 2025,
        exam: 'JEE Main',
        questionEn: 'The shortest distance between lines r = (i + 2j + 3k) + λ(2i + 3j + 4k) and r = (2i + 4j + 5k) + μ(3i + 4j + 5k) is:',
        questionHi: 'रेखाओं r = (i + 2j + 3k) + λ(2i + 3j + 4k) तथा r = (2i + 4j + 5k) + μ(3i + 4j + 5k) के मध्य न्यूनतम दूरी होगी:',
        optionsEn: ['1 / √6', '2 / √6', '1 / 3', '√6'],
        optionsHi: ['1 / √6', '2 / √6', '1 / 3', '√6'],
        correctOption: 0,
        solutionEn: 'd = |(a₂ - a₁) · (b₁ × b₂)| / |b₁ × b₂|. Here a₂ - a₁ = i + 2j + 2k. b₁ × b₂ = -i + 2j - k. Numerator = |-1 + 4 - 2| = 1. Denominator = √(1+4+1) = √6. d = 1/√6.',
        solutionHi: 'd = |(a₂ - a₁) · (b₁ × b₂)| / |b₁ × b₂| = |(1,2,2) · (-1,2,-1)| / √6 = 1 / √6.',
        topperTrickEn: 'Compute dot product directly without expanding full determinant: saves 45 seconds!',
        topperTrickHi: 'अदिश त्रिगुणन का मान सीधे निकालें, 45 सेकंड बचेंगे!',
      },
    ],
  },
  {
    id: 'pyq-sheet-math-02',
    chapter: 'Definite Integrals & Calculus Sheet',
    chapterHindi: 'निश्चित समाकलन एवं कलन पीवाईक्यू शीट',
    subject: 'Mathematics',
    yearCoverage: '2010–2026',
    questionsCount: 75,
    totalMarks: 300,
    topSubtopics: ['King\'s Property', 'Leibnitz Rule of Limits', 'Area Under Curves', 'Linear Differential Equations'],
    topSubtopicsHindi: ['किंग्स प्रॉपर्टी', 'लेबनिज नियम', 'वक्रों का क्षेत्रफल', 'रैखिक अवकल समीकरण'],
    exemplarQuestions: [
      {
        year: 2024,
        exam: 'JEE Advanced',
        questionEn: 'The value of integral I = ∫[0 to π/2] (sin⁴ x) / (sin⁴ x + cos⁴ x) dx is:',
        questionHi: 'समाकल I = ∫[0 to π/2] (sin⁴ x) / (sin⁴ x + cos⁴ x) dx का मान है:',
        optionsEn: ['π / 4', 'π / 2', 'π / 8', '0'],
        optionsHi: ['π / 4', 'π / 2', 'π / 8', '0'],
        correctOption: 0,
        solutionEn: 'Apply King\'s property x → π/2 - x: I = ∫[0 to π/2] cos⁴ x / (cos⁴ x + sin⁴ x) dx. Adding 2I = ∫[0 to π/2] 1 dx = π/2 ⇒ I = π/4.',
        solutionHi: 'किंग्स प्रॉपर्टी लगाने पर: 2I = ∫[0 से π/2] 1 dx = π/2, अतः I = π/4.',
        topperTrickEn: 'Symmetric integrand over [0, π/2]: the answer is ALWAYS (upper - lower)/2 = π/4 in 3 seconds!',
        topperTrickHi: 'सममित समाकल का उत्तर सदैव (ऊपरी सीमा - निचली सीमा)/2 = π/4 होता है।',
      },
    ],
  },
];
