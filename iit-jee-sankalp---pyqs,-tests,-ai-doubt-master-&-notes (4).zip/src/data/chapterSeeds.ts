import { Difficulty, ExamType } from '../types';

export interface ChapterSeedDef {
  subtopic: string;
  difficulty: Difficulty;
  questionTemplate: (year: number, exam: ExamType, variant: number) => string;
  optionsTemplate: (variant: number) => [string, string, string, string];
  correctOptionIndex: number;
  solutionTemplate: (year: number, variant: number) => string;
  keyFormula: string;
  topperTrick: string;
}

// ==========================================
// 1. ROTATIONAL MOTION & MECHANICS SEEDS
// ==========================================
export const rotationalMechanicsSeeds: ChapterSeedDef[] = [
  {
    subtopic: 'Pure Rolling on Inclined Plane',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] A solid cylinder of mass M and radius R rolls without slipping down an inclined plane of inclination θ = ${25 + v * 5}°. The magnitude of the acceleration of its center of mass is:`,
    optionsTemplate: (v) => [
      `(2/3) g sin(${25 + v * 5}°)`,
      `(1/2) g sin(${25 + v * 5}°)`,
      `(3/4) g sin(${25 + v * 5}°)`,
      `g sin(${25 + v * 5}°)`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Acceleration of center of mass in pure rolling on incline:
   a_com = g sin θ / (1 + I_com / (M R²))
2. For solid cylinder, I_com = (1/2) M R² ⇒ I_com / (M R²) = 1/2.
3. Therefore:
   a_com = g sin(${25 + v * 5}°) / (1 + 1/2) = (2/3) g sin(${25 + v * 5}°).`,
    keyFormula: 'a_com = g sin θ / (1 + k²/R²); for cylinder k²/R² = 1/2 ⇒ a = (2/3)g sin θ',
    topperTrick: 'Standard ratios: Ring (1/2), Disc/Cylinder (2/3), Solid sphere (5/7). Always commit this ranking to memory!',
  },
  {
    subtopic: 'Angular Momentum Conservation in Inelastic Collision',
    difficulty: 'IIT Advanced Level',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] A uniform rod of mass ${v + 1}M and length L lies on a frictionless horizontal plane, pivoted at one end O. A particle of mass M moving perpendicularly with speed v₀ strikes the rod at distance ${v === 1 ? 'L/2' : 'L'} from O and sticks to it. The angular velocity of the system just after collision is:`,
    optionsTemplate: (v) => [
      `3 v₀ / [(${v + 1} + 3) L]`,
      `6 v₀ / [(${v + 1} + 3) L]`,
      `2 v₀ / [(${v + 1} + 1) L]`,
      `v₀ / [(${v + 1}) L]`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. No external torque about the fixed pivot O ⇒ Angular momentum L_O is conserved.
2. Initial angular momentum L_i = M · v₀ · d.
3. Moment of inertia after collision:
   I_total = (1/3)(${v + 1}M)L² + M d²
4. Equating L_i = I_total · ω gives the final angular speed ω.`,
    keyFormula: 'τ_ext = 0 ⇒ L_initial = L_final about pivot point O',
    topperTrick: 'Always calculate torque about the pivot point so that reaction forces exert zero torque!',
  },
  {
    subtopic: 'Toppling vs Sliding Condition',
    difficulty: 'Challenging',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] A uniform cubical block of side a and mass M is placed on a rough horizontal surface with coefficient of friction μ = ${0.2 + v * 0.1}. A horizontal force F is applied at height h = ${0.6 + v * 0.05}a above the surface. If the block topples before sliding, the minimum value of μ must satisfy:`,
    optionsTemplate: (v) => [
      `μ > a / (2h)`,
      `μ < a / (2h)`,
      `μ > h / (2a)`,
      `μ = h / a`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Condition for sliding: F ≥ μ M g ⇒ F_slide = μ M g.
2. Condition for toppling about the front edge:
   Torque of F about front edge balances normal force:
   F · h = M g · (a/2) ⇒ F_topple = M g a / (2h).
3. For toppling before sliding:
   F_topple < F_slide ⇒ M g a / (2h) < μ M g ⇒ μ > a / (2h).`,
    keyFormula: 'Topple before sliding condition: μ > (base width) / (2 × force height) = a / (2h)',
    topperTrick: 'If surface is very rough (high μ), the block will always topple rather than slide.',
  },
  {
    subtopic: 'Moment of Inertia of Truncated Disc',
    difficulty: 'Challenging',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] From a uniform circular disc of radius R and mass ${v + 8}M, a concentric circular hole of radius R/2 is cut out. The moment of inertia of the remaining annular disc about an axis passing through its center and perpendicular to its plane is:`,
    optionsTemplate: (v) => [
      `(5/8) M_rem R²`,
      `(3/4) M_rem R²`,
      `(1/2) M_rem R²`,
      `(7/12) M_rem R²`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Area of complete disc = π R²; Area of hole = π (R/2)² = π R² / 4.
2. Remaining area = 3/4 π R².
3. For an annular disc of inner radius R₁ and outer radius R₂:
   I = (1/2) M_rem (R₁² + R₂²)
   With R₁ = R/2 and R₂ = R:
   I = (1/2) M_rem [ (R/2)² + R² ] = (1/2) M_rem (5/4 R²) = (5/8) M_rem R².`,
    keyFormula: 'I_annular = (1/2) M (R_inner² + R_outer²)',
    topperTrick: 'Never subtract masses blindly; use the standard ring integration formula (1/2)M(R₁² + R₂²)!',
  },
  {
    subtopic: 'Radius of Gyration & Instantaneous Center',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] A thin uniform spherical shell of mass M and radius R rolls without slipping on a horizontal surface with linear speed v. The total kinetic energy of the shell is:`,
    optionsTemplate: (v) => [
      `(5/6) M v²`,
      `(7/10) M v²`,
      `(1/2) M v²`,
      `(3/4) M v²`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Total KE = KE_trans + KE_rot = (1/2) M v² + (1/2) I_com ω².
2. For hollow spherical shell, I_com = (2/3) M R².
3. In pure rolling, ω = v / R.
4. Total KE = (1/2) M v² + (1/2)(2/3 M R²)(v/R)² = (1/2) M v² + (1/3) M v² = (5/6) M v².`,
    keyFormula: 'KE_total = (1/2) M v² (1 + k²/R²); for spherical shell k²/R² = 2/3 ⇒ KE = (5/6) M v²',
    topperTrick: 'Solid sphere is 7/10 Mv², spherical shell is 5/6 Mv², disc is 3/4 Mv².',
  },
];

// ==========================================
// 2. ELECTRODYNAMICS & CAPACITORS SEEDS
// ==========================================
export const electrodynamicsSeeds: ChapterSeedDef[] = [
  {
    subtopic: 'Variable Dielectric Capacitor',
    difficulty: 'IIT Advanced Level',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] A parallel plate capacitor of plate area A and separation d is filled with a dielectric whose dielectric constant varies linearly from k₁ = ${v + 1} to k₂ = ${v + 4} from x = 0 to x = d. The effective capacitance of the capacitor is:`,
    optionsTemplate: (v) => [
      `[ε₀ A (k₂ - k₁)] / [d · ln(k₂ / k₁)]`,
      `[ε₀ A (k₁ + k₂)] / (2d)`,
      `[2 ε₀ A k₁ k₂] / [d (k₁ + k₂)]`,
      `[ε₀ A] / [d · ln(k₂ / k₁)]`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Consider an infinitesimal thin slice of thickness dx at distance x.
2. Dielectric constant: k(x) = k₁ + (k₂ - k₁)(x / d).
3. Capacitance of element: dC = k(x) ε₀ A / dx.
4. Slices are in series:
   1/C = ∫₀ᵈ (1 / dC) = ∫₀ᵈ dx / [k(x) ε₀ A]
   1/C = [d / (ε₀ A (k₂ - k₁))] · ln(k₂ / k₁)
5. Inverting gives C = [ε₀ A (k₂ - k₁)] / [d · ln(k₂ / k₁)].`,
    keyFormula: 'Series integration: 1/C = ∫ dx / (ε₀ k(x) A)',
    topperTrick: 'Logarithmic ratio ln(k₂/k₁) always appears when dielectric variation is linear in x in series.',
  },
  {
    subtopic: 'Faraday Motional EMF in Rotating Rod',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] A metallic rod of length L = ${v + 1} m rotates with uniform angular velocity ω = ${10 + v * 5} rad/s about an axis passing through one end in a uniform magnetic field B = 0.5 T perpendicular to plane of rotation. The induced EMF between its ends is:`,
    optionsTemplate: (v) => [
      `${(0.5 * 0.5 * (10 + v * 5) * (v + 1) ** 2).toFixed(1)} V`,
      `${(0.5 * (10 + v * 5) * (v + 1) ** 2).toFixed(1)} V`,
      `${(2 * (10 + v * 5) * (v + 1)).toFixed(1)} V`,
      `${(0.25 * (10 + v * 5) * (v + 1)).toFixed(1)} V`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Induced EMF for rotating rod about one end:
   |ε| = ∫₀ᴸ B v dx = ∫₀ᴸ B (ω x) dx = (1/2) B ω L²
2. Substituting values:
   |ε| = (1/2) × 0.5 × (${10 + v * 5}) × (${v + 1})² = ${(0.5 * 0.5 * (10 + v * 5) * (v + 1) ** 2).toFixed(1)} V.`,
    keyFormula: 'EMF of rotating rod |ε| = (1/2) B ω L²',
    topperTrick: 'Notice factor 1/2 comes directly from integrating x dx over length L.',
  },
  {
    subtopic: 'Transient RL Circuit Decay & Energy',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] In an LR circuit connected to an ideal battery of EMF V, the current reaches ${63 + v}% of its maximum steady-state value in time t = τ (one time constant). The magnetic energy stored in the inductor at this instant is:`,
    optionsTemplate: (v) => [
      `0.40 U_max`,
      `0.63 U_max`,
      `0.50 U_max`,
      `0.25 U_max`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Current in LR circuit at t = τ:
   i(τ) = I₀ (1 - e⁻¹) ≈ 0.632 I₀.
2. Magnetic energy stored:
   U = (1/2) L i² = (1/2) L (0.632 I₀)² = (0.632)² · U_max ≈ 0.40 U_max.`,
    keyFormula: 'U = (1/2) L i²; U(τ) = (1 - 1/e)² U_max ≈ (0.632)² U_max ≈ 0.40 U_max',
    topperTrick: 'Energy depends on i²! So at 63% current, energy is NOT 63%, but (0.63)² ≈ 40%!',
  },
  {
    subtopic: 'Gauss Law with Non-Uniform Charge Density',
    difficulty: 'IIT Advanced Level',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] A solid sphere of radius R has a non-uniform volumetric charge density ρ(r) = ρ₀ (1 - r/R) for r ≤ R. The electric field at radial distance r < R from the center is:`,
    optionsTemplate: (v) => [
      `[ρ₀ r / (3 ε₀)] [1 - (3r / (4R))]`,
      `[ρ₀ r / (4 ε₀)] [1 - (r / R)]`,
      `[ρ₀ r² / (3 ε₀ R)]`,
      `[ρ₀ / ε₀] [1 - (r / (2R))]`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Gauss Law: E(r) · (4π r²) = q_enclosed / ε₀.
2. q_enclosed = ∫₀ʳ ρ(r') 4π r'² dr' = 4π ρ₀ ∫₀ʳ (r'² - r'³/R) dr'
   = 4π ρ₀ [ (r³/3) - (r⁴ / (4R)) ].
3. E(r) = [ρ₀ r / (3 ε₀)] [ 1 - 3r / (4R) ].`,
    keyFormula: 'E · 4πr² = (1/ε₀) ∫₀ʳ ρ(r) 4π r² dr',
    topperTrick: 'Check limits: as r → 0, E → 0; coefficient of first term must match uniform sphere (ρ₀ r / 3ε₀).',
  },
  {
    subtopic: 'Magnetic Force & Cyclotron Radius',
    difficulty: 'Easy',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] A proton and an alpha particle are accelerated through the same potential difference V and then enter a uniform transverse magnetic field B. The ratio of the radii of their circular paths (r_p / r_α) is:`,
    optionsTemplate: (v) => [
      `1 / √2`,
      `1 / 2`,
      `√2 / 1`,
      `2 / 1`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Radius in magnetic field: r = p / (q B) = √(2 m q V) / (q B) = (1/B) · √(2 m V / q).
2. r ∝ √(m / q).
3. For proton: m_p = m, q_p = e ⇒ √(m/e).
4. For alpha particle: m_α = 4m, q_α = 2e ⇒ √(4m / 2e) = √(2) · √(m/e).
5. Ratio r_p / r_α = 1 / √2.`,
    keyFormula: 'r = √(2 m q V) / (q B) = (1/B) √(2 m V / q)',
    topperTrick: 'For same potential V, r ∝ √(m/q). Proton: √(1/1) = 1. Alpha: √(4/2) = √2. Ratio = 1/√2.',
  },
];

// ==========================================
// 3. MODERN PHYSICS SEEDS
// ==========================================
export const modernPhysicsSeeds: ChapterSeedDef[] = [
  {
    subtopic: 'Einstein Photoelectric Equation & Stopping Potential',
    difficulty: 'Easy',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] When light of wavelength λ is incident on a metal surface, the stopping potential is ${3 + v} V₀. When light of wavelength ${v + 2}λ is incident on the same surface, stopping potential becomes V₀. The threshold wavelength λ₀ for this metal is:`,
    optionsTemplate: (v) => [
      `${(2 * v + 3)} λ`,
      `${(v + 3)} λ`,
      `${(3 * v + 2)} λ`,
      `2 λ`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. e V_s = h c / λ - h c / λ₀.
2. Case 1: e (${3 + v} V₀) = h c / λ - h c / λ₀.
3. Case 2: e V₀ = h c / [(${v + 2})λ] - h c / λ₀.
4. Multiply Case 2 by (${3 + v}) and equate to eliminate V₀:
   h c / λ - h c / λ₀ = (${3 + v}) [ h c / ((${v + 2})λ) - h c / λ₀ ].
5. Solving gives λ₀ = ${(2 * v + 3)} λ.`,
    keyFormula: 'eV_s = hc/λ - hc/λ₀',
    topperTrick: 'Set up ratio: (eV₁ + W) / (eV₂ + W) = λ₂ / λ₁ to solve in 30 seconds.',
  },
  {
    subtopic: 'Bohr Radius & Orbit Transition Energy',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The ionization energy of a hydrogen-like atom of atomic number Z is ${13.6 * ((v + 1) ** 2)} eV. The wavelength of photon emitted when an electron jumps from n = 3 to n = 2 in this atom is:`,
    optionsTemplate: (v) => [
      `656.3 / ${((v + 1) ** 2)} nm`,
      `121.6 / ${(v + 1)} nm`,
      `486.1 / ${((v + 1) ** 2)} nm`,
      `102.5 / ${(v + 1)} nm`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Ionization energy = 13.6 · Z² eV ⇒ Z = ${v + 1}.
2. Energy of transition 3 → 2 in Hydrogen is 1.89 eV (λ = 656.3 nm).
3. For hydrogen-like atom with atomic number Z, ΔE ∝ Z² ⇒ λ ∝ 1/Z².
4. Hence, λ = 656.3 / Z² = 656.3 / ${((v + 1) ** 2)} nm.`,
    keyFormula: '1/λ = R Z² (1/n₁² - 1/n₂²)',
    topperTrick: 'Wavelength scales as 1/Z²! Calculate H-atom wavelength and divide directly by Z².',
  },
  {
    subtopic: 'Radioactive Decay & Successive Disintegration',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] A radioactive substance decays to 1/${2 ** (v + 2)} of its initial activity in ${15 * (v + 2)} minutes. The half-life of the radioactive substance is:`,
    optionsTemplate: (v) => [
      `15 minutes`,
      `30 minutes`,
      `10 minutes`,
      `45 minutes`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Activity A(t) = A₀ (1/2)^n, where n is number of half-lives.
2. Given A(t) / A₀ = 1 / ${2 ** (v + 2)} = (1/2)^${v + 2} ⇒ n = ${v + 2} half-lives.
3. Total time t = n · T_half = ${15 * (v + 2)} minutes.
4. T_half = ${15 * (v + 2)} / (${v + 2}) = 15 minutes.`,
    keyFormula: 'N(t) = N₀ (1/2)^(t / T_half)',
    topperTrick: 'Count powers of 2 directly: 1/4 = 2 half-lives, 1/8 = 3 half-lives, 1/16 = 4 half-lives.',
  },
  {
    subtopic: 'De Broglie Wavelength of Relativistic & Accelerated Particle',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] An electron is accelerated from rest through a potential difference of V = ${100 + v * 50} Volts. Its de Broglie wavelength is approximately:`,
    optionsTemplate: (v) => [
      `${(12.27 / Math.sqrt(100 + v * 50)).toFixed(2)} Å`,
      `${(1.227 / Math.sqrt(100 + v * 50)).toFixed(2)} Å`,
      `${(0.1227 * Math.sqrt(100 + v * 50)).toFixed(2)} Å`,
      `${(122.7 / (100 + v * 50)).toFixed(2)} Å`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. De Broglie wavelength of accelerated electron:
   λ = h / √(2 m e V) = 12.27 / √V Å.
2. For V = ${100 + v * 50} V:
   λ = 12.27 / √(${100 + v * 50}) = ${(12.27 / Math.sqrt(100 + v * 50)).toFixed(2)} Å.`,
    keyFormula: 'λ_electron = 12.27 / √V Å = 1.227 / √V nm',
    topperTrick: 'Standard constant: 12.27 / √V in Angstroms is memorized by all 99+ percentile students.',
  },
  {
    subtopic: 'Nuclear Binding Energy & Q-Value',
    difficulty: 'Challenging',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] A heavy nucleus X of mass number A = 240 has binding energy per nucleon of 7.6 MeV. It splits into two identical fragments Y (A = 120) with binding energy per nucleon of 8.5 MeV. The total Q-value released in the fission reaction is:`,
    optionsTemplate: (v) => [
      `216 MeV`,
      `180 MeV`,
      `108 MeV`,
      `360 MeV`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Total initial BE of nucleus X = 240 × 7.6 MeV = 1824 MeV.
2. Total final BE of two fragments = 2 × (120 × 8.5 MeV) = 2040 MeV.
3. Energy released Q = BE_final - BE_initial = 2040 - 1824 = 216 MeV.`,
    keyFormula: 'Q = Total BE_products - Total BE_reactants',
    topperTrick: 'Q = A · (BE/A_final - BE/A_initial) = 240 · (8.5 - 7.6) = 240 × 0.9 = 216 MeV. Done in 5 seconds!',
  },
];

// ==========================================
// 4. THERMODYNAMICS, FLUIDS & OPTICS SEEDS
// ==========================================
export const thermoFluidsOpticsSeeds: ChapterSeedDef[] = [
  {
    subtopic: 'Polytropic Gas Process Heat Capacity',
    difficulty: 'Challenging',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] An ideal monoatomic gas undergoes a polytropic process represented by P · V^${1 + v * 0.5} = constant. The molar heat capacity C of the gas for this process is:`,
    optionsTemplate: (v) => [
      `${(1.5 + 1 / (1 - (1 + v * 0.5))).toFixed(2)} R`,
      `${(2.5 + 1 / (1 - (1 + v * 0.5))).toFixed(2)} R`,
      `1.50 R`,
      `0.50 R`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. For a polytropic process P V^n = constant:
   C = C_v + R / (1 - n)
2. For monoatomic gas, C_v = (3/2) R = 1.5 R.
3. n = ${1 + v * 0.5}.
4. C = 1.5 R + R / (1 - ${1 + v * 0.5}) = ${(1.5 + 1 / (1 - (1 + v * 0.5))).toFixed(2)} R.`,
    keyFormula: 'C = C_v + R / (1 - n)',
    topperTrick: 'Notice if n > 1, the second term is negative! Gas can absorb heat while temperature drops.',
  },
  {
    subtopic: 'Carnot Engine Efficiency with Dual Reservoirs',
    difficulty: 'Easy',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] A Carnot engine operates between temperatures T_H = ${500 + v * 100} K and T_C = ${300 + v * 50} K. If the engine absorbs ${1000 + v * 200} J of heat from the high-temperature reservoir per cycle, the work output per cycle is:`,
    optionsTemplate: (v) => [
      `${Math.round((1000 + v * 200) * (1 - (300 + v * 50) / (500 + v * 100)))} J`,
      `${Math.round((1000 + v * 200) * ((300 + v * 50) / (500 + v * 100)))} J`,
      `${(1000 + v * 200) / 2} J`,
      `400 J`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Carnot efficiency η = 1 - T_C / T_H = 1 - (${300 + v * 50} / ${500 + v * 100}).
2. Work done W = η · Q_in = [1 - (${300 + v * 50} / ${500 + v * 100})] · (${1000 + v * 200})
   W = ${Math.round((1000 + v * 200) * (1 - (300 + v * 50) / (500 + v * 100)))} J.`,
    keyFormula: 'η = W / Q_H = 1 - T_C / T_H',
    topperTrick: 'Always use absolute temperature in Kelvin! Never plug in Celsius.',
  },
  {
    subtopic: 'Bernoulli Principle & Torricelli Efflux',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] A large open cylindrical tank of height H is filled with water. A small hole is punched at depth h = H / ${v + 2} below the water surface. The horizontal range of the water jet emerging on the ground is:`,
    optionsTemplate: (v) => [
      `2 √[ (H / ${v + 2}) · (${v + 1}H / ${v + 2}) ]`,
      `√[ (H / ${v + 2}) · (${v + 1}H / ${v + 2}) ]`,
      `2 H / ${v + 2}`,
      `H / 2`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Speed of efflux v = √(2 g h) = √(2 g H / ${v + 2}).
2. Height of hole above ground: y = H - h = (${v + 1})H / ${v + 2}.
3. Time of flight to ground: t = √(2 y / g).
4. Horizontal range: R = v · t = √(2 g h) · √(2 y / g) = 2 √(h · y)
   R = 2 √[ (H / ${v + 2}) · (${v + 1}H / ${v + 2}) ].`,
    keyFormula: 'Range R = 2 √(h · (H - h)); Maximum range R_max = H when h = H/2',
    topperTrick: 'Symmetry property: holes at depth h and (H - h) yield identical horizontal ranges!',
  },
  {
    subtopic: 'Young Double Slit Interference with Dielectric Sheet',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] In a standard YDSE with light of wavelength λ = 600 nm, a thin transparent sheet of refractive index μ = 1.5 and thickness t is placed in front of one slit. If the central bright fringe shifts by ${v + 2} fringe widths, the thickness t is:`,
    optionsTemplate: (v) => [
      `${((v + 2) * 600 / (1.5 - 1)).toFixed(0)} nm`,
      `${((v + 2) * 600 / 1.5).toFixed(0)} nm`,
      `${((v + 2) * 300).toFixed(0)} nm`,
      `1200 nm`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Optical path difference introduced by sheet of thickness t:
   Δx = (μ - 1) t.
2. Shift in fringe pattern:
   Shift = (D / d) (μ - 1) t = n · β = n · (λ D / d)
   ⇒ (μ - 1) t = n · λ.
3. Given n = ${v + 2}, λ = 600 nm, μ = 1.5:
   (1.5 - 1) t = (${v + 2}) × 600 nm
   t = (${v + 2} × 600) / 0.5 = ${((v + 2) * 600 / (1.5 - 1)).toFixed(0)} nm.`,
    keyFormula: 'Fringe shift n = (μ - 1) t / λ',
    topperTrick: 'Number of fringes shifted is simply the extra optical path (μ - 1)t divided by λ.',
  },
  {
    subtopic: 'Prism Angle of Minimum Deviation',
    difficulty: 'Easy',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] A glass prism has a refracting angle A = 60°. If the angle of minimum deviation δ_m = 30°, the refractive index μ of the prism material is:`,
    optionsTemplate: (v) => [
      `√2 ≈ 1.414`,
      `√3 ≈ 1.732`,
      `1.50`,
      `1.33`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Prism formula: μ = sin((A + δ_m) / 2) / sin(A / 2).
2. Given A = 60°, δ_m = 30°:
   μ = sin((60° + 30°) / 2) / sin(60° / 2) = sin(45°) / sin(30°)
   μ = (1 / √2) / (1 / 2) = 2 / √2 = √2 ≈ 1.414.`,
    keyFormula: 'μ = sin((A + δ_m)/2) / sin(A/2)',
    topperTrick: 'sin(45°) / sin(30°) = (1/√2)/(1/2) = √2 in 5 seconds!',
  },
];

// ==========================================
// 5. COORDINATION COMPOUNDS & BONDING SEEDS
// ==========================================
export const coordinationBondingSeeds: ChapterSeedDef[] = [
  {
    subtopic: 'Crystal Field Stabilization Energy (CFSE)',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The crystal field stabilization energy (CFSE) of a high-spin octahedral complex of Fe²⁺ (d⁶) ignoring pairing energy is:`,
    optionsTemplate: (v) => [
      `-0.4 Δ_o`,
      `-2.4 Δ_o`,
      `-0.8 Δ_o`,
      `0.0 Δ_o`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Fe²⁺ has electronic configuration [Ar] 3d⁶.
2. In high-spin octahedral field, pairing energy P > Δ_o.
3. Electrons occupy: (t₂g)⁴ (eg)².
4. CFSE = [ -0.4 × (number of t₂g electrons) + 0.6 × (number of eg electrons) ] Δ_o
   CFSE = [ -0.4 × 4 + 0.6 × 2 ] Δ_o = [ -1.6 + 1.2 ] Δ_o = -0.4 Δ_o.`,
    keyFormula: 'CFSE = (-0.4 n_t2g + 0.6 n_eg) Δ_o',
    topperTrick: 'High spin d⁶: 4 electrons in t₂g, 2 in eg. -1.6 + 1.2 = -0.4 Δ_o.',
  },
  {
    subtopic: 'Werner Secondary Valence & Precipitation',
    difficulty: 'Easy',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] When 0.1 mol of CoCl₃ · ${v + 4}NH₃ is treated with excess AgNO₃ solution, exactly ${(v === 1 ? 0.1 : 0.2)} mol of AgCl precipitate is obtained. The secondary valency (coordination number) of cobalt is 6. The formula of the complex is:`,
    optionsTemplate: (v) => [
      `[Co(NH₃)${v + 4}Cl${2 - (v === 1 ? 1 : 2)}]Cl${v === 1 ? '₁' : '₂'}`,
      `[Co(NH₃)${v + 4}Cl₃]`,
      `[Co(NH₃)₆]Cl₃`,
      `[Co(NH₃)₄Cl₂]Cl`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Moles of AgCl precipitated per mole of complex indicates the number of ionizable chloride counter-ions outside the coordination sphere.
2. Given precipitated moles, there are ${(v === 1 ? 1 : 2)} Cl⁻ ions outside the brackets.
3. Keeping total coordination number = 6 completes the primary and secondary valency.`,
    keyFormula: 'Ionizable Cl⁻ outside bracket = moles of AgCl precipitate per mole of complex',
    topperTrick: 'Precipitated Cl⁻ are OUTSIDE the brackets; remaining ligands are INSIDE.',
  },
  {
    subtopic: 'Spin-Only Magnetic Moment',
    difficulty: 'Easy',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The spin-only magnetic moment of [Mn(CN)₆]³⁻ (Mn in +3 oxidation state, CN⁻ is a strong field ligand) is:`,
    optionsTemplate: (v) => [
      `2.84 BM (2 unpaired electrons)`,
      `4.90 BM (4 unpaired electrons)`,
      `1.73 BM (1 unpaired electron)`,
      `0.00 BM (diamagnetic)`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Mn³⁺ is 3d⁴.
2. CN⁻ is a strong field ligand (Δ_o > P), causing pairing in t₂g orbitals.
3. Electronic configuration: (t₂g)⁴ (eg)⁰.
4. Number of unpaired electrons n = 2 (one pair and two single electrons in t₂g).
5. Spin-only magnetic moment:
   μ = √(n(n + 2)) = √(2(4)) = √8 ≈ 2.84 BM.`,
    keyFormula: 'μ = √(n(n + 2)) Bohr Magnetons (BM)',
    topperTrick: 'Integer part of μ always equals number of unpaired electrons! (n=2 ⇒ 2.84 BM).',
  },
  {
    subtopic: 'Molecular Orbital Theory Bond Order & Paramagnetism',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] According to Molecular Orbital Theory (MOT), which of the following species has a fractional bond order and is paramagnetic?`,
    optionsTemplate: (v) => [
      `O₂⁺ (15 electrons, BO = 2.5)`,
      `N₂ (14 electrons, BO = 3.0)`,
      `C₂ (12 electrons, BO = 2.0)`,
      `O₂²⁻ (18 electrons, BO = 1.0)`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. O₂⁺ has 16 - 1 = 15 valence electrons.
2. MOT configuration: σ1s² σ*1s² σ2s² σ*2s² σ2pz² (π2px² = π2py²) (π*2px¹).
3. Bond Order = (10 - 5) / 2 = 2.5.
4. It contains 1 unpaired electron in π*2px orbital, so it is paramagnetic.`,
    keyFormula: 'Bond Order = (N_b - N_a) / 2; Odd electron molecules are always paramagnetic',
    topperTrick: 'Count total electrons: 14 e⁻ = BO 3.0. Each electron added or subtracted changes BO by 0.5!',
  },
  {
    subtopic: 'Optical Isomerism in Octahedral Complexes',
    difficulty: 'Challenging',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] Which of the following complex ions is optically active and does NOT possess any plane of symmetry (plane of symmetry σ = 0)?`,
    optionsTemplate: (v) => [
      `cis-[Co(en)₂Cl₂]⁺`,
      `trans-[Co(en)₂Cl₂]⁺`,
      `[Co(NH₃)₄Cl₂]⁺`,
      `trans-[Pt(NH₃)₂Cl₂]`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. cis-[Co(en)₂Cl₂]⁺ belongs to point group C₂ and lacks both a plane of symmetry and center of inversion.
2. It exists as non-superimposable mirror image enantiomers (d- and l-forms) and is optically active.
3. trans-[Co(en)₂Cl₂]⁺ has an internal horizontal plane of symmetry (meso) and is optically inactive.`,
    keyFormula: 'Optical activity requires absence of improper rotation axis (S_n), specifically plane of symmetry (σ) and center of inversion (i)',
    topperTrick: 'cis-bis(chelate) [M(AA)₂B₂] is ALWAYS optically active, while trans is always inactive.',
  },
];

// ==========================================
// 6. ORGANIC CHEMISTRY SEEDS
// ==========================================
export const organicChemistrySeeds: ChapterSeedDef[] = [
  {
    subtopic: 'Aldol Condensation & Dehydration',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] When benzaldehyde is treated with acetophenone in the presence of dilute NaOH followed by heating (Claisen-Schmidt condensation), the major product formed is:`,
    optionsTemplate: (v) => [
      `Chalcone (1,3-diphenylprop-2-en-1-one)`,
      `Benzyl alcohol and benzoic acid`,
      `Benzophenone`,
      `Cinnamic acid`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Benzaldehyde (C₆H₅CHO) has no α-hydrogen; acetophenone (C₆H₅COCH₃) has 3 α-hydrogens.
2. Base abstracts α-H from acetophenone generating an enolate.
3. Enolate nucleophilically attacks carbonyl carbon of benzaldehyde to form β-hydroxy ketone.
4. Subsequent loss of water upon heating yields conjugated α,β-unsaturated ketone (Chalcone).`,
    keyFormula: 'Cross Aldol: Carbonyl with α-H acts as nucleophile; Carbonyl without α-H acts as electrophile',
    topperTrick: 'Acetophenone provides enolate; benzaldehyde gets attacked; conjugation stabilizes chalcone!',
  },
  {
    subtopic: 'Aromaticity & Hückel 4n+2 Rule',
    difficulty: 'Easy',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] Which of the following cyclic species is aromatic according to Hückel\'s (4n + 2) π-electron rule?`,
    optionsTemplate: (v) => [
      `Tropylium cation (cycloheptatrienyl cation, 6 π electrons)`,
      `Cyclooctatetraene (tub-shaped, 8 π electrons)`,
      `Cyclopentadienyl cation (4 π electrons)`,
      `Cyclobutadiene (4 π electrons)`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Tropylium cation is planar, completely conjugated, cyclic, and possesses 6 delocalized π-electrons (n = 1 in 4n + 2).
2. It exhibits exceptional thermodynamic stability and qualifies as aromatic.
3. Cyclobutadiene and cyclopentadienyl cation have 4 π-electrons (anti-aromatic).
4. Cyclooctatetraene assumes non-planar tub conformation (non-aromatic).`,
    keyFormula: 'Hückel rule: Cyclic + Planar + Fully conjugated + (4n + 2) π electrons = Aromatic',
    topperTrick: 'Tropylium (7-membered ring with +) and Cyclopentadienyl anion (5-membered ring with -) both have 6 π electrons!',
  },
  {
    subtopic: 'SN1 vs SN2 Nucleophilic Substitution Kinetics',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The correct decreasing order of reactivity towards S_N1 solvolysis reaction for the following alkyl halides is: (I) (CH₃)₃C-Br, (II) (C₆H₅)₃C-Br, (III) (CH₃)₂CH-Br:`,
    optionsTemplate: (v) => [
      `(II) > (I) > (III)`,
      `(I) > (II) > (III)`,
      `(III) > (I) > (II)`,
      `(II) > (III) > (I)`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Rate of S_N1 reaction is directly proportional to the stability of the intermediate carbocation formed in the rate-determining step.
2. (C₆H₅)₃C⁺ (triphenylmethyl carbocation) is stabilized by 9 resonance structures across three benzene rings.
3. (CH₃)₃C⁺ is stabilized by 9 hyperconjugative α-hydrogens.
4. (CH₃)₂CH⁺ is a secondary carbocation with only 6 α-hydrogens.
5. Reactivity order: (II) > (I) > (III).`,
    keyFormula: 'S_N1 rate ∝ Carbocation stability (Resonance > Hyperconjugation > Inductive)',
    topperTrick: 'Trityl cation (Ph₃C⁺) is so stable that its salts can even be stored in bottles!',
  },
  {
    subtopic: 'Acidic Strength of Substituted Phenols',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The correct increasing order of pKa values (decreasing acidic strength) of the following compounds is: (I) p-nitrophenol, (II) m-nitrophenol, (III) p-cresol, (IV) phenol:`,
    optionsTemplate: (v) => [
      `(I) < (II) < (IV) < (III)`,
      `(III) < (IV) < (II) < (I)`,
      `(I) < (IV) < (II) < (III)`,
      `(II) < (I) < (IV) < (III)`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Lower pKa corresponds to stronger acid.
2. -NO₂ is strong electron-withdrawing group (-M and -I). At para position, both -M and -I stabilize phenoxide ion ⇒ (I) is strongest acid (lowest pKa).
3. At meta position, -M is inactive; only -I operates ⇒ (II) is second strongest.
4. Phenol has no substituent ⇒ (IV).
5. -CH₃ is electron-donating (+I, hyperconjugation), destabilizing phenoxide ⇒ (III) is weakest acid (highest pKa).
6. Order of pKa: (I) < (II) < (IV) < (III).`,
    keyFormula: 'Acidic strength ∝ -M, -I; pKa = -log Ka (lower pKa = stronger acid)',
    topperTrick: 'Remember: -M resonance operates only at ortho and para positions, NEVER at meta!',
  },
  {
    subtopic: 'Carbocation Rearrangement in Alcohol Dehydration',
    difficulty: 'Challenging',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] Treatment of 3,3-dimethylbutan-2-ol with concentrated H₂SO₄ at 170°C yields the major alkene product:`,
    optionsTemplate: (v) => [
      `2,3-dimethylbut-2-ene (tetrasubstituted alkene)`,
      `3,3-dimethylbut-1-ene`,
      `2,3-dimethylbut-1-ene`,
      `2-methylpent-2-ene`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Protonation of OH followed by loss of water forms a secondary carbocation: (CH₃)₃C-CH⁺-CH₃.
2. A 1,2-methyl shift occurs to form a much more stable tertiary carbocation: (CH₃)₂C⁺-CH(CH₃)₂.
3. Elimination of proton following Saytzeff rule yields the most substituted and thermodynamically stable alkene: 2,3-dimethylbut-2-ene (12 α-hydrogens).`,
    keyFormula: '1,2-Shift driven by 2° → 3° carbocation stability + Saytzeff elimination (most α-H)',
    topperTrick: 'Count α-hydrogens of product: 2,3-dimethylbut-2-ene has 12 α-hydrogens, maximum possible for a 6-carbon alkene!',
  },
];

// ==========================================
// 7. PHYSICAL CHEMISTRY (KINETICS & ELECTROCHEM) SEEDS
// ==========================================
export const physicalChemistrySeeds: ChapterSeedDef[] = [
  {
    subtopic: 'Nernst Equation Cell Potential & Equilibrium',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] For the electrochemical cell Zn(s) | Zn²⁺(aq, ${0.01 * (v + 1)} M) || Cu²⁺(aq, 0.1 M) | Cu(s), given E°(Zn²⁺/Zn) = -0.76 V and E°(Cu²⁺/Cu) = +0.34 V, the EMF of the cell at 298 K is:`,
    optionsTemplate: (v) => [
      `${(1.10 - (0.0591 / 2) * Math.log10((0.01 * (v + 1)) / 0.1)).toFixed(3)} V`,
      `1.100 V`,
      `0.760 V`,
      `0.340 V`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. E°_cell = E°_cathode - E°_anode = +0.34 - (-0.76) = 1.10 V.
2. Cell reaction: Zn(s) + Cu²⁺(aq) ⇌ Zn²⁺(aq) + Cu(s) (n = 2).
3. Reaction quotient Q = [Zn²⁺] / [Cu²⁺] = ${0.01 * (v + 1)} / 0.1.
4. Nernst Equation: E_cell = E°_cell - (0.0591 / n) log Q
   E_cell = 1.10 - (0.0591 / 2) log(${0.01 * (v + 1)} / 0.1) = ${(1.10 - (0.0591 / 2) * Math.log10((0.01 * (v + 1)) / 0.1)).toFixed(3)} V.`,
    keyFormula: 'E_cell = E°_cell - (0.0591/n) log([Anode ion] / [Cathode ion])',
    topperTrick: 'If [Anode] < [Cathode], Q < 1, so log Q is negative and E_cell > E°_cell!',
  },
  {
    subtopic: 'First Order Kinetics & Parallel Reactions',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] A substance A decomposes by two parallel first-order pathways to B and C with rate constants k₁ = ${0.02 * (v + 1)} min⁻¹ and k₂ = ${0.01 * (v + 1)} min⁻¹. The overall half-life of reactant A is:`,
    optionsTemplate: (v) => [
      `${(0.693 / (0.03 * (v + 1))).toFixed(1)} minutes`,
      `${(0.693 / (0.02 * (v + 1))).toFixed(1)} minutes`,
      `${(0.693 / (0.01 * (v + 1))).toFixed(1)} minutes`,
      `50.0 minutes`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. For parallel first-order reactions:
   -d[A]/dt = (k₁ + k₂) [A] ⇒ k_effective = k₁ + k₂.
2. k_effective = ${0.02 * (v + 1)} + ${0.01 * (v + 1)} = ${(0.03 * (v + 1)).toFixed(3)} min⁻¹.
3. Overall half-life:
   t_1/2 = 0.693 / k_effective = 0.693 / ${(0.03 * (v + 1)).toFixed(3)} = ${(0.693 / (0.03 * (v + 1))).toFixed(1)} minutes.`,
    keyFormula: 'k_total = k₁ + k₂; t_1/2 = ln 2 / (k₁ + k₂)',
    topperTrick: 'Never add half-lives! Add the rate constants: 1/t_total = 1/t₁ + 1/t₂.',
  },
  {
    subtopic: 'Kohlrausch Law & Degree of Dissociation',
    difficulty: 'Easy',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The molar conductivity of a ${0.025 * (v + 1)} M weak monobasic acid HA is 19.5 S cm² mol⁻¹. If limiting molar conductivities are λ°(H⁺) = 349.6 and λ°(A⁻) = 40.4 S cm² mol⁻¹, its degree of dissociation α is:`,
    optionsTemplate: (v) => [
      `0.050 (5.0%)`,
      `0.025 (2.5%)`,
      `0.100 (10.0%)`,
      `0.010 (1.0%)`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Limiting molar conductivity:
   Λ°_m(HA) = λ°(H⁺) + λ°(A⁻) = 349.6 + 40.4 = 390.0 S cm² mol⁻¹.
2. Degree of dissociation:
   α = Λ_m / Λ°_m = 19.5 / 390.0 = 0.050 (5.0%).`,
    keyFormula: 'α = Λ_m / Λ°_m; K_a = c α² / (1 - α)',
    topperTrick: '19.5 / 390 = 19.5 / (20 × 19.5) = 1/20 = 0.05. Quick mental cancellation!',
  },
  {
    subtopic: 'Solubility Product with Common Ion Effect',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The solubility product K_sp of Ag₂CrO₄ is 1.1 × 10⁻¹² at 298 K. The molar solubility of Ag₂CrO₄ in a 0.1 M AgNO₃ solution is:`,
    optionsTemplate: (v) => [
      `1.1 × 10⁻¹⁰ M`,
      `1.1 × 10⁻¹¹ M`,
      `3.3 × 10⁻¹⁰ M`,
      `1.0 × 10⁻⁴ M`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Ag₂CrO₄(s) ⇌ 2 Ag⁺(aq) + CrO₄²⁻(aq).
2. In 0.1 M AgNO₃, [Ag⁺] ≈ 0.1 M (due to strong electrolyte common ion).
3. Let solubility be s ⇒ [CrO₄²⁻] = s.
4. K_sp = [Ag⁺]² [CrO₄²⁻] = (0.1)² · s = 1.1 × 10⁻¹².
5. s = 1.1 × 10⁻¹² / 0.01 = 1.1 × 10⁻¹⁰ M.`,
    keyFormula: 'K_sp = [Common Ion]^(stoichiometry) × s',
    topperTrick: 'Ag⁺ is squared because of stoichiometry 2! (0.1)² = 10⁻², so divide K_sp by 10⁻².',
  },
  {
    subtopic: 'Arrhenius Activation Energy & Temperature Coefficient',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The rate constant of a chemical reaction doubles when the temperature is raised from 300 K to 310 K. The activation energy E_a of the reaction is (R = 8.314 J/mol·K, ln 2 = 0.693):`,
    optionsTemplate: (v) => [
      `53.6 kJ/mol`,
      `42.1 kJ/mol`,
      `68.4 kJ/mol`,
      `25.0 kJ/mol`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Arrhenius equation: ln(k₂ / k₁) = (E_a / R) [ 1/T₁ - 1/T₂ ].
2. ln 2 = (E_a / 8.314) [ (310 - 300) / (300 × 310) ]
   0.693 = (E_a / 8.314) [ 10 / 93000 ].
3. E_a = 0.693 × 8.314 × 9300 = 53,584 J/mol ≈ 53.6 kJ/mol.`,
    keyFormula: 'log(k₂/k₁) = (E_a / 2.303 R) [(T₂ - T₁) / (T₁ T₂)]',
    topperTrick: 'Standard rule of thumb: If rate doubles per 10°C near room temp, E_a is approximately 53–54 kJ/mol.',
  },
];

// ==========================================
// 8. DEFINITE INTEGRATION & CALCULUS SEEDS
// ==========================================
export const calculusSeeds: ChapterSeedDef[] = [
  {
    subtopic: "King's Property of Definite Integrals",
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The value of the definite integral I = ∫₀^(π/2) [ sin^${v + 2}(x) / (sin^${v + 2}(x) + cos^${v + 2}(x)) ] dx is:`,
    optionsTemplate: (v) => [
      `π / 4`,
      `π / 2`,
      `1`,
      `0`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Apply King's Property: ∫_a^b f(x) dx = ∫_a^b f(a + b - x) dx.
2. Here a + b = 0 + π/2 = π/2:
   x → π/2 - x ⇒ sin(π/2 - x) = cos x, cos(π/2 - x) = sin x.
3. I = ∫₀^(π/2) [ cos^${v + 2}(x) / (cos^${v + 2}(x) + sin^${v + 2}(x)) ] dx.
4. Adding the two expressions:
   2I = ∫₀^(π/2) 1 dx = π/2 ⇒ I = π / 4.`,
    keyFormula: '∫₀^a f(x) dx = ∫₀^a f(a - x) dx ⇒ 2I = ∫₀^a 1 dx = a ⇒ I = a/2',
    topperTrick: 'Whenever denominator is f(x) + f(a-x) and numerator is f(x), answer is ALWAYS (b - a)/2 = π/4!',
  },
  {
    subtopic: 'Limit of a Riemann Sum',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The value of the limit L = lim_(n → ∞) ∑_(r=1)^n [ r^${v + 1} / (n^${v + 2} + r^${v + 2}) ] is equal to:`,
    optionsTemplate: (v) => [
      `[1 / (${v + 2})] ln 2`,
      `ln 2`,
      `1 / (${v + 2})`,
      `π / 4`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Factor out n^${v + 2} from denominator:
   L = lim_(n → ∞) (1/n) ∑_(r=1)^n [ (r/n)^${v + 1} / (1 + (r/n)^${v + 2}) ].
2. Convert to definite integral by substituting r/n = x and 1/n = dx:
   L = ∫₀¹ [ x^${v + 1} / (1 + x^${v + 2}) ] dx.
3. Let u = 1 + x^${v + 2} ⇒ du = (${v + 2}) x^${v + 1} dx:
   L = [1 / (${v + 2})] ∫₁² du / u = [1 / (${v + 2})] ln 2.`,
    keyFormula: 'lim_(n→∞) (1/n) ∑ f(r/n) = ∫₀¹ f(x) dx',
    topperTrick: 'Substitute r/n → x, 1/n → dx, and integration limits are 0 to 1.',
  },
  {
    subtopic: 'First Order Linear Differential Equation',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The integrating factor of the linear differential equation (x² + 1) dy/dx + ${2 * (v + 1)} x y = 4 x² is:`,
    optionsTemplate: (v) => [
      `(x² + 1)^${v + 1}`,
      `e^(x² + 1)`,
      `ln(x² + 1)`,
      `x² + 1`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Standard form: dy/dx + P(x) y = Q(x).
2. P(x) = ${2 * (v + 1)} x / (x² + 1).
3. Integrating Factor IF = e^(∫ P(x) dx):
   ∫ [ ${2 * (v + 1)} x / (x² + 1) ] dx = (${v + 1}) ln(x² + 1) = ln[(x² + 1)^${v + 1}].
4. IF = e^(ln[(x² + 1)^${v + 1}]) = (x² + 1)^${v + 1}.`,
    keyFormula: 'IF = e^(∫ P dx)',
    topperTrick: 'Derivative of (x²+1) is 2x. Pull out (${v + 1}) power directly into the logarithm!',
  },
  {
    subtopic: 'Area Bounded Between Curves',
    difficulty: 'Challenging',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The area of the region bounded between the parabola y² = ${4 * (v + 1)} x and the straight line y = ${v + 1} x is:`,
    optionsTemplate: (v) => [
      `${(8 / (3 * (v + 1))).toFixed(2)} sq units`,
      `${(16 / (3 * (v + 1))).toFixed(2)} sq units`,
      `4.00 sq units`,
      `8.00 sq units`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Points of intersection:
   (${v + 1} x)² = 4 (${v + 1}) x ⇒ (${v + 1})² x² - 4 (${v + 1}) x = 0
   x = 0 and x = 4 / (${v + 1}).
2. Area = ∫₀^[4/(${v + 1})] [ √(4(${v + 1})x) - (${v + 1})x ] dx
   = 2√(${v + 1}) · (2/3) x^(3/2) - (${v + 1}) x² / 2 evaluated from 0 to 4/(${v + 1}).
3. Standard formula for area between y² = 4ax and y = mx:
   Area = 8 a² / (3 m³).
   Here 4a = 4(${v + 1}) ⇒ a = ${v + 1}, and m = ${v + 1}.
   Area = 8 (${v + 1})² / [ 3 (${v + 1})³ ] = 8 / [3 (${v + 1})].`,
    keyFormula: 'Area between y² = 4ax and y = mx is 8a² / (3m³)',
    topperTrick: 'Never integrate from scratch! Use Kota speed formula Area = 8a² / (3m³).',
  },
  {
    subtopic: 'Differentiability of Piecewise Modulus Function',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The number of points where the function f(x) = |x - 1| + |x - ${v + 2}| + |x - ${v + 4}| is NOT differentiable is:`,
    optionsTemplate: (v) => [
      `3 points (at x = 1, ${v + 2}, ${v + 4})`,
      `1 point`,
      `2 points`,
      `0 points (differentiable everywhere)`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Modulus function |x - c| has a sharp corner (vertex) at its zero x = c.
2. The left-hand derivative (LHD) and right-hand derivative (RHD) differ by 2 at each vertex.
3. Therefore, non-differentiable points occur precisely at the zeros:
   x = 1, x = ${v + 2}, and x = ${v + 4}.
4. Total non-differentiable points = 3.`,
    keyFormula: '|g(x)| fails to be differentiable where g(x) = 0 and g\'(x) ≠ 0',
    topperTrick: 'Linear modulus terms |x - c| always have sharp corner vertices at each distinct root c.',
  },
];

// ==========================================
// 9. VECTORS & 3D GEOMETRY SEEDS
// ==========================================
export const vectors3DGeometrySeeds: ChapterSeedDef[] = [
  {
    subtopic: 'Shortest Distance Between Skew Lines',
    difficulty: 'IIT Advanced Level',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The shortest distance between the skew lines:
   L₁: (x - 1)/${v + 1} = (y - 2)/2 = (z - 3)/3
   L₂: (x - 2)/2 = (y - 4)/3 = (z - 5)/4 is:`,
    optionsTemplate: (v) => [
      `1 / √6`,
      `2 / √6`,
      `1 / √3`,
      `0 (intersecting lines)`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Line 1 passes through a₁ = (1, 2, 3) with direction b₁ = (${v + 1}, 2, 3).
2. Line 2 passes through a₂ = (2, 4, 5) with direction b₂ = (2, 3, 4).
3. a₂ - a₁ = (1, 2, 2).
4. Cross product b₁ × b₂ gives normal vector to both lines.
5. Shortest distance d = |(a₂ - a₁) · (b₁ × b₂)| / |b₁ × b₂| = 1 / √6.`,
    keyFormula: 'd = |(a₂ - a₁) · (b₁ × b₂)| / |b₁ × b₂|',
    topperTrick: 'Set up 3×3 determinant in numerator: row 1 is (a₂ - a₁), rows 2 & 3 are direction ratios.',
  },
  {
    subtopic: 'Scalar Triple Product & Coplanarity',
    difficulty: 'Easy',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] If the vectors u = i + j + k, v = i - j + 2k, and w = 2i + ${v + 1}j - k are coplanar, then the scalar triple product [u, v, w] is:`,
    optionsTemplate: (v) => [
      `0`,
      `1`,
      `-1`,
      `${v + 1}`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Three vectors are coplanar if and only if they lie in the same geometric plane.
2. Volume of the parallelepiped formed by them is zero:
   [u, v, w] = u · (v × w) = 0.`,
    keyFormula: '[u, v, w] = 0 for coplanar vectors',
    topperTrick: 'Coplanar vectors have volume of parallelepiped = 0, so scalar triple product is always 0!',
  },
  {
    subtopic: 'Vector Triple Product Identity',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] For any three non-zero vectors a, b, and c, the vector triple product a × (b × c) is equal to:`,
    optionsTemplate: (v) => [
      `(a · c) b - (a · b) c`,
      `(a · b) c - (a · c) b`,
      `(b · c) a - (a · c) b`,
      `0`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Standard BAC-CAB vector triple product expansion rule:
   a × (b × c) = b (a · c) - c (a · b) = (a · c) b - (a · b) c.`,
    keyFormula: 'a × (b × c) = (a · c) b - (a · b) c ("BAC - CAB" rule)',
    topperTrick: 'Mnemonic: "BAC minus CAB". Middle vector (b) comes first with positive sign!',
  },
  {
    subtopic: 'Angle Between Line and Plane',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The angle θ between the line (x - 1)/2 = (y + 1)/1 = (z - 2)/2 and the plane 2x - y + 2z = 5 is given by sin θ =:`,
    optionsTemplate: (v) => [
      `7 / 9`,
      `4 / 9`,
      `2 / 3`,
      `1 / 3`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Direction ratios of line: b = (2, 1, 2) ⇒ |b| = √(4 + 1 + 4) = 3.
2. Normal vector of plane: n = (2, -1, 2) ⇒ |n| = √(4 + 1 + 4) = 3.
3. Angle between line and plane:
   sin θ = |b · n| / (|b| |n|) = |(2)(2) + (1)(-1) + (2)(2)| / (3 × 3)
   sin θ = |4 - 1 + 4| / 9 = 7 / 9.`,
    keyFormula: 'sin θ = |b · n| / (|b| |n|)',
    topperTrick: 'Angle between line and plane uses SINE, while angle between two lines or two planes uses COSINE!',
  },
  {
    subtopic: 'Distance of Point from a 3D Plane',
    difficulty: 'Easy',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The perpendicular distance from the point P(1, 2, 3) to the plane 2x + 2y - z + ${3 * v} = 0 is:`,
    optionsTemplate: (v) => [
      `${((2 * 1 + 2 * 2 - 3 + 3 * v) / 3).toFixed(1)} units`,
      `${((2 * 1 + 2 * 2 - 3 + 3 * v) / 9).toFixed(1)} units`,
      `1.0 units`,
      `3.0 units`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Perpendicular distance formula:
   d = |a x₀ + b y₀ + c z₀ + d| / √(a² + b² + c²).
2. Normal magnitude = √(2² + 2² + (-1)²) = √(4 + 4 + 1) = 3.
3. Numerator = |2(1) + 2(2) - (3) + ${3 * v}| = |3 + ${3 * v}|.
4. d = |3 + ${3 * v}| / 3 = ${((2 * 1 + 2 * 2 - 3 + 3 * v) / 3).toFixed(1)} units.`,
    keyFormula: 'd = |Ax₁ + By₁ + Cz₁ + D| / √(A² + B² + C²)',
    topperTrick: 'Normal vector (2, 2, -1) has length √(4+4+1) = 3. Clean integer denominator!',
  },
];

// ==========================================
// 10. ALGEBRA, MATRICES & PROBABILITY SEEDS
// ==========================================
export const algebraMatricesSeeds: ChapterSeedDef[] = [
  {
    subtopic: 'Properties of Adjoint & Determinants',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] Let A be a 3 × 3 invertible matrix with determinant |A| = ${v + 2}. Then the determinant of its adjoint matrix |adj(adj(A))| is:`,
    optionsTemplate: (v) => [
      `${((v + 2) ** 4)}`,
      `${((v + 2) ** 2)}`,
      `${((v + 2) ** 3)}`,
      `${((v + 2) ** 6)}`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. For an n × n matrix:
   |adj(A)| = |A|^(n - 1)
2. Here n = 3, so |adj(A)| = |A|² = (${v + 2})² = ${(v + 2) ** 2}.
3. Determinant of double adjoint:
   |adj(adj(A))| = |A|^((n - 1)²) = |A|^(2²) = |A|⁴
   = (${v + 2})⁴ = ${((v + 2) ** 4)}.`,
    keyFormula: '|adj(A)| = |A|^(n - 1); |adj(adj(A))| = |A|^((n - 1)²)',
    topperTrick: 'For 3×3 matrix: |adj(A)| = |A|² and |adj(adj(A))| = |A|⁴.',
  },
  {
    subtopic: 'Bayes Theorem Conditional Probability',
    difficulty: 'Moderate',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] Box I contains ${v + 2} red balls and 3 black balls. Box II contains 3 red balls and 4 black balls. A box is chosen at random and a ball is drawn and found to be red. The probability that it was drawn from Box I is:`,
    optionsTemplate: (v) => [
      `${(((v + 2) / (v + 5)) / ((v + 2) / (v + 5) + 3 / 7)).toFixed(3)}`,
      `0.500`,
      `0.333`,
      `0.667`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. P(B₁) = P(B₂) = 1/2.
2. P(R | B₁) = (${v + 2}) / (${v + 5}).
3. P(R | B₂) = 3 / 7.
4. By Bayes' Theorem:
   P(B₁ | R) = [P(B₁) P(R|B₁)] / [P(B₁) P(R|B₁) + P(B₂) P(R|B₂)]
   = [ (${v + 2}) / (${v + 5}) ] / [ (${v + 2}) / (${v + 5}) + 3 / 7 ]
   = ${(((v + 2) / (v + 5)) / ((v + 2) / (v + 5) + 3 / 7)).toFixed(3)}.`,
    keyFormula: 'P(A|B) = P(B|A)P(A) / P(B)',
    topperTrick: 'Cancel out 1/2 probability of box selection from numerator and denominator immediately!',
  },
  {
    subtopic: 'Eigenvalues & Trace of Triangular Matrix',
    difficulty: 'Easy',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] Let A = [[${v + 1}, 2, 3], [0, ${v + 2}, 4], [0, 0, ${v + 3}]] be an upper triangular matrix. The eigenvalues of matrix A² are:`,
    optionsTemplate: (v) => [
      `${(v + 1) ** 2}, ${(v + 2) ** 2}, ${(v + 3) ** 2}`,
      `${v + 1}, ${v + 2}, ${v + 3}`,
      `1, 2, 3`,
      `0, 0, 0`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. The eigenvalues of an upper (or lower) triangular matrix are simply its main diagonal entries:
   λ₁ = ${v + 1}, λ₂ = ${v + 2}, λ₃ = ${v + 3}.
2. If λ is an eigenvalue of A, then λ² is the eigenvalue of A².
3. Hence, the eigenvalues of A² are ${(v + 1) ** 2}, ${(v + 2) ** 2}, and ${(v + 3) ** 2}.`,
    keyFormula: 'Eigenvalues of triangular matrix are its diagonal entries; eigenvalues of A^k are λ^k',
    topperTrick: 'For triangular matrices, never expand char equation det(A - λI) = 0! Just square diagonal entries.',
  },
  {
    subtopic: 'Complex Numbers Circular Disk & Maximum Argument',
    difficulty: 'Challenging',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] If complex number z satisfies |z - (${4 + v} + ${4 + v}i)| ≤ ${2 + v}, then the difference between the maximum and minimum argument of z is:`,
    optionsTemplate: (v) => [
      `2 sin⁻¹(${2 + v} / ${Math.sqrt(2 * (4 + v) ** 2).toFixed(1)})`,
      `π / 2`,
      `π / 4`,
      `sin⁻¹(1/2)`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. |z - z₀| ≤ r represents a closed circular disk with center z₀ = (${4 + v}) + (${4 + v})i and radius r = ${2 + v}.
2. Distance from origin to center: |z₀| = √[ (${4 + v})² + (${4 + v})² ] = √2 · (${4 + v}).
3. The lines from the origin tangent to the circle define the minimum and maximum arguments.
4. If half-angle between tangents is α, then sin α = r / |z₀| = (${2 + v}) / [ √2 · (${4 + v}) ].
5. Difference between max and min argument = 2 α = 2 sin⁻¹(r / |z₀|).`,
    keyFormula: 'Arg_max - Arg_min = 2 sin⁻¹(radius / distance_to_center)',
    topperTrick: 'Draw the two tangents from origin to circle: right triangle gives sin(half-angle) = radius / hypotenuse.',
  },
  {
    subtopic: 'Conic Section Common Tangent Condition',
    difficulty: 'Challenging',
    questionTemplate: (year, exam, v) => 
      `[${exam} ${year}] The slope m of a common tangent to the parabola y² = 16x and the circle x² + y² = 8 is:`,
    optionsTemplate: (v) => [
      `±1`,
      `±2`,
      `±1/2`,
      `±√3`,
    ],
    correctOptionIndex: 0,
    solutionTemplate: (year, v) => 
      `1. Tangent to parabola y² = 16x (a = 4):
   y = m x + 4 / m ⇒ m² x - m y + 4 = 0.
2. For this line to be tangent to circle x² + y² = 8 (center at origin, radius r = √8 = 2√2):
   Perpendicular distance from origin = radius:
   |4| / √(m⁴ + m²) = 2√2.
3. Square both sides:
   16 / [m² (m² + 1)] = 8 ⇒ 2 = m² (m² + 1)
   m⁴ + m² - 2 = 0 ⇒ (m² + 2)(m² - 1) = 0.
4. Since m² > 0 ⇒ m² = 1 ⇒ m = ±1.`,
    keyFormula: 'Common tangent: apply condition of tangency for both curves simultaneously',
    topperTrick: 'Solve quadratic in m²: m⁴ + m² - 2 = 0 immediately gives m² = 1, so m = ±1 in 15 seconds!',
  },
];
