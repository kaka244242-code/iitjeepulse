import { UserProfileStats, UserTestAttempt, BookItem } from '../types';

const STATS_KEY = 'jee_sankalp_user_stats';
const ATTEMPTS_KEY = 'jee_sankalp_test_attempts';
const UPLOADED_BOOKS_KEY = 'jee_sankalp_uploaded_books';

export const getTodayKey = (): string => {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const getYesterdayKey = (): string => {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

// Generate seed activity history for the past week
const generateInitialHistory = (yesterday: string): Record<string, number> => {
  const history: Record<string, number> = {};
  const d = new Date();
  for (let i = 6; i >= 1; i--) {
    const past = new Date();
    past.setDate(d.getDate() - i);
    const key = `${past.getFullYear()}-${String(past.getMonth() + 1).padStart(2, '0')}-${String(past.getDate()).padStart(2, '0')}`;
    history[key] = 5 + (i % 3);
  }
  return history;
};

const yesterday = getYesterdayKey();

const initialStats: UserProfileStats = {
  coins: 240, // Generous starting balance
  streakDays: 7,
  longestStreak: 12,
  lastActiveDate: yesterday, // Maintained through yesterday, so today's goal is primed!
  dailyGoal: 5, // Target 5 questions/day (or 1 test)
  todayQuestionsSolved: 4, // 4/5 questions done today, so solving just 1 question triggers celebration!
  todayGoalCompleted: false,
  activityHistory: generateInitialHistory(yesterday),
  questionsSolved: 48,
  testsCompleted: 3,
  accuracyRate: 76,
  unlockedNoteIds: ['pnb-01'], // 1 pre-unlocked bundle
  bookmarkedQuestionIds: ['phy-2024-01', 'chem-2024-02'],
};

export const getStoredStats = (): UserProfileStats => {
  try {
    const raw = localStorage.getItem(STATS_KEY);
    const today = getTodayKey();
    const yest = getYesterdayKey();

    let stats: UserProfileStats;
    if (!raw) {
      stats = { ...initialStats };
      localStorage.setItem(STATS_KEY, JSON.stringify(stats));
      return stats;
    }

    stats = JSON.parse(raw);

    // Ensure all required fields exist for backwards compatibility
    if (typeof stats.dailyGoal !== 'number' || stats.dailyGoal <= 0) {
      stats.dailyGoal = 5;
    }
    if (typeof stats.todayQuestionsSolved !== 'number') {
      stats.todayQuestionsSolved = 0;
    }
    if (typeof stats.longestStreak !== 'number') {
      stats.longestStreak = Math.max(stats.streakDays || 0, 7);
    }
    if (!stats.activityHistory) {
      stats.activityHistory = generateInitialHistory(yest);
    }

    // Handle day boundaries
    if (stats.lastActiveDate === today) {
      // Same day, keep progress as is
    } else if (stats.lastActiveDate === yest) {
      // New day, streak is intact! Reset today's counters
      stats.todayQuestionsSolved = 0;
      stats.todayGoalCompleted = false;
      saveStats(stats);
    } else if (stats.lastActiveDate && stats.lastActiveDate < yest) {
      // Missed more than 1 day - streak reset
      stats.streakDays = 0;
      stats.todayQuestionsSolved = 0;
      stats.todayGoalCompleted = false;
      saveStats(stats);
    }

    return stats;
  } catch {
    return initialStats;
  }
};

export const saveStats = (stats: UserProfileStats): void => {
  try {
    localStorage.setItem(STATS_KEY, JSON.stringify(stats));
  } catch (e) {
    console.error('Error saving user stats:', e);
  }
};

export const addCoins = (amount: number): UserProfileStats => {
  const current = getStoredStats();
  const updated = { ...current, coins: current.coins + amount };
  saveStats(updated);
  return updated;
};

export const deductCoins = (amount: number): boolean => {
  const current = getStoredStats();
  if (current.coins < amount) return false;
  const updated = { ...current, coins: current.coins - amount };
  saveStats(updated);
  return true;
};

export const unlockNoteBundle = (bundleId: string, price: number): boolean => {
  const current = getStoredStats();
  if (current.unlockedNoteIds.includes(bundleId)) return true;
  if (current.coins < price) return false;
  const updated = {
    ...current,
    coins: current.coins - price,
    unlockedNoteIds: [...current.unlockedNoteIds, bundleId],
  };
  saveStats(updated);
  return true;
};

export const toggleBookmark = (questionId: string): boolean => {
  const current = getStoredStats();
  const exists = current.bookmarkedQuestionIds.includes(questionId);
  const updatedBookmarks = exists
    ? current.bookmarkedQuestionIds.filter(id => id !== questionId)
    : [...current.bookmarkedQuestionIds, questionId];
  const updated = { ...current, bookmarkedQuestionIds: updatedBookmarks };
  saveStats(updated);
  return !exists;
};

export interface SolveQuestionResult {
  stats: UserProfileStats;
  goalJustCompleted: boolean;
  streakIncremented: boolean;
  earnedCoins: number;
}

export const recordQuestionSolved = (isCorrect: boolean): SolveQuestionResult => {
  const current = getStoredStats();
  const today = getTodayKey();

  const newTotalSolved = current.questionsSolved + 1;
  const newTodaySolved = (current.todayQuestionsSolved || 0) + 1;
  let earnedCoins = isCorrect ? 5 : 1; // Reward for practice

  let goalJustCompleted = false;
  let streakIncremented = false;
  let newStreakDays = current.streakDays;
  let isGoalCompleted = current.todayGoalCompleted;

  // Check if daily goal reached
  if (newTodaySolved >= current.dailyGoal && !isGoalCompleted) {
    goalJustCompleted = true;
    isGoalCompleted = true;
    newStreakDays += 1;
    streakIncremented = true;
    earnedCoins += 25; // Bonus 25 coins for completing daily goal!
  }

  const updatedHistory = {
    ...(current.activityHistory || {}),
    [today]: ((current.activityHistory && current.activityHistory[today]) || 0) + 1,
  };

  const updated: UserProfileStats = {
    ...current,
    coins: current.coins + earnedCoins,
    questionsSolved: newTotalSolved,
    todayQuestionsSolved: newTodaySolved,
    todayGoalCompleted: isGoalCompleted,
    streakDays: newStreakDays,
    longestStreak: Math.max(current.longestStreak || 0, newStreakDays),
    lastActiveDate: today,
    activityHistory: updatedHistory,
  };

  saveStats(updated);
  return {
    stats: updated,
    goalJustCompleted,
    streakIncremented,
    earnedCoins,
  };
};

export const updateDailyGoal = (newGoal: number): UserProfileStats => {
  const current = getStoredStats();
  const updated = { ...current, dailyGoal: Math.max(1, newGoal) };
  // Check if the new goal immediately completes today's target
  if (updated.todayQuestionsSolved >= updated.dailyGoal && !updated.todayGoalCompleted) {
    updated.todayGoalCompleted = true;
    updated.streakDays += 1;
    updated.longestStreak = Math.max(updated.longestStreak, updated.streakDays);
    updated.coins += 25;
    updated.lastActiveDate = getTodayKey();
  }
  saveStats(updated);
  return updated;
};

// Test Attempts
export const getTestAttempts = (): UserTestAttempt[] => {
  try {
    const raw = localStorage.getItem(ATTEMPTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

export const saveTestAttempt = (attempt: UserTestAttempt): { stats: UserProfileStats; goalJustCompleted: boolean } => {
  try {
    const list = getTestAttempts();
    list.unshift(attempt);
    localStorage.setItem(ATTEMPTS_KEY, JSON.stringify(list));

    // Update stats with bonus coins for completing a mock test!
    const stats = getStoredStats();
    const today = getTodayKey();
    stats.testsCompleted += 1;
    stats.coins += 50; // +50 coins for completing test!

    const questionsAttemptedInTest = (attempt.correctCount || 0) + (attempt.incorrectCount || 0);
    stats.todayQuestionsSolved = (stats.todayQuestionsSolved || 0) + questionsAttemptedInTest;
    stats.questionsSolved += questionsAttemptedInTest;

    const history = stats.activityHistory || {};
    history[today] = (history[today] || 0) + questionsAttemptedInTest;
    stats.activityHistory = history;

    let goalJustCompleted = false;
    if (stats.todayQuestionsSolved >= stats.dailyGoal && !stats.todayGoalCompleted) {
      stats.todayGoalCompleted = true;
      stats.streakDays += 1;
      stats.longestStreak = Math.max(stats.longestStreak || 0, stats.streakDays);
      stats.lastActiveDate = today;
      stats.coins += 25; // Daily goal bonus
      goalJustCompleted = true;
    }

    saveStats(stats);
    return { stats, goalJustCompleted };
  } catch (e) {
    console.error('Error saving test attempt:', e);
    return { stats: getStoredStats(), goalJustCompleted: false };
  }
};

// IndexedDB Helper for Large Uploaded Books / PDFs
const DB_NAME = 'JEESankalpBooksDB';
const DB_VERSION = 1;
const STORE_NAME = 'books';

const initDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event: any) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
  });
};

export const getUploadedBooks = async (): Promise<BookItem[]> => {
  try {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch {
    // Fallback to localStorage if IndexedDB not available
    const raw = localStorage.getItem(UPLOADED_BOOKS_KEY);
    return raw ? JSON.parse(raw) : [];
  }
};

export const saveUploadedBook = async (book: BookItem): Promise<void> => {
  try {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(book);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch {
    const current = await getUploadedBooks();
    current.unshift(book);
    localStorage.setItem(UPLOADED_BOOKS_KEY, JSON.stringify(current));
  }
};

export const deleteUploadedBook = async (id: string): Promise<void> => {
  try {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch {
    const current = await getUploadedBooks();
    const filtered = current.filter(b => b.id !== id);
    localStorage.setItem(UPLOADED_BOOKS_KEY, JSON.stringify(filtered));
  }
};
