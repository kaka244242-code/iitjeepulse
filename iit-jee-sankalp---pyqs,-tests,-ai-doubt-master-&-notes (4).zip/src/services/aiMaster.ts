import { Subject } from '../types';

export interface DoubtSolverRequest {
  prompt: string;
  subject?: Subject;
  topic?: string;
  imageBase64?: string;
  mimeType?: string;
  history?: { role: 'user' | 'model'; content: string }[];
}

export interface DoubtSolverResponse {
  success: boolean;
  text?: string;
  error?: string;
  isOfflineDemo?: boolean;
}

export const askAIDoubtMaster = async (
  req: DoubtSolverRequest
): Promise<DoubtSolverResponse> => {
  try {
    const res = await fetch('/api/ai/doubt-solver', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(req),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `Server responded with ${res.status}`);
    }

    return await res.json();
  } catch (error: any) {
    console.error('Error contacting AI Doubt Master:', error);
    return {
      success: false,
      error: error.message || 'Network error connecting to AI Master.',
    };
  }
};

export const generateAIDrill = async (params: {
  subject: Subject;
  topic: string;
  difficulty?: string;
  count?: number;
}) => {
  try {
    const res = await fetch('/api/ai/generate-drill', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    return await res.json();
  } catch (error: any) {
    return { success: false, error: error.message };
  }
};
