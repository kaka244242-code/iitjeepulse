import React from 'react';
import { 
  Library, 
  Zap, 
  Clock, 
  Bot, 
  BookMarked, 
  Sparkles, 
  BarChart3 
} from 'lucide-react';
import { AppLanguage } from '../types';
import { getTranslation } from '../utils/translations';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  unlockedNotesCount: number;
  language: AppLanguage;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  setActiveTab,
  unlockedNotesCount,
  language,
}) => {
  const t = getTranslation(language);

  const tabs = [
    { id: 'pyq', label: t.navPyq, icon: Library, desc: t.navPyqDesc },
    { id: 'practice', label: t.navPractice, icon: Zap, desc: t.navPracticeDesc },
    { id: 'cbt', label: t.navCbt, icon: Clock, desc: t.navCbtDesc },
    { id: 'ai-master', label: t.navAiMaster, icon: Bot, desc: t.navAiMasterDesc },
    { id: 'books', label: t.navBooks, icon: BookMarked, desc: t.navBooksDesc },
    { id: 'notes', label: t.navNotes, icon: Sparkles, desc: t.navNotesDesc },
    { id: 'analytics', label: t.navAnalytics, icon: BarChart3, desc: t.navAnalyticsDesc },
  ];

  return (
    <nav className="border-b border-slate-800 bg-slate-900/50 sticky top-16 z-30 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-2 sm:px-6">
        <div className="flex items-center gap-1 overflow-x-auto py-2 scrollbar-none no-scrollbar">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all select-none cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
                {tab.id === 'cbt' && (
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono font-bold">
                    1000 Tests
                  </span>
                )}
                {tab.id === 'books' && (
                  <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono font-bold">
                    10K PYQs PDF
                  </span>
                )}
                {tab.id === 'notes' && (
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-mono font-bold">
                    All Chaps
                  </span>
                )}
                {tab.id === 'notes' && unlockedNotesCount > 0 && (
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
