import React, { useState, useMemo } from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  Sparkles, 
  Bookmark, 
  Lightbulb, 
  ChevronDown, 
  ChevronUp, 
  Filter, 
  Zap, 
  Check, 
  Search,
  BookOpen,
  Library,
  Clock,
  ArrowRight,
  GraduationCap,
  Play,
  RotateCcw,
  Target,
  Flame,
  Award,
  Globe,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { Question, Subject, ExamType, Difficulty, MockTest, ChapterTestInfo, AppLanguage } from '../types';
import { chapterTestsList } from '../data/chapterTests';
import { getTranslation } from '../utils/translations';

interface PYQExplorerProps {
  questions: Question[];
  bookmarkedIds: string[];
  onToggleBookmark: (id: string) => void;
  onSolveQuestion: (isCorrect: boolean) => void;
  onAskAIMaster: (question: Question) => void;
  onStartChapterTest?: (test: MockTest) => void;
  language: AppLanguage;
}

export const PYQExplorer: React.FC<PYQExplorerProps> = ({
  questions,
  bookmarkedIds,
  onToggleBookmark,
  onSolveQuestion,
  onAskAIMaster,
  onStartChapterTest,
  language,
}) => {
  const t = getTranslation(language);
  // Main view switcher: 'archive' (Browse & Practice PYQs) or 'chapter-tests' (Timed Chapter CBT Tests)
  const [activeView, setActiveView] = useState<'archive' | 'chapter-tests'>('archive');

  // Language state for PYQs: 'en' | 'hi' | 'bilingual'
  const [archiveLang, setArchiveLang] = useState<'en' | 'hi' | 'bilingual'>(language === 'hi' ? 'hi' : 'en');
  const [questionLangOverrides, setQuestionLangOverrides] = useState<Record<string, 'en' | 'hi' | 'bilingual'>>({});

  // Pagination for 500 questions per year
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [jumpToQ, setJumpToQ] = useState<string>('');
  const pageSize = 20;

  // Filters for Archive
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [selectedExam, setSelectedExam] = useState<string>('All');
  const [selectedYear, setSelectedYear] = useState<string>('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [onlyBookmarks, setOnlyBookmarks] = useState<boolean>(false);

  // Filters for Chapter Tests
  const [chapterSubjectFilter, setChapterSubjectFilter] = useState<'All' | 'Physics' | 'Chemistry' | 'Mathematics'>('All');
  const [expandedChapterPreview, setExpandedChapterPreview] = useState<string | null>(null);

  // User answers per question: { [questionId]: selectedOptionIndex }
  const [userAnswers, setUserAnswers] = useState<Record<string, number>>({});
  // Expanded solutions: { [questionId]: boolean }
  const [expandedSolutions, setExpandedSolutions] = useState<Record<string, boolean>>({});

  const availableYears = [
    2026, 2025, 2024, 2023, 2022, 2021, 2020, 2019, 2018, 2017, 2016, 2015, 2014, 2013, 2012, 2011, 2010
  ];

  const filteredQuestions = useMemo(() => {
    return questions.filter((q) => {
      if (selectedSubject !== 'All' && q.subject !== selectedSubject) return false;
      if (selectedExam !== 'All' && q.exam !== selectedExam) return false;
      if (selectedYear !== 'All' && q.year.toString() !== selectedYear) return false;
      if (selectedDifficulty !== 'All' && q.difficulty !== selectedDifficulty) return false;
      if (onlyBookmarks && !bookmarkedIds.includes(q.id)) return false;
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesText = q.question.toLowerCase().includes(query) ||
          (q.questionHindi && q.questionHindi.toLowerCase().includes(query)) ||
          q.topic.toLowerCase().includes(query) ||
          (q.subtopic && q.subtopic.toLowerCase().includes(query));
        if (!matchesText) return false;
      }
      return true;
    });
  }, [questions, selectedSubject, selectedExam, selectedYear, selectedDifficulty, searchQuery, onlyBookmarks, bookmarkedIds]);

  const totalPages = Math.max(1, Math.ceil(filteredQuestions.length / pageSize));
  
  const paginatedQuestions = useMemo(() => {
    const startIndex = (currentPage - 1) * pageSize;
    return filteredQuestions.slice(startIndex, startIndex + pageSize);
  }, [filteredQuestions, currentPage, pageSize]);

  const handleJumpToQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    const qNum = parseInt(jumpToQ, 10);
    if (!isNaN(qNum) && qNum >= 1 && qNum <= filteredQuestions.length) {
      const targetPage = Math.ceil(qNum / pageSize);
      setCurrentPage(targetPage);
      setJumpToQ('');
    }
  };

  const filteredChapterTests = useMemo(() => {
    if (chapterSubjectFilter === 'All') return chapterTestsList;
    return chapterTestsList.filter(ct => ct.subject === chapterSubjectFilter);
  }, [chapterSubjectFilter]);

  const handleSelectOption = (question: Question, optionIdx: number) => {
    if (userAnswers[question.id] !== undefined) return; // already answered
    setUserAnswers((prev) => ({ ...prev, [question.id]: optionIdx }));
    const isCorrect = optionIdx === question.correctOption;
    onSolveQuestion(isCorrect);
  };

  const toggleSolution = (id: string) => {
    setExpandedSolutions((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleLaunchChapterTest = (ct: ChapterTestInfo) => {
    if (onStartChapterTest) {
      const mockTest: MockTest = {
        id: ct.id,
        title: `${ct.chapter} · Chapter CBT Test (${ct.yearCoverage})`,
        examType: ct.examType === 'JEE Advanced' ? 'JEE Advanced' : 'JEE Main',
        durationMinutes: ct.durationMinutes,
        totalQuestions: ct.questions.length,
        totalMarks: ct.questions.length * 4,
        subjectBreakdown: {
          Physics: ct.subject === 'Physics' ? ct.questions.length : 0,
          Chemistry: ct.subject === 'Chemistry' ? ct.questions.length : 0,
          Mathematics: ct.subject === 'Mathematics' ? ct.questions.length : 0,
        },
        difficulty: ct.difficulty === 'IIT Advanced Level' ? 'JEE Advanced Paper-1' : 'Standard JEE Main',
        description: `${ct.description} Curated from authentic ${ct.yearCoverage} JEE Main & Advanced official question papers.`,
        chapter: ct.chapter,
        isChapterTest: true,
        questions: ct.questions,
      };
      onStartChapterTest(mockTest);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Mode Switcher */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/20 rounded-2xl p-5 sm:p-6 shadow-lg shadow-indigo-950/20">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1.5">
                <Library className="w-3.5 h-3.5 text-indigo-400" />
                2010 – 2026 Archive
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                JEE Main & JEE Advanced
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                17 Years Chapter-Wise
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              {t.archiveTitle}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              {t.archiveSubtitle}
            </p>
          </div>

          {/* View Toggle Tabs */}
          <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800 shrink-0 w-full sm:w-auto">
            <button
              onClick={() => setActiveView('archive')}
              className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeView === 'archive'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>{t.tabArchive}</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-900/80 text-indigo-200">
                {questions.length} Qs
              </span>
            </button>
            <button
              onClick={() => setActiveView('chapter-tests')}
              className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeView === 'chapter-tests'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Target className="w-4 h-4" />
              <span>{t.tabChapterTests}</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-900/80 text-indigo-200">
                {chapterTestsList.length} Tests
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* VIEW 1: 2010–2026 PYQ ARCHIVES & QUESTION SOLVER */}
      {/* ======================================================== */}
      {activeView === 'archive' && (
        <div className="space-y-6">
          {/* Year Timeline Selector (2010 to 2026) */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 sm:p-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-indigo-400" />
                <span>{t.selectYear}</span>
                <span className="text-[10px] text-amber-400 font-normal bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  ~500 PYQs / Year (Bilingual)
                </span>
                <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 hidden sm:inline-flex items-center gap-1">
                  <span>✓</span>
                  <span>A, B, C, D संतुलित उत्तर</span>
                </span>
              </label>

              {/* Questions Language Switcher (EN / HI / Bilingual) */}
              <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 shrink-0">
                <Globe className="w-3.5 h-3.5 text-indigo-400 ml-1.5" />
                <span className="text-[11px] text-slate-400 mr-1 hidden sm:inline">Questions:</span>
                <button
                  onClick={() => setArchiveLang('en')}
                  className={`px-2 py-1 rounded-lg text-xs font-bold transition-all ${
                    archiveLang === 'en' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  English
                </button>
                <button
                  onClick={() => setArchiveLang('hi')}
                  className={`px-2 py-1 rounded-lg text-xs font-bold transition-all ${
                    archiveLang === 'hi' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  हिन्दी
                </button>
                <button
                  onClick={() => setArchiveLang('bilingual')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                    archiveLang === 'bilingual' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  द्विभाषी (Both)
                </button>
              </div>
            </div>

            {/* Horizontal Scrollable Year Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none no-scrollbar">
              <button
                onClick={() => {
                  setSelectedYear('All');
                  setCurrentPage(1);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  selectedYear === 'All'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white hover:border-slate-700'
                }`}
              >
                {t.allYears} ({questions.length})
              </button>
              {availableYears.map((year) => {
                const count = questions.filter(q => q.year === year).length;
                const isSelected = selectedYear === year.toString();
                return (
                  <button
                    key={year}
                    onClick={() => {
                      setSelectedYear(year.toString());
                      setCurrentPage(1);
                    }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white hover:border-slate-700'
                    }`}
                  >
                    <span>{year}</span>
                    {year === 2026 && (
                      <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 font-normal">
                        Latest
                      </span>
                    )}
                    <span className="text-[10px] text-slate-500 font-mono">({count})</span>
                  </button>
                );
              })}
            </div>

            {/* Search & Secondary Filter Bar */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3 mt-4 pt-4 border-t border-slate-800/80">
              {/* Search */}
              <div className="md:col-span-4 relative">
                <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder={language === 'hi' ? 'प्रश्न, टॉपिक या सूत्र खोजें...' : 'Search question, formula or topic...'}
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Jump to Question Number */}
              <form onSubmit={handleJumpToQuestion} className="md:col-span-2 flex items-center gap-1.5">
                <input
                  type="number"
                  min={1}
                  max={filteredQuestions.length || 500}
                  placeholder={`Q# (1-${filteredQuestions.length})`}
                  value={jumpToQ}
                  onChange={(e) => setJumpToQ(e.target.value)}
                  className="w-full px-2.5 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-mono"
                />
                <button
                  type="submit"
                  className="px-2.5 py-2 bg-slate-900 border border-slate-700 hover:border-indigo-500 text-xs font-bold text-slate-200 rounded-lg shrink-0 cursor-pointer"
                >
                  Go
                </button>
              </form>

              {/* Exam Selector */}
              <div className="md:col-span-2">
                <select
                  value={selectedExam}
                  onChange={(e) => {
                    setSelectedExam(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full px-2.5 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="All">{t.allExams}</option>
                  <option value="JEE Main">JEE Main Only</option>
                  <option value="JEE Advanced">JEE Advanced Only</option>
                </select>
              </div>

              {/* Subject Selector */}
              <div className="md:col-span-2">
                <select
                  value={selectedSubject}
                  onChange={(e) => {
                    setSelectedSubject(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full px-2.5 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="All">{t.allSubjects}</option>
                  <option value="Physics">{t.Physics}</option>
                  <option value="Chemistry">{t.Chemistry}</option>
                  <option value="Mathematics">{t.Mathematics}</option>
                </select>
              </div>

              {/* Difficulty */}
              <div className="md:col-span-1">
                <select
                  value={selectedDifficulty}
                  onChange={(e) => {
                    setSelectedDifficulty(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full px-2 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="All">Diff: All</option>
                  <option value="Easy">Easy</option>
                  <option value="Moderate">Medium</option>
                  <option value="Challenging">Hard</option>
                  <option value="IIT Advanced Level">Adv</option>
                </select>
              </div>

              {/* Bookmarks Toggle */}
              <div className="md:col-span-1">
                <button
                  onClick={() => {
                    setOnlyBookmarks(!onlyBookmarks);
                    setCurrentPage(1);
                  }}
                  title={t.savedQuestions}
                  className={`w-full py-2 rounded-lg text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    onlyBookmarks
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  <Bookmark className={`w-3.5 h-3.5 ${onlyBookmarks ? 'fill-amber-400 text-amber-400' : ''}`} />
                  <span className="hidden xl:inline">{language === 'hi' ? 'सेव' : 'Saved'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Results Summary Bar */}
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <div>
              Showing <span className="text-white font-bold">{filteredQuestions.length}</span> authentic PYQs
              {selectedYear !== 'All' && <span> for Year <strong className="text-indigo-400">{selectedYear}</strong></span>}
              {selectedExam !== 'All' && <span> in <strong className="text-indigo-400">{selectedExam}</strong></span>}
              {selectedSubject !== 'All' && <span> (<strong className="text-indigo-400">{selectedSubject}</strong>)</span>}
            </div>

            {(selectedSubject !== 'All' || selectedExam !== 'All' || selectedYear !== 'All' || selectedDifficulty !== 'All' || searchQuery || onlyBookmarks) && (
              <button
                onClick={() => {
                  setSelectedSubject('All');
                  setSelectedExam('All');
                  setSelectedYear('All');
                  setSelectedDifficulty('All');
                  setSearchQuery('');
                  setOnlyBookmarks(false);
                }}
                className="text-xs text-indigo-400 hover:text-indigo-300 underline font-semibold"
              >
                Reset All Filters
              </button>
            )}
          </div>

          {/* Question List */}
          {filteredQuestions.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-12 text-center">
              <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center mx-auto mb-3 text-slate-400">
                <Search className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-200">No questions found matching criteria</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                Try selecting &ldquo;All Years&rdquo; or clearing the search query to browse other questions from the 2010–2026 archive.
              </p>
              <button
                onClick={() => {
                  setSelectedSubject('All');
                  setSelectedExam('All');
                  setSelectedYear('All');
                  setSelectedDifficulty('All');
                  setSearchQuery('');
                  setOnlyBookmarks(false);
                }}
                className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg transition-all"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {paginatedQuestions.map((q, index) => {
                const globalIndex = (currentPage - 1) * pageSize + index;
                const isAnswered = userAnswers[q.id] !== undefined;
                const selectedOption = userAnswers[q.id];
                const isCorrect = isAnswered && selectedOption === q.correctOption;
                const isBookmarked = bookmarkedIds.includes(q.id);
                const isSolutionOpen = !!expandedSolutions[q.id];

                // Resolved language for this specific question
                const qLang = questionLangOverrides[q.id] || archiveLang;
                const showEnglish = qLang === 'en' || qLang === 'bilingual';
                const showHindi = qLang === 'hi' || qLang === 'bilingual';

                return (
                  <div
                    key={q.id}
                    className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 transition-all hover:border-slate-700 shadow-sm"
                  >
                    {/* Card Header Meta */}
                    <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800/80">
                      <div className="flex flex-wrap items-center gap-2">
                        {/* Question Global Number & Year Badge */}
                        <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 flex items-center gap-1.5 font-mono">
                          <span>Q#{globalIndex + 1}</span>
                          <span>•</span>
                          <span>{q.exam} {q.year}</span>
                        </span>

                        {/* Subject Badge */}
                        <span
                          className={`px-2.5 py-1 rounded-md text-xs font-bold ${
                            q.subject === 'Physics'
                              ? 'bg-sky-500/10 text-sky-300 border border-sky-500/20'
                              : q.subject === 'Chemistry'
                              ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20'
                              : 'bg-violet-500/10 text-violet-300 border border-violet-500/20'
                          }`}
                        >
                          {q.subject}
                        </span>

                        {/* Topic */}
                        <span className="text-xs font-medium text-slate-300">
                          {q.topic}
                        </span>

                        {q.subtopic && (
                          <span className="text-xs text-slate-500 hidden sm:inline">
                            • {q.subtopic}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {/* Per-Question Language Pill */}
                        <div className="flex items-center bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-[10px] font-bold">
                          <button
                            onClick={() => setQuestionLangOverrides((prev) => ({ ...prev, [q.id]: 'en' }))}
                            className={`px-1.5 py-0.5 rounded transition-all ${
                              qLang === 'en' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            EN
                          </button>
                          <button
                            onClick={() => setQuestionLangOverrides((prev) => ({ ...prev, [q.id]: 'hi' }))}
                            className={`px-1.5 py-0.5 rounded transition-all ${
                              qLang === 'hi' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            हिं
                          </button>
                          <button
                            onClick={() => setQuestionLangOverrides((prev) => ({ ...prev, [q.id]: 'bilingual' }))}
                            className={`px-1.5 py-0.5 rounded transition-all ${
                              qLang === 'bilingual' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            द्वि
                          </button>
                        </div>

                        {/* Difficulty */}
                        <span
                          className={`text-[11px] font-semibold px-2 py-0.5 rounded ${
                            q.difficulty === 'Easy'
                              ? 'bg-emerald-950 text-emerald-400'
                              : q.difficulty === 'Moderate'
                              ? 'bg-amber-950 text-amber-400'
                              : 'bg-rose-950 text-rose-400'
                          }`}
                        >
                          {q.difficulty}
                        </span>

                        {/* Bookmark Button */}
                        <button
                          onClick={() => onToggleBookmark(q.id)}
                          className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                            isBookmarked
                              ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                              : 'bg-slate-950 text-slate-500 border-slate-800 hover:text-slate-300'
                          }`}
                          title={isBookmarked ? 'Remove bookmark' : 'Bookmark this question'}
                        >
                          <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-amber-400' : ''}`} />
                        </button>
                      </div>
                    </div>

                    {/* Question Statement (Bilingual rendering) */}
                    <div className="mb-5 space-y-2">
                      {showEnglish && (
                        <div className="text-sm font-medium text-slate-100 leading-relaxed whitespace-pre-line font-sans">
                          <span className="text-slate-500 font-bold mr-2">Q{globalIndex + 1}.</span>
                          {q.question}
                        </div>
                      )}

                      {showHindi && (
                        <div className={`text-sm leading-relaxed whitespace-pre-line font-sans ${
                          showEnglish 
                            ? 'bg-slate-950/60 p-3 rounded-xl border border-indigo-500/20 text-slate-200 text-xs sm:text-sm' 
                            : 'text-slate-100 font-medium'
                        }`}>
                          {showEnglish && (
                            <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block mb-1">
                              🌐 हिन्दी अनुवाद:
                            </span>
                          )}
                          {!showEnglish && <span className="text-slate-500 font-bold mr-2">Q{globalIndex + 1}.</span>}
                          {q.questionHindi || q.question}
                        </div>
                      )}
                    </div>

                    {/* Options Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-5">
                      {q.options.map((option, optIdx) => {
                        const isThisSelected = selectedOption === optIdx;
                        const isThisCorrect = optIdx === q.correctOption;
                        const optionHi = q.optionsHindi?.[optIdx];

                        let optionStyle = 'bg-slate-950/80 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800/40 cursor-pointer';

                        if (isAnswered) {
                          if (isThisCorrect) {
                            optionStyle = 'bg-emerald-950/40 border-emerald-500 text-emerald-200 font-semibold';
                          } else if (isThisSelected) {
                            optionStyle = 'bg-rose-950/40 border-rose-500 text-rose-200';
                          } else {
                            optionStyle = 'bg-slate-950/40 border-slate-900 text-slate-600 opacity-60';
                          }
                        }

                        return (
                          <button
                            key={optIdx}
                            onClick={() => handleSelectOption(q, optIdx)}
                            disabled={isAnswered}
                            className={`flex items-start gap-3 p-3.5 rounded-xl border text-left text-xs transition-all ${optionStyle}`}
                          >
                            <span
                              className={`w-5 h-5 rounded-md flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5 ${
                                isAnswered && isThisCorrect
                                  ? 'bg-emerald-500 text-slate-950'
                                  : isAnswered && isThisSelected
                                  ? 'bg-rose-500 text-white'
                                  : 'bg-slate-800 text-slate-400'
                              }`}
                            >
                              {String.fromCharCode(65 + optIdx)}
                            </span>
                            <div className="flex-1 leading-snug">
                              {showEnglish && <div>{option}</div>}
                              {showHindi && optionHi && (
                                <div className={showEnglish ? 'text-[11px] text-slate-400 mt-0.5' : ''}>
                                  {optionHi}
                                </div>
                              )}
                            </div>
                            {isAnswered && isThisCorrect && (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                            )}
                            {isAnswered && isThisSelected && !isThisCorrect && (
                              <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Result Notification Bar on Answer */}
                    {isAnswered && (
                      <div
                        className={`p-3 rounded-xl mb-4 flex items-center justify-between text-xs font-semibold ${
                          isCorrect
                            ? 'bg-emerald-950/50 text-emerald-300 border border-emerald-800/60'
                            : 'bg-rose-950/50 text-rose-300 border border-rose-800/60'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          {isCorrect ? (
                            <>
                              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                              <span>{language === 'hi' ? 'सही उत्तर!' : 'Correct Answer!'} <strong>+4 Marks</strong> · <strong>+5 Coins</strong></span>
                            </>
                          ) : (
                            <>
                              <XCircle className="w-4 h-4 text-rose-400" />
                              <span>{language === 'hi' ? 'गलत उत्तर!' : 'Incorrect!'} <strong>-1 Negative mark</strong>. Correct option: <strong>({String.fromCharCode(65 + q.correctOption)})</strong>.</span>
                            </>
                          )}
                        </div>
                        <span className="text-[11px] opacity-80">
                          {isCorrect ? (language === 'hi' ? 'शानदार सटीकता!' : 'Great accuracy!') : (language === 'hi' ? 'नीचे हल देखें' : 'Review step derivation')}
                        </span>
                      </div>
                    )}

                    {/* Bottom Action Bar */}
                    <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800/60">
                      {/* Solution Toggle */}
                      <button
                        onClick={() => toggleSolution(q.id)}
                        className="flex items-center gap-1.5 text-xs font-bold text-indigo-400 hover:text-indigo-300 transition-colors cursor-pointer"
                      >
                        <Lightbulb className="w-3.5 h-3.5" />
                        <span>{isSolutionOpen ? (language === 'hi' ? 'हल छिपाएं' : 'Hide Derivation') : (language === 'hi' ? 'चरणबद्ध हल देखें (Hindi/Eng)' : 'View Step Derivation')}</span>
                        {isSolutionOpen ? (
                          <ChevronUp className="w-3.5 h-3.5" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5" />
                        )}
                      </button>

                      {/* AI Master Quick Prompt */}
                      <button
                        onClick={() => onAskAIMaster(q)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-semibold transition-all cursor-pointer"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                        <span>{language === 'hi' ? 'AI गुरु से समझें' : 'Ask AI Guru to Explain'}</span>
                      </button>
                    </div>

                    {/* Expandable Derivation & Formula Box */}
                    {isSolutionOpen && (
                      <div className="mt-4 pt-4 border-t border-slate-800 space-y-3.5 animate-in fade-in duration-200">
                        {/* Step Derivation in English / Hindi */}
                        <div className="bg-slate-950 rounded-xl p-4 border border-slate-800/80 space-y-3">
                          <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            <span>{language === 'hi' ? 'आधिकारिक चरणबद्ध समाधान:' : 'Official Step-by-Step Solution:'}</span>
                          </h4>

                          {showEnglish && (
                            <pre className="text-xs text-slate-300 whitespace-pre-wrap font-sans leading-relaxed">
                              {q.solution}
                            </pre>
                          )}

                          {showHindi && (
                            <div className={showEnglish ? 'pt-2 border-t border-slate-800/80' : ''}>
                              {showEnglish && (
                                <strong className="text-amber-400 block text-[11px] mb-1">
                                  हिन्दी में समाधान:
                                </strong>
                              )}
                              <pre className="text-xs text-slate-300 whitespace-pre-wrap font-sans leading-relaxed">
                                {q.solutionHindi || q.solution}
                              </pre>
                            </div>
                          )}
                        </div>

                        {/* Core Formula Box */}
                        {(q.keyFormula || q.keyFormulaHindi) && (
                          <div className="bg-indigo-950/30 rounded-xl p-3.5 border border-indigo-800/30 text-xs flex items-start gap-2.5">
                            <Zap className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                            <div>
                              <span className="font-bold text-indigo-300 block mb-0.5">
                                {language === 'hi' ? 'मुख्य सूत्र / सिद्धांत:' : 'High-Yield Formula / Principle:'}
                              </span>
                              <code className="text-slate-200 font-mono text-[11px] bg-slate-950/60 px-1.5 py-0.5 rounded block">
                                {showHindi && q.keyFormulaHindi ? q.keyFormulaHindi : q.keyFormula}
                              </code>
                            </div>
                          </div>
                        )}

                        {/* Topper Trick */}
                        {(q.topperTrick || q.topperTrickHindi) && (
                          <div className="bg-amber-950/30 rounded-xl p-3.5 border border-amber-800/30 text-xs flex items-start gap-2.5">
                            <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                            <div>
                              <span className="font-bold text-amber-300 block mb-0.5">
                                {language === 'hi' ? 'कोटा AIR-रैंकर शॉर्टकट ट्रिक:' : 'Kota AIR-Ranker Shortcut Hack:'}
                              </span>
                              <p className="text-slate-300 leading-relaxed text-[11px]">
                                {showHindi && q.topperTrickHindi ? q.topperTrickHindi : q.topperTrick}
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Pagination Controls Bar */}
              {totalPages > 1 && (
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 mt-6">
                  <div className="text-xs text-slate-400">
                    Showing <strong className="text-white">{(currentPage - 1) * pageSize + 1}</strong> – <strong className="text-white">{Math.min(currentPage * pageSize, filteredQuestions.length)}</strong> of <strong className="text-white">{filteredQuestions.length}</strong> PYQs
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 cursor-pointer"
                    >
                      <ChevronLeft className="w-4 h-4" />
                      <span>Prev</span>
                    </button>

                    {/* Page Numbers Indicator */}
                    <div className="flex items-center gap-1">
                      {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                        let pageNum = i + 1;
                        if (totalPages > 5 && currentPage > 3) {
                          pageNum = Math.min(totalPages - 4 + i, Math.max(1, currentPage - 2 + i));
                        }
                        return (
                          <button
                            key={pageNum}
                            onClick={() => setCurrentPage(pageNum)}
                            className={`w-7 h-7 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                              currentPage === pageNum
                                ? 'bg-indigo-600 text-white shadow-sm'
                                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                            }`}
                          >
                            {pageNum}
                          </button>
                        );
                      })}
                      {totalPages > 5 && currentPage < totalPages - 2 && (
                        <span className="text-slate-600 px-1 text-xs">...</span>
                      )}
                      {totalPages > 5 && currentPage < totalPages - 2 && (
                        <button
                          onClick={() => setCurrentPage(totalPages)}
                          className="w-7 h-7 rounded-lg text-xs font-bold bg-slate-900 text-slate-400 hover:text-white border border-slate-800 cursor-pointer"
                        >
                          {totalPages}
                        </button>
                      )}
                    </div>

                    <button
                      disabled={currentPage === totalPages}
                      onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 cursor-pointer"
                    >
                      <span>Next</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ======================================================== */}
      {/* VIEW 2: CHAPTER-WISE CBT TESTS (2010–2026) */}
      {/* ======================================================== */}
      {activeView === 'chapter-tests' && (
        <div className="space-y-6">
          {/* Subject Filter Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                  <Target className="w-4 h-4 text-indigo-400" />
                  Chapter-Wise CBT Tests (75 Questions per Chapter)
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  75 Qs · 300 Marks
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Har chapter me authentic 2010 se 2026 tak ke 75 questions ka complete test module (+4 / -1 marking, 180 min timer).
              </p>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800 shrink-0">
              {(['All', 'Physics', 'Chemistry', 'Mathematics'] as const).map((sub) => (
                <button
                  key={sub}
                  onClick={() => setChapterSubjectFilter(sub)}
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                    chapterSubjectFilter === sub
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {sub}
                </button>
              ))}
            </div>
          </div>

          {/* 1,000 CBT Vault Banner */}
          <div className="bg-gradient-to-r from-indigo-950/60 via-slate-900 to-slate-950 border border-indigo-500/30 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                  <span>1,000 CBT Tests Vault Available in "CBT Mock Tests" Tab</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300">
                    Bilingual (Hindi + English)
                  </span>
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Over 1,000 curated Hard-level tests with 75 questions each covering high-weightage topics (2010–2026) for maximum marks in minimum time.
                </p>
              </div>
            </div>
          </div>

          {/* Chapter Tests Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredChapterTests.map((ct) => {
              const isPreviewOpen = expandedChapterPreview === ct.id;

              return (
                <div
                  key={ct.id}
                  className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col justify-between hover:border-slate-700 transition-all shadow-sm group"
                >
                  <div>
                    {/* Header */}
                    <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                          ct.subject === 'Physics'
                            ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20'
                            : ct.subject === 'Chemistry'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : 'bg-violet-500/10 text-violet-400 border border-violet-500/20'
                        }`}
                      >
                        {ct.subject}
                      </span>
                      <span className="text-slate-500 font-mono text-[11px]">
                        {ct.yearCoverage}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-white mb-2 leading-snug group-hover:text-indigo-300 transition-colors">
                      {ct.chapter}
                    </h3>
                    <p className="text-xs text-slate-400 mb-4 line-clamp-2 leading-relaxed">
                      {ct.description}
                    </p>

                    {/* Stats pills */}
                    <div className="grid grid-cols-3 gap-2 bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 mb-4 text-center">
                      <div>
                        <span className="text-[10px] text-slate-500 block uppercase font-mono">Questions</span>
                        <span className="text-xs font-bold text-white">{ct.questionsCount} Qs</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block uppercase font-mono">Duration</span>
                        <span className="text-xs font-bold text-indigo-400">{ct.durationMinutes}m</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block uppercase font-mono">Total Marks</span>
                        <span className="text-xs font-bold text-amber-400">{ct.totalMarks}M</span>
                      </div>
                    </div>

                    {/* High-yield focus points */}
                    <div className="space-y-1 mb-4">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                        High-Yield Topics Tested:
                      </span>
                      {ct.highYieldPoints.slice(0, 2).map((pt, idx) => (
                        <div key={idx} className="text-[11px] text-slate-300 flex items-center gap-1.5 truncate">
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 shrink-0" />
                          <span className="truncate">{pt}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <button
                      onClick={() => handleLaunchChapterTest(ct)}
                      className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-lg transition-all flex items-center justify-center gap-2 shadow-sm shadow-indigo-600/20"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Start Chapter Test</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => setExpandedChapterPreview(isPreviewOpen ? null : ct.id)}
                      className="w-full py-1.5 text-slate-400 hover:text-slate-200 text-[11px] font-semibold text-center transition-colors"
                    >
                      {isPreviewOpen ? 'Hide Question Preview' : `Preview Questions (${ct.questions.length})`}
                    </button>

                    {isPreviewOpen && (
                      <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 mt-2 space-y-2 max-h-64 overflow-y-auto text-xs">
                        <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 pb-1 border-b border-slate-800">
                          <span>All 75 Questions (2010 – 2026):</span>
                          <span className="text-indigo-400">Scroll to view all 75</span>
                        </div>
                        {ct.questions.map((q, qIdx) => (
                          <div key={q.id} className="text-slate-300 border-b border-slate-900 pb-1.5 last:border-0 hover:text-white transition-colors">
                            <div className="flex items-center gap-1.5 text-[10px] text-slate-500 mb-0.5">
                              <span className="text-indigo-400 font-bold">Q{qIdx + 1}</span>
                              <span>•</span>
                              <span className="font-semibold text-slate-400">{q.exam} {q.year}</span>
                              <span>•</span>
                              <span className="text-slate-500">{q.subtopic}</span>
                            </div>
                            <span className="line-clamp-2 leading-relaxed text-xs">{q.question}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
