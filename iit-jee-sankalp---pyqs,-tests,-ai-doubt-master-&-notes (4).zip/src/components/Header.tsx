import React from 'react';
import { Sparkles, Flame, Coins, Bookmark, BookOpen, Compass, Target, CheckCircle2, Languages, HelpCircle, Award, Activity } from 'lucide-react';
import { UserProfileStats, AppLanguage } from '../types';
import { getTranslation } from '../utils/translations';

interface HeaderProps {
  stats: UserProfileStats;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenQuickDoubt: () => void;
  onOpenStreakDetails: () => void;
  onOpenAppGuide: () => void;
  onOpenRankPredictor: () => void;
  language: AppLanguage;
  onToggleLanguage: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  stats,
  activeTab,
  setActiveTab,
  onOpenQuickDoubt,
  onOpenStreakDetails,
  onOpenAppGuide,
  onOpenRankPredictor,
  language,
  onToggleLanguage,
}) => {
  const t = getTranslation(language);
  const dailyGoal = stats.dailyGoal || 5;
  const todaySolved = stats.todayQuestionsSolved || 0;
  const isGoalMet = stats.todayGoalCompleted;

  return (
    <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Brand: JEEPulse */}
        <div 
          onClick={() => setActiveTab('pyq')}
          className="flex items-center gap-3 cursor-pointer select-none group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-sky-500 to-amber-500 p-0.5 shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Activity className="w-5 h-5 text-indigo-400 group-hover:scale-110 transition-transform" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black text-base sm:text-lg tracking-tight text-white flex items-center">
                <span>JEE</span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-sky-300 to-emerald-400">
                  Pulse
                </span>
                <span className="text-[9px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-mono font-bold ml-1.5 border border-indigo-500/30">
                  PRO
                </span>
              </span>
              <span className="text-[10px] text-amber-400/80 tracking-wider font-mono font-bold hidden sm:inline">2010–2026</span>
            </div>
            <p className="text-[11px] text-slate-400 flex items-center gap-1.5">
              <span className="text-amber-300/95 font-bold flex items-center gap-1">
                <span>👑</span>
                <span>Owner: MOHIT PARAMHANS</span>
              </span>
              <span className="text-slate-600 hidden md:inline">·</span>
              <span className="hidden md:inline text-slate-400">
                {language === 'hi' ? '17 वर्षों के PYQs (500/वर्ष) · 1,000 CBT टेस्ट' : '500 PYQs/Year · 1,000 CBT Tests'}
              </span>
            </p>
          </div>
        </div>

        {/* Action Controls & Gamification Counters */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Owner Badge: MOHIT PARAMHANS */}
          <div 
            title="Platform Owner: MOHIT PARAMHANS"
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/20 via-orange-500/15 to-amber-600/20 border border-amber-500/50 shadow-sm text-xs select-none"
          >
            <span className="text-amber-400 text-sm">👑</span>
            <div className="flex flex-col text-left leading-none">
              <span className="text-[8px] text-amber-400/90 font-mono uppercase tracking-wider font-bold">
                Owner
              </span>
              <span className="text-[11px] font-extrabold text-amber-200 tracking-wide whitespace-nowrap">
                MOHIT PARAMHANS
              </span>
            </div>
          </div>

          {/* All-India Rank (AIR) Predictor Button (shifted with spacing) */}
          <button
            onClick={onOpenRankPredictor}
            title={language === 'hi' ? 'ऑल इंडिया रैंक (AIR) प्रेडिक्टर' : 'All-India Rank (AIR) Predictor'}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 ml-0.5 sm:ml-1.5 rounded-xl bg-amber-950/60 border border-amber-500/40 hover:border-amber-400 hover:bg-amber-900/60 text-xs font-bold text-amber-300 hover:text-white transition-all select-none shadow-sm cursor-pointer"
          >
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden md:inline">{language === 'hi' ? 'AIR रैंक प्रेडिक्टर' : 'AIR Predictor'}</span>
          </button>

          {/* App Guide & Walkthrough (How to Use) */}
          <button
            onClick={onOpenAppGuide}
            title={language === 'hi' ? 'ऐप कैसे इस्तेमाल करें? (यूजर गाइड)' : 'How to Use This App (User Guide)'}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-indigo-950/60 border border-indigo-500/40 hover:border-indigo-400 hover:bg-indigo-900/60 text-xs font-bold text-indigo-300 hover:text-white transition-all select-none shadow-sm cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">{t.appGuide}</span>
          </button>

          {/* Language Switcher (EN / हिंदी) */}
          <button
            onClick={onToggleLanguage}
            title={language === 'en' ? 'हिंदी में बदलें (Switch to Hindi)' : 'Switch to English (अंग्रेजी में बदलें)'}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-indigo-500/60 hover:bg-slate-850 text-xs font-bold text-slate-200 transition-all select-none shadow-sm cursor-pointer"
          >
            <Languages className="w-3.5 h-3.5 text-indigo-400" />
            <span className={language === 'en' ? 'text-indigo-400 font-extrabold' : 'text-slate-400'}>EN</span>
            <span className="text-slate-600">/</span>
            <span className={language === 'hi' ? 'text-amber-400 font-extrabold' : 'text-slate-400'}>हिं</span>
          </button>

          {/* Daily Streak Tracking System */}
          <div 
            onClick={onOpenStreakDetails}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => { if (e.key === 'Enter') onOpenStreakDetails(); }}
            title={`Study Streak: ${stats.streakDays} days!`}
            className="flex items-center gap-2 px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-900 border border-amber-500/30 hover:border-amber-500/60 hover:bg-slate-850 cursor-pointer transition-all shadow-sm group select-none"
          >
            <div className="relative flex items-center justify-center">
              <span className="absolute -inset-1 bg-amber-500/20 rounded-full blur-sm group-hover:bg-amber-500/30 transition-all" />
              <Flame className="w-4 h-4 fill-amber-400 text-amber-400 animate-pulse relative z-10" />
            </div>

            <div className="flex items-baseline gap-0.5">
              <span className="font-extrabold text-amber-300 text-xs sm:text-sm">{stats.streakDays}d</span>
              <span className="text-[11px] text-amber-400/80 font-medium hidden md:inline">
                {t.streak}
              </span>
            </div>

            <div className="h-4 w-px bg-slate-800 hidden sm:block" />

            {isGoalMet ? (
              <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-emerald-950/70 border border-emerald-500/40 text-[10px] font-bold text-emerald-300">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                <span>{t.goalMet}</span>
              </span>
            ) : (
              <div className="hidden sm:flex items-center gap-1.5 text-[11px] text-slate-300 font-mono">
                <Target className="w-3 h-3 text-indigo-400" />
                <span>{todaySolved}/{dailyGoal}</span>
              </div>
            )}
          </div>

          {/* Coins Balance */}
          <div 
            onClick={() => setActiveTab('notes')}
            title="Sankalp Coins"
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs font-medium text-amber-300 cursor-pointer hover:bg-amber-500/20 transition-colors"
          >
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="font-bold">{stats.coins}</span>
            <span className="text-amber-400/80 hidden md:inline">{t.coins}</span>
          </div>

          {/* Quick AI Guru Button */}
          <button
            onClick={onOpenQuickDoubt}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition-all active:scale-95"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{t.askAiGuru}</span>
            <span className="sm:hidden">AI Guru</span>
          </button>
        </div>
      </div>
    </header>
  );
};
