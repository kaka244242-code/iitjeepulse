import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Image as ImageIcon, 
  Sparkles, 
  Trash2, 
  Volume2, 
  VolumeX, 
  Lightbulb, 
  Zap, 
  CheckCircle2, 
  X,
  Compass,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { Subject, Question, ChatMessage } from '../types';
import { askAIDoubtMaster } from '../services/aiMaster';

interface AIMasterChatProps {
  initialQuestion?: Question | null;
  onClearInitialQuestion?: () => void;
}

export const AIMasterChat: React.FC<AIMasterChatProps> = ({
  initialQuestion,
  onClearInitialQuestion,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      content: `**Namaste IITian! I am Guru AI, your personal IIT JEE Master & Doubt Solver.**

I can help you crack any doubt in **Physics, Chemistry, or Mathematics** for JEE Main & JEE Advanced:
• **Step-by-step rigorous derivations** with conceptual clarity
• **Topper shortcut tricks & option elimination hacks**
• **Trap identification** to prevent negative marking (-1)
• **Snap photo of any problem** from your notebook or textbook!

How can I help you today? Choose a subject below or type your doubt!`,
      timestamp: 'Just now',
    },
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<Subject>('Physics');
  const [topicContext, setTopicContext] = useState('');
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // If pre-filled question is passed from PYQ or test review, load it into input!
  useEffect(() => {
    if (initialQuestion) {
      setSelectedSubject(initialQuestion.subject);
      setTopicContext(initialQuestion.topic);
      const promptText = `I have a doubt on this ${initialQuestion.exam} (${initialQuestion.year}) question:
"${initialQuestion.question}"

Options:
A: ${initialQuestion.options[0]}
B: ${initialQuestion.options[1]}
C: ${initialQuestion.options[2]}
D: ${initialQuestion.options[3]}

Please explain the fundamental concept, derive the solution step-by-step, and share the topper's 30-second elimination shortcut!`;
      setInputPrompt(promptText);
    }
  }, [initialQuestion]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isGenerating]);

  // Handle image upload
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setAttachedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Send message
  const handleSend = async () => {
    if ((!inputPrompt.trim() && !attachedImage) || isGenerating) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: inputPrompt,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      subject: selectedSubject,
      doubtImage: attachedImage || undefined,
    };

    setMessages((prev) => [...prev, userMessage]);
    const currentPrompt = inputPrompt;
    const currentImg = attachedImage;

    setInputPrompt('');
    setAttachedImage(null);
    if (onClearInitialQuestion) onClearInitialQuestion();
    setIsGenerating(true);

    try {
      const history = messages
        .filter((m) => m.id !== 'welcome')
        .map((m) => ({
          role: m.role,
          content: m.content,
        }));

      const res = await askAIDoubtMaster({
        prompt: currentPrompt || 'Please solve and explain this problem step-by-step.',
        subject: selectedSubject,
        topic: topicContext || undefined,
        imageBase64: currentImg || undefined,
        mimeType: 'image/jpeg',
        history,
      });

      if (res.success && res.text) {
        const aiMessage: ChatMessage = {
          id: `ai-${Date.now()}`,
          role: 'model',
          content: res.text,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          subject: selectedSubject,
        };
        setMessages((prev) => [...prev, aiMessage]);
      } else {
        const errMessage: ChatMessage = {
          id: `err-${Date.now()}`,
          role: 'model',
          content: `⚠️ Could not complete request: ${res.error || 'Please try asking again.'}`,
          timestamp: 'Now',
        };
        setMessages((prev) => [...prev, errMessage]);
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'model',
          content: '⚠️ Failed to connect to AI Master. Please verify your connection or try again.',
          timestamp: 'Now',
        },
      ]);
    } finally {
      setIsGenerating(false);
    }
  };

  // Text to Speech
  const toggleSpeech = (id: string, text: string) => {
    if ('speechSynthesis' in window) {
      if (isSpeaking === id) {
        window.speechSynthesis.cancel();
        setIsSpeaking(null);
      } else {
        window.speechSynthesis.cancel();
        // Clean markdown symbols for cleaner speech
        const cleanText = text.replace(/[*#`_$\\]/g, '');
        const utterance = new SpeechSynthesisUtterance(cleanText);
        utterance.rate = 1.05;
        utterance.pitch = 1.0;
        utterance.onend = () => setIsSpeaking(null);
        utterance.onerror = () => setIsSpeaking(null);
        window.speechSynthesis.speak(utterance);
        setIsSpeaking(id);
      }
    }
  };

  const handleQuickPrompt = (promptText: string) => {
    setInputPrompt(promptText);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden flex flex-col h-[740px] shadow-xl">
      {/* Header */}
      <div className="bg-slate-950 p-4 border-b border-slate-800 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white">Guru AI · IIT JEE Doubt Master</h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                Gemini 3.8 Flash
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Instant derivations, conceptual breakdowns & shortcut tricks
            </p>
          </div>
        </div>

        {/* Subject Mode Selector */}
        <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-lg border border-slate-800">
          {(['Physics', 'Chemistry', 'Mathematics'] as Subject[]).map((subj) => (
            <button
              key={subj}
              onClick={() => setSelectedSubject(subj)}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                selectedSubject === subj
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {subj}
            </button>
          ))}
        </div>
      </div>

      {/* Quick Prompts Bar */}
      <div className="bg-slate-950/60 px-4 py-2 border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto text-xs scrollbar-none">
        <span className="text-slate-500 text-[11px] font-medium shrink-0">Quick Ask:</span>
        <button
          onClick={() => handleQuickPrompt("Explain the core concept and step-by-step derivation for: ")}
          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 shrink-0 text-[11px]"
        >
          🔬 Step-by-step derivation
        </button>
        <button
          onClick={() => handleQuickPrompt("What is the fastest 30-sec elimination trick for: ")}
          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 shrink-0 text-[11px]"
        >
          ⚡ JEE Topper Shortcut
        </button>
        <button
          onClick={() => handleQuickPrompt("What are the common traps and negative marking mistakes in: ")}
          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 shrink-0 text-[11px]"
        >
          ⚠️ Negative Marking Traps
        </button>
        <button
          onClick={() => handleQuickPrompt("Give me 2 similar practice questions for JEE Advanced on: ")}
          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 shrink-0 text-[11px]"
        >
          🎯 2 Similar Practice Qs
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-4 sm:p-5 overflow-y-auto space-y-4">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              {/* Avatar */}
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 text-xs font-bold ${
                isUser
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gradient-to-br from-indigo-500 to-purple-600 text-white'
              }`}>
                {isUser ? 'ME' : <Bot className="w-4 h-4" />}
              </div>

              {/* Message Content Bubble */}
              <div className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed ${
                isUser
                  ? 'bg-indigo-600 text-white rounded-tr-none'
                  : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-none shadow-sm'
              }`}>
                {/* Subject badge if present */}
                {msg.subject && !isUser && (
                  <div className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider mb-1">
                    {msg.subject} Master
                  </div>
                )}

                {/* Attached Image Preview */}
                {msg.doubtImage && (
                  <div className="mb-3 rounded-lg overflow-hidden border border-indigo-400/40 max-h-56">
                    <img
                      src={msg.doubtImage}
                      alt="Uploaded doubt"
                      className="w-full object-contain bg-black/40"
                    />
                  </div>
                )}

                {/* Body Text */}
                <div className="whitespace-pre-line leading-relaxed font-sans">
                  {msg.content}
                </div>

                {/* Footer Controls for AI Messages */}
                {!isUser && (
                  <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-800 text-[11px] text-slate-500">
                    <span>{msg.timestamp}</span>
                    <button
                      onClick={() => toggleSpeech(msg.id, msg.content)}
                      className="flex items-center gap-1 hover:text-indigo-400 transition-colors"
                      title="Read aloud"
                    >
                      {isSpeaking === msg.id ? (
                        <>
                          <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                          <span className="text-rose-400">Stop Voice</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>Listen (TTS)</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {isGenerating && (
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/30 text-indigo-400 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 animate-spin" />
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-2xl rounded-tl-none p-4 text-xs text-slate-400 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
              <span>Guru AI is analyzing problem & formulating step-by-step solution...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-slate-950 border-t border-slate-800">
        {/* Attached image preview pill */}
        {attachedImage && (
          <div className="flex items-center gap-2 mb-2 p-2 bg-slate-900 border border-slate-800 rounded-lg max-w-sm">
            <img src={attachedImage} alt="Thumbnail" className="w-10 h-10 object-cover rounded" />
            <div className="flex-1 truncate text-xs text-slate-300">Image attached for doubt solving</div>
            <button
              onClick={() => setAttachedImage(null)}
              className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <div className="flex items-end gap-2">
          {/* File Upload Button */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-indigo-400 hover:bg-slate-850 transition-colors shrink-0"
            title="Snap or Upload photo of question"
          >
            <ImageIcon className="w-5 h-5" />
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageSelect}
            accept="image/*"
            className="hidden"
          />

          {/* Text Area */}
          <textarea
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={`Ask ${selectedSubject} doubt or question statement...`}
            rows={2}
            className="flex-1 px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 resize-none transition-colors"
          />

          {/* Send Button */}
          <button
            disabled={(!inputPrompt.trim() && !attachedImage) || isGenerating}
            onClick={handleSend}
            className="p-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-bold transition-all shadow-md shadow-indigo-600/30 shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
