import React, { useState, useEffect, useMemo } from 'react';
import { 
  Zap, 
  RotateCcw, 
  Clock, 
  Layers, 
  CheckCircle2, 
  XCircle, 
  ChevronRight, 
  ChevronLeft, 
  HelpCircle, 
  Sparkles,
  Trophy,
  Filter,
  Play,
  BookOpen,
  Globe,
  FileText,
  Shuffle,
  Check,
  AlertTriangle,
  Lightbulb,
  Flame,
  Award,
  ArrowRight
} from 'lucide-react';
import { Question, Subject, Flashcard, AppLanguage } from '../types';
import { mockFlashcards } from '../data/flashcards';
import { chapterPracticeSheets } from '../data/chapterPracticeSheets';

interface PracticeModesProps {
  questions: Question[];
  onSolveQuestion: (isCorrect: boolean) => void;
  onAskAIMaster: (question: Question) => void;
  language?: AppLanguage;
}

export const PracticeModes: React.FC<PracticeModesProps> = ({
  questions,
  onSolveQuestion,
  onAskAIMaster,
  language = 'en',
}) => {
  const [activeSubMode, setActiveSubMode] = useState<'sprint' | 'drill' | 'flashcards' | 'custom' | 'sheets'>('drill');
  const [practiceLang, setPracticeLang] = useState<AppLanguage>(language);
  const [selectedSheetIndex, setSelectedSheetIndex] = useState<number>(0);
  const [sheetQIndex, setSheetQIndex] = useState<number>(0);
  const [sheetAnswer, setSheetAnswer] = useState<number | null>(null);
  const [sheetSolVisible, setSheetSolVisible] = useState<boolean>(false);

  // --- SPRINT MODE STATE ---
  const [sprintQuestions, setSprintQuestions] = useState<Question[]>([]);
  const [sprintIndex, setSprintIndex] = useState(0);
  const [sprintTimeLeft, setSprintTimeLeft] = useState(60);
  const [sprintActive, setSprintActive] = useState(false);
  const [sprintScore, setSprintScore] = useState({ correct: 0, wrong: 0 });
  const [sprintAnswered, setSprintAnswered] = useState<number | null>(null);
  const [sprintSubject, setSprintSubject] = useState<Subject | 'All'>('All');

  // --- DRILL MODE STATE ---
  const [drillSubject, setDrillSubject] = useState<Subject>('Physics');
  const [drillTopic, setDrillTopic] = useState<string>('All');
  const [drillIndex, setDrillIndex] = useState(0);
  const [drillAnswer, setDrillAnswer] = useState<number | null>(null);
  const [drillHintVisible, setDrillHintVisible] = useState(false);

  // --- FLASHCARD STATE ---
  const [flashcardDeck, setFlashcardDeck] = useState<Flashcard[]>(mockFlashcards);
  const [flashcardIndex, setFlashcardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [flashcardFilter, setFlashcardFilter] = useState<Subject | 'All'>('All');
  const [flashcardChapterFilter, setFlashcardChapterFilter] = useState<string>('All');
  const [cardLang, setCardLang] = useState<'bilingual' | 'en' | 'hi'>('bilingual');
  const [masteredCards, setMasteredCards] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem('jeepulse_mastered_flashcards');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const toggleMastered = (cardId: string) => {
    setMasteredCards((prev) => {
      const next = { ...prev, [cardId]: !prev[cardId] };
      try {
        localStorage.setItem('jeepulse_mastered_flashcards', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  const shuffleFlashcards = () => {
    setFlashcardDeck((prev) => [...prev].sort(() => 0.5 - Math.random()));
    setFlashcardIndex(0);
    setIsFlipped(false);
  };

  // Filter questions for sprint
  const filteredSprintPool = questions.filter(
    (q) => sprintSubject === 'All' || q.subject === sprintSubject
  );

  const startSprint = () => {
    const shuffled = [...filteredSprintPool].sort(() => 0.5 - Math.random());
    setSprintQuestions(shuffled);
    setSprintIndex(0);
    setSprintTimeLeft(60);
    setSprintScore({ correct: 0, wrong: 0 });
    setSprintAnswered(null);
    setSprintActive(true);
  };

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (sprintActive && sprintTimeLeft > 0 && sprintAnswered === null) {
      timer = setTimeout(() => setSprintTimeLeft((prev) => prev - 1), 1000);
    } else if (sprintActive && sprintTimeLeft === 0 && sprintAnswered === null) {
      // Time expired for this question
      setSprintAnswered(-1);
      setSprintScore((prev) => ({ ...prev, wrong: prev.wrong + 1 }));
    }
    return () => clearTimeout(timer);
  }, [sprintActive, sprintTimeLeft, sprintAnswered]);

  const handleSprintAnswer = (optionIdx: number) => {
    if (sprintAnswered !== null) return;
    const currentQ = sprintQuestions[sprintIndex];
    setSprintAnswered(optionIdx);
    const isCorrect = optionIdx === currentQ.correctOption;
    if (isCorrect) {
      setSprintScore((prev) => ({ ...prev, correct: prev.correct + 1 }));
      onSolveQuestion(true);
    } else {
      setSprintScore((prev) => ({ ...prev, wrong: prev.wrong + 1 }));
      onSolveQuestion(false);
    }
  };

  const nextSprintQuestion = () => {
    if (sprintIndex + 1 < sprintQuestions.length) {
      setSprintIndex((prev) => prev + 1);
      setSprintAnswered(null);
      setSprintTimeLeft(60);
    } else {
      setSprintActive(false); // Finished sprint
    }
  };

  // Drill questions
  const drillPool = questions.filter((q) => {
    if (q.subject !== drillSubject) return false;
    if (drillTopic !== 'All' && q.topic !== drillTopic) return false;
    return true;
  });

  const currentDrillQ = drillPool[drillIndex] || drillPool[0];

  const handleDrillAnswer = (optIdx: number) => {
    if (drillAnswer !== null) return;
    setDrillAnswer(optIdx);
    onSolveQuestion(optIdx === currentDrillQ.correctOption);
  };

  // Flashcard chapters list based on selected subject
  const availableChapters = useMemo(() => {
    const set = new Set<string>();
    mockFlashcards.forEach((fc) => {
      if (fc.chapter && (flashcardFilter === 'All' || fc.subject === flashcardFilter)) {
        set.add(fc.chapter);
      }
    });
    return Array.from(set);
  }, [flashcardFilter]);

  // Filtered flashcards based on subject and chapter
  const filteredFlashcards = useMemo(() => {
    return flashcardDeck.filter((fc) => {
      if (flashcardFilter !== 'All' && fc.subject !== flashcardFilter) return false;
      if (flashcardChapterFilter !== 'All' && fc.chapter !== flashcardChapterFilter) return false;
      return true;
    });
  }, [flashcardDeck, flashcardFilter, flashcardChapterFilter]);

  const currentCard = filteredFlashcards[flashcardIndex] || filteredFlashcards[0];

  // Number of mastered cards in the current filtered set
  const masteredInFilterCount = useMemo(() => {
    return filteredFlashcards.filter((fc) => masteredCards[fc.id]).length;
  }, [filteredFlashcards, masteredCards]);

  // Keyboard navigation for active recall flashcards
  useEffect(() => {
    if (activeSubMode !== 'flashcards') return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement || 
        e.target instanceof HTMLTextAreaElement || 
        e.target instanceof HTMLSelectElement
      ) {
        return;
      }
      if (e.code === 'Space') {
        e.preventDefault();
        setIsFlipped((f) => !f);
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        setFlashcardIndex((idx) => (idx + 1 < filteredFlashcards.length ? idx + 1 : idx));
        setIsFlipped(false);
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        setFlashcardIndex((idx) => (idx > 0 ? idx - 1 : 0));
        setIsFlipped(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeSubMode, filteredFlashcards.length]);

  return (
    <div className="space-y-6">
      {/* Sub-mode Navigation Selector */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <button
          onClick={() => setActiveSubMode('sheets')}
          className={`flex flex-col items-start p-3.5 rounded-xl border text-left transition-all ${
            activeSubMode === 'sheets'
              ? 'bg-indigo-950/40 border-indigo-500 text-white shadow-lg shadow-indigo-500/10'
              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <div className="flex items-center justify-between w-full mb-2">
            <span className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400">
              <FileText className="w-4 h-4" />
            </span>
            <span className="text-[10px] uppercase font-mono font-bold text-amber-400">20 Qs/Chap</span>
          </div>
          <h4 className="text-xs sm:text-sm font-bold text-slate-100">Practice Sheets</h4>
          <p className="text-[11px] text-slate-400 mt-0.5">20 Bilingual Qs per chapter with step solutions</p>
        </button>

        <button
          onClick={() => setActiveSubMode('sprint')}
          className={`flex flex-col items-start p-3.5 rounded-xl border text-left transition-all ${
            activeSubMode === 'sprint'
              ? 'bg-amber-950/30 border-amber-500/80 text-white shadow-lg shadow-amber-500/10'
              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <div className="flex items-center justify-between w-full mb-2">
            <span className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
              <Zap className="w-4 h-4" />
            </span>
            <span className="text-[10px] uppercase font-mono font-bold text-amber-400">60-Sec</span>
          </div>
          <h4 className="text-xs sm:text-sm font-bold text-slate-100">Timed Sprint</h4>
          <p className="text-[11px] text-slate-400 mt-0.5">Rapid fire to build instinct under time pressure</p>
        </button>

        <button
          onClick={() => setActiveSubMode('drill')}
          className={`flex flex-col items-start p-3.5 rounded-xl border text-left transition-all ${
            activeSubMode === 'drill'
              ? 'bg-blue-950/30 border-blue-500/80 text-white shadow-lg shadow-blue-500/10'
              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <div className="flex items-center justify-between w-full mb-2">
            <span className="p-1.5 rounded-lg bg-blue-500/10 text-blue-400">
              <Layers className="w-4 h-4" />
            </span>
            <span className="text-[10px] uppercase font-mono font-bold text-blue-400">Step Hints</span>
          </div>
          <h4 className="text-xs sm:text-sm font-bold text-slate-100">Topic Drill</h4>
          <p className="text-[11px] text-slate-400 mt-0.5">Topic mastery with formulas & step hints</p>
        </button>

        <button
          onClick={() => setActiveSubMode('flashcards')}
          className={`flex flex-col items-start p-3.5 rounded-xl border text-left transition-all ${
            activeSubMode === 'flashcards'
              ? 'bg-emerald-950/30 border-emerald-500/80 text-white shadow-lg shadow-emerald-500/10'
              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <div className="flex items-center justify-between w-full mb-2">
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <RotateCcw className="w-4 h-4" />
            </span>
            <span className="text-[10px] uppercase font-mono font-bold text-emerald-400">Flashcards</span>
          </div>
          <h4 className="text-xs sm:text-sm font-bold text-slate-100">Formula Cards</h4>
          <p className="text-[11px] text-slate-400 mt-0.5">Active recall cards for high-yield formulas</p>
        </button>

        <button
          onClick={() => setActiveSubMode('custom')}
          className={`flex flex-col items-start p-3.5 rounded-xl border text-left transition-all ${
            activeSubMode === 'custom'
              ? 'bg-purple-950/30 border-purple-500/80 text-white shadow-lg shadow-purple-500/10'
              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-850'
          }`}
        >
          <div className="flex items-center justify-between w-full mb-2">
            <span className="p-1.5 rounded-lg bg-purple-500/10 text-purple-400">
              <Sparkles className="w-4 h-4" />
            </span>
            <span className="text-[10px] uppercase font-mono font-bold text-purple-400">AI Adaptive</span>
          </div>
          <h4 className="text-xs sm:text-sm font-bold text-slate-100">AI Questions</h4>
          <p className="text-[11px] text-slate-400 mt-0.5">Generate fresh questions on weak topics</p>
        </button>
      </div>

      {/* --- RENDER CHAPTER PRACTICE SHEETS (20 Qs per chapter, Bilingual) --- */}
      {activeSubMode === 'sheets' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 space-y-5">
          {/* Header & Controls */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  20 QUESTIONS PER CHAPTER · BILINGUAL
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  2010–2026 Archive
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-white">
                {practiceLang === 'hi' ? 'अध्यायवार प्रैक्टिस शीट्स (प्रत्येक अध्याय में 20 प्रश्न)' : 'Chapter Practice Sheets (20 Qs per Chapter)'}
              </h3>
            </div>

            {/* Language Toggle */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">Language:</span>
              <button
                onClick={() => setPracticeLang((l) => (l === 'en' ? 'hi' : 'en'))}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs font-bold text-amber-300 hover:text-white cursor-pointer"
              >
                <Globe className="w-3.5 h-3.5 text-indigo-400" />
                <span>{practiceLang === 'hi' ? 'English' : 'हिन्दी'}</span>
              </button>
            </div>
          </div>

          {/* Chapter Selector Dropdown / Chips */}
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-1">
              <label className="text-xs font-bold text-slate-300 shrink-0">
                {practiceLang === 'hi' ? 'चैप्टर चुनें:' : 'Select Chapter Sheet:'}
              </label>
              <select
                value={selectedSheetIndex}
                onChange={(e) => {
                  setSelectedSheetIndex(parseInt(e.target.value, 10));
                  setSheetQIndex(0);
                  setSheetAnswer(null);
                  setSheetSolVisible(false);
                }}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white font-medium focus:outline-none focus:border-indigo-500"
              >
                {chapterPracticeSheets.map((sheet, sIdx) => (
                  <option key={sheet.id} value={sIdx}>
                    [{sheet.subject}] {practiceLang === 'hi' ? sheet.chapterHindi : sheet.chapter}
                  </option>
                ))}
              </select>
            </div>

            <div className="text-xs font-mono text-slate-400 text-right shrink-0">
              Question <strong className="text-white">{sheetQIndex + 1}</strong> of <strong className="text-white">{chapterPracticeSheets[selectedSheetIndex]?.questionsCount || 20}</strong>
            </div>
          </div>

          {/* Current Question Display */}
          {(() => {
            const currentSheet = chapterPracticeSheets[selectedSheetIndex] || chapterPracticeSheets[0];
            const currentQ = currentSheet.exemplarQuestions[sheetQIndex] || currentSheet.exemplarQuestions[0];
            const isCorrect = sheetAnswer !== null && sheetAnswer === currentQ.correctOption;

            return (
              <div className="bg-slate-950 rounded-xl p-5 border border-slate-800 space-y-4">
                {/* Meta header */}
                <div className="flex items-center justify-between text-xs pb-3 border-b border-slate-800/80">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-indigo-400">
                      Problem #{sheetQIndex + 1} · [{currentQ.exam} {currentQ.year}]
                    </span>
                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                      +4 / -1 Marking
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    {currentSheet.subject}
                  </span>
                </div>

                {/* Question Bilingual Statement */}
                <div className="space-y-2">
                  <div className="text-sm font-medium text-slate-100 leading-relaxed">
                    {currentQ.questionEn}
                  </div>
                  <div className="text-xs sm:text-sm text-slate-300 leading-relaxed bg-slate-900/50 p-3 rounded-lg border border-indigo-500/20">
                    <strong className="text-amber-400 block text-[10px] mb-0.5">🌐 हिन्दी अनुवाद:</strong>
                    {currentQ.questionHi}
                  </div>
                </div>

                {/* 4 Options */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {currentQ.optionsEn.map((opt, optIdx) => {
                    const optHi = currentQ.optionsHi?.[optIdx];
                    let btnStyle = 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-200';
                    if (sheetAnswer !== null) {
                      if (optIdx === currentQ.correctOption) {
                        btnStyle = 'bg-emerald-950/60 border-emerald-500 text-emerald-200 font-bold';
                      } else if (sheetAnswer === optIdx) {
                        btnStyle = 'bg-rose-950/60 border-rose-500 text-rose-200';
                      } else {
                        btnStyle = 'bg-slate-900/40 border-slate-800/40 text-slate-500 opacity-60';
                      }
                    }

                    return (
                      <button
                        key={optIdx}
                        disabled={sheetAnswer !== null}
                        onClick={() => {
                          setSheetAnswer(optIdx);
                          onSolveQuestion(optIdx === currentQ.correctOption);
                        }}
                        className={`p-3 rounded-xl border text-left text-xs transition-all flex items-start gap-2.5 cursor-pointer ${btnStyle}`}
                      >
                        <span className="w-5 h-5 rounded bg-slate-800 text-slate-300 font-mono font-bold flex items-center justify-center shrink-0">
                          {['A', 'B', 'C', 'D'][optIdx]}
                        </span>
                        <div className="flex-1">
                          <span className="block leading-snug">{opt}</span>
                          {optHi && <span className="text-[11px] text-slate-400 block mt-0.5">{optHi}</span>}
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Answer Feedback Banner */}
                {sheetAnswer !== null && (
                  <div className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                    isCorrect
                      ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                      : 'bg-rose-950/40 border-rose-500/50 text-rose-300'
                  }`}>
                    <div className="flex items-center gap-2 font-bold">
                      {isCorrect ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-rose-400" />}
                      <span>{isCorrect ? 'Correct! +4 Marks & +5 Coins added' : `Incorrect (-1 Mark). Correct is (${['A','B','C','D'][currentQ.correctOption]})`}</span>
                    </div>
                    <button
                      onClick={() => setSheetSolVisible(!sheetSolVisible)}
                      className="px-2.5 py-1 bg-slate-900 text-white rounded font-bold hover:bg-slate-800 transition-colors"
                    >
                      {sheetSolVisible ? 'Hide Solution' : 'View Derivation'}
                    </button>
                  </div>
                )}

                {/* Solution Box */}
                {(sheetSolVisible || sheetAnswer !== null) && (
                  <div className="space-y-3 pt-3 border-t border-slate-800/80 animate-in fade-in">
                    <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                      <h5 className="font-bold text-xs text-white flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Step-by-Step Derivation (Bilingual):</span>
                      </h5>
                      <div className="text-xs text-slate-300 whitespace-pre-wrap font-sans leading-relaxed">
                        {currentQ.solutionEn}
                      </div>
                      <div className="text-xs text-slate-300 whitespace-pre-wrap font-sans leading-relaxed pt-2 border-t border-slate-800/80">
                        <strong className="text-amber-400 block text-[11px] mb-0.5">हिन्दी में समाधान:</strong>
                        {currentQ.solutionHi}
                      </div>
                    </div>

                    {/* Topper Trick */}
                    <div className="p-3 bg-amber-950/20 border border-amber-500/30 rounded-xl text-xs space-y-1">
                      <strong className="text-amber-300 block font-bold">
                        ⚡ Kota AIR-Ranker Shortcut Hack:
                      </strong>
                      <p className="text-slate-300 text-[11px] leading-relaxed">
                        {currentQ.topperTrickEn}
                      </p>
                      <p className="text-slate-400 text-[11px] leading-relaxed pt-1 border-t border-amber-500/20">
                        {currentQ.topperTrickHi}
                      </p>
                    </div>
                  </div>
                )}

                {/* Question Navigation Bar (1 to 20) */}
                <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="flex items-center gap-1 overflow-x-auto max-w-full pb-1">
                    {Array.from({ length: currentSheet.exemplarQuestions.length }, (_, i) => (
                      <button
                        key={i}
                        onClick={() => {
                          setSheetQIndex(i);
                          setSheetAnswer(null);
                          setSheetSolVisible(false);
                        }}
                        className={`w-7 h-7 rounded text-xs font-mono font-bold transition-all cursor-pointer ${
                          sheetQIndex === i
                            ? 'bg-indigo-600 text-white shadow-sm'
                            : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {i + 1}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      disabled={sheetQIndex === 0}
                      onClick={() => {
                        setSheetQIndex((q) => q - 1);
                        setSheetAnswer(null);
                        setSheetSolVisible(false);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white disabled:opacity-40 flex items-center gap-1 cursor-pointer"
                    >
                      <ChevronLeft className="w-4 h-4" />
                      <span>Prev</span>
                    </button>
                    <button
                      disabled={sheetQIndex + 1 >= currentSheet.exemplarQuestions.length}
                      onClick={() => {
                        setSheetQIndex((q) => q + 1);
                        setSheetAnswer(null);
                        setSheetSolVisible(false);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white disabled:opacity-40 flex items-center gap-1 cursor-pointer"
                    >
                      <span>Next</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* --- RENDER SPRINT MODE --- */}
      {activeSubMode === 'sprint' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          {!sprintActive && sprintQuestions.length === 0 ? (
            <div className="max-w-md mx-auto text-center py-8">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center mx-auto mb-4 border border-amber-500/20">
                <Zap className="w-8 h-8 fill-amber-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Timed Rapid Sprint</h3>
              <p className="text-xs text-slate-400 mb-6 leading-relaxed">
                You will get 60 seconds per question. Think fast, eliminate impossible options, and train your brain to perform under exam time constraints!
              </p>

              <div className="mb-6 text-left bg-slate-950 p-4 rounded-lg border border-slate-800">
                <label className="text-xs font-semibold text-slate-300 block mb-2">Select Sprint Subject</label>
                <div className="flex gap-2">
                  {(['All', 'Physics', 'Chemistry', 'Mathematics'] as const).map((sub) => (
                    <button
                      key={sub}
                      onClick={() => setSprintSubject(sub)}
                      className={`flex-1 py-2 text-xs font-medium rounded-md border transition-all ${
                        sprintSubject === sub
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {sub}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={startSprint}
                className="w-full py-3 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-bold rounded-xl text-sm shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4 fill-slate-950" />
                <span>Start Rapid Sprint</span>
              </button>
            </div>
          ) : !sprintActive && sprintQuestions.length > 0 ? (
            /* Sprint Summary */
            <div className="max-w-md mx-auto text-center py-8">
              <Trophy className="w-16 h-16 text-amber-400 mx-auto mb-4 animate-bounce" />
              <h3 className="text-2xl font-bold text-white">Sprint Completed!</h3>
              <p className="text-xs text-slate-400 mt-1 mb-6">Great discipline! Here is your speed summary:</p>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-emerald-950/30 border border-emerald-800/50 p-4 rounded-xl">
                  <span className="text-3xl font-extrabold text-emerald-400">{sprintScore.correct}</span>
                  <span className="text-xs text-emerald-300 block mt-1">Correct (+{sprintScore.correct * 4} Marks)</span>
                </div>
                <div className="bg-rose-950/30 border border-rose-800/50 p-4 rounded-xl">
                  <span className="text-3xl font-extrabold text-rose-400">{sprintScore.wrong}</span>
                  <span className="text-xs text-rose-300 block mt-1">Missed / Wrong</span>
                </div>
              </div>

              <button
                onClick={startSprint}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-sm"
              >
                Start Another Sprint
              </button>
            </div>
          ) : (
            /* Active Sprint Question */
            (() => {
              const currentQ = sprintQuestions[sprintIndex];
              return (
                <div>
                  {/* Top Bar: Progress, Timer & Score */}
                  <div className="flex items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
                    <div className="text-xs text-slate-400">
                      Question <span className="font-bold text-white">{sprintIndex + 1}</span> of {sprintQuestions.length}
                    </div>

                    {/* Countdown Timer */}
                    <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-mono text-sm font-bold ${
                      sprintTimeLeft <= 10
                        ? 'bg-rose-950/80 text-rose-400 border border-rose-600 animate-pulse'
                        : 'bg-slate-950 text-amber-400 border border-slate-800'
                    }`}>
                      <Clock className="w-4 h-4" />
                      <span>{sprintTimeLeft}s</span>
                    </div>

                    <div className="text-xs text-slate-400">
                      Score: <span className="text-emerald-400 font-bold">{sprintScore.correct}</span> / {sprintIndex}
                    </div>
                  </div>

                  {/* Question */}
                  <div className="text-xs text-slate-400 mb-2">
                    {currentQ.subject} · {currentQ.topic} · {currentQ.exam}
                  </div>
                  <div className="text-base font-medium text-slate-100 mb-6 leading-relaxed">
                    {currentQ.question}
                  </div>

                  {/* Options */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
                    {currentQ.options.map((opt, optIdx) => {
                      let btnStyle = 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-200';
                      if (sprintAnswered !== null) {
                        if (optIdx === currentQ.correctOption) {
                          btnStyle = 'bg-emerald-950/60 border-emerald-500 text-emerald-200 font-medium';
                        } else if (sprintAnswered === optIdx) {
                          btnStyle = 'bg-rose-950/60 border-rose-500 text-rose-200';
                        } else {
                          btnStyle = 'bg-slate-950/40 border-slate-800/40 text-slate-500 opacity-60';
                        }
                      }

                      return (
                        <button
                          key={optIdx}
                          disabled={sprintAnswered !== null}
                          onClick={() => handleSprintAnswer(optIdx)}
                          className={`p-3.5 rounded-lg border text-left text-xs transition-all flex items-start gap-3 ${btnStyle}`}
                        >
                          <span className="w-5 h-5 rounded bg-slate-800 text-slate-300 font-mono font-bold flex items-center justify-center shrink-0">
                            {['A', 'B', 'C', 'D'][optIdx]}
                          </span>
                          <span className="flex-1 pt-0.5">{opt}</span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Sprint Footer */}
                  {sprintAnswered !== null && (
                    <div className="flex items-center justify-between p-4 bg-slate-950 rounded-xl border border-slate-800">
                      <div className="text-xs">
                        {sprintAnswered === currentQ.correctOption ? (
                          <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                            <CheckCircle2 className="w-4 h-4" /> Correct Answer! (+4)
                          </span>
                        ) : (
                          <span className="text-rose-400 font-bold flex items-center gap-1.5">
                            <XCircle className="w-4 h-4" /> Correct was Option {['A', 'B', 'C', 'D'][currentQ.correctOption]}
                          </span>
                        )}
                      </div>
                      <button
                        onClick={nextSprintQuestion}
                        className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5"
                      >
                        <span>{sprintIndex + 1 === sprintQuestions.length ? 'Finish Sprint' : 'Next Question'}</span>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })()
          )}
        </div>
      )}

      {/* --- RENDER CHAPTER DRILL MODE --- */}
      {activeSubMode === 'drill' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          {/* Topic Selectors */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2">
              {(['Physics', 'Chemistry', 'Mathematics'] as Subject[]).map((sub) => (
                <button
                  key={sub}
                  onClick={() => {
                    setDrillSubject(sub);
                    setDrillTopic('All');
                    setDrillIndex(0);
                    setDrillAnswer(null);
                    setDrillHintVisible(false);
                  }}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                    drillSubject === sub
                      ? 'bg-blue-600 border-blue-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {sub}
                </button>
              ))}
            </div>

            <div className="text-xs text-slate-400">
              Question <strong className="text-white">{drillIndex + 1}</strong> of {drillPool.length}
            </div>
          </div>

          {currentDrillQ ? (
            <div>
              {/* Question metadata */}
              <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
                <span>{currentDrillQ.exam} {currentDrillQ.year}</span>
                <span aria-hidden="true">·</span>
                <span className="text-indigo-400 font-medium">{currentDrillQ.topic}</span>
                <span aria-hidden="true">·</span>
                <span>{currentDrillQ.difficulty}</span>
              </div>

              {/* Statement */}
              <div className="text-sm font-medium text-slate-100 mb-5 leading-relaxed">
                {currentDrillQ.question}
              </div>

              {/* Options */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
                {currentDrillQ.options.map((opt, optIdx) => {
                  let btnStyle = 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-200';
                  if (drillAnswer !== null) {
                    if (optIdx === currentDrillQ.correctOption) {
                      btnStyle = 'bg-emerald-950/60 border-emerald-500 text-emerald-200 font-medium';
                    } else if (drillAnswer === optIdx) {
                      btnStyle = 'bg-rose-950/60 border-rose-500 text-rose-200';
                    } else {
                      btnStyle = 'bg-slate-950/40 border-slate-800/40 text-slate-500 opacity-60';
                    }
                  }

                  return (
                    <button
                      key={optIdx}
                      disabled={drillAnswer !== null}
                      onClick={() => handleDrillAnswer(optIdx)}
                      className={`p-3.5 rounded-lg border text-left text-xs transition-all flex items-start gap-3 ${btnStyle}`}
                    >
                      <span className="w-5 h-5 rounded bg-slate-800 text-slate-300 font-mono font-bold flex items-center justify-center shrink-0">
                        {['A', 'B', 'C', 'D'][optIdx]}
                      </span>
                      <span className="flex-1 pt-0.5">{opt}</span>
                    </button>
                  );
                })}
              </div>

              {/* Hint & AI Master Actions */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setDrillHintVisible(!drillHintVisible)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-lg text-xs"
                  >
                    <HelpCircle className="w-3.5 h-3.5 text-blue-400" />
                    <span>{drillHintVisible ? 'Hide Key Formula' : 'Reveal Key Formula'}</span>
                  </button>

                  <button
                    onClick={() => onAskAIMaster(currentDrillQ)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 rounded-lg text-xs font-semibold"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>AI Master Explain</span>
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    disabled={drillIndex === 0}
                    onClick={() => {
                      setDrillIndex((prev) => prev - 1);
                      setDrillAnswer(null);
                      setDrillHintVisible(false);
                    }}
                    className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white disabled:opacity-40"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    disabled={drillIndex + 1 >= drillPool.length}
                    onClick={() => {
                      setDrillIndex((prev) => prev + 1);
                      setDrillAnswer(null);
                      setDrillHintVisible(false);
                    }}
                    className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white disabled:opacity-40"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Hint Box */}
              {drillHintVisible && currentDrillQ.keyFormula && (
                <div className="mt-4 p-3.5 bg-blue-950/40 border border-blue-800/40 rounded-lg text-xs text-blue-200">
                  <strong className="text-blue-300 block mb-1">Guiding Formula:</strong>
                  <code>{currentDrillQ.keyFormula}</code>
                </div>
              )}

              {/* Solution on Answered */}
              {drillAnswer !== null && (
                <div className="mt-4 p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                  <div className="text-xs font-bold text-slate-200">
                    Solution Derivation (Correct Option: {['A', 'B', 'C', 'D'][currentDrillQ.correctOption]})
                  </div>
                  <pre className="text-xs text-slate-400 font-mono whitespace-pre-line leading-relaxed">
                    {currentDrillQ.solution}
                  </pre>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-10 text-slate-500 text-xs">No questions found for this topic.</div>
          )}
        </div>
      )}

      {/* --- RENDER FLASHCARDS MODE --- */}
      {activeSubMode === 'flashcards' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-6">
          {/* Header & Controls Bar */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-800">
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1.5">
                <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 font-mono uppercase tracking-wider">
                  <RotateCcw className="w-3 h-3 text-emerald-400" />
                  Active Recall · Chapter Formula Flashcards
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  Kota AIR Hacks &amp; JEE Traps
                </span>
              </div>
              <h3 className="text-base sm:text-xl font-black text-white tracking-tight flex items-center gap-2">
                <span>{practiceLang === 'hi' ? 'चैप्टर फॉर्मूला एवं कॉन्सेप्ट फ्लैशकार्ड्स' : 'Chapter Formula & Concept Flashcards'}</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1 max-w-xl">
                {practiceLang === 'hi' 
                  ? 'अपने अध्ययनरत अध्यायों के मुख्य सूत्र, जाह्न-टेलर व लाइबनिज नियम, कोटा AIR ट्रिक्स और सामान्य त्रुटियों का त्वरित रिवीज़न करें।'
                  : 'Quickly flip through key formulas, derivations, conditions, Kota AIR shortcuts, and exam traps for the chapters you are studying.'}
              </p>
            </div>

            {/* Language Switcher & Deck Tools */}
            <div className="flex flex-wrap items-center gap-2">
              {/* Language Toggle */}
              <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-bold">
                <Globe className="w-3.5 h-3.5 text-indigo-400 ml-1.5 mr-1" />
                {(['bilingual', 'en', 'hi'] as const).map((l) => (
                  <button
                    key={l}
                    onClick={() => setCardLang(l)}
                    className={`px-2 py-1 rounded-lg transition-all ${
                      cardLang === l
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {l === 'bilingual' ? 'द्विभाषी (Both)' : l === 'en' ? 'EN' : 'हिन्दी'}
                  </button>
                ))}
              </div>

              {/* Shuffle Button */}
              <button
                onClick={shuffleFlashcards}
                title="Shuffle card deck"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white hover:border-slate-700 transition-all cursor-pointer"
              >
                <Shuffle className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Shuffle</span>
              </button>
            </div>
          </div>

          {/* Filtering Bar: Subject Tabs & Chapter Dropdown */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center bg-slate-950/80 p-3.5 rounded-xl border border-slate-800">
            {/* Subject Filters */}
            <div className="md:col-span-5 flex flex-wrap items-center gap-1.5">
              {(['All', 'Physics', 'Chemistry', 'Mathematics'] as const).map((sub) => {
                const count = flashcardDeck.filter(
                  (fc) => sub === 'All' || fc.subject === sub
                ).length;
                const isSelected = flashcardFilter === sub;
                return (
                  <button
                    key={sub}
                    onClick={() => {
                      setFlashcardFilter(sub);
                      setFlashcardChapterFilter('All');
                      setFlashcardIndex(0);
                      setIsFlipped(false);
                    }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                        : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white hover:border-slate-700'
                    }`}
                  >
                    <span>{sub === 'All' ? 'All Subjects' : sub}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                      isSelected ? 'bg-emerald-800 text-emerald-100' : 'bg-slate-800 text-slate-500'
                    }`}>
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Chapter Dropdown Selector */}
            <div className="md:col-span-4 flex items-center gap-2">
              <label className="text-xs font-bold text-slate-300 shrink-0">
                {practiceLang === 'hi' ? 'अध्याय:' : 'Chapter:'}
              </label>
              <select
                value={flashcardChapterFilter}
                onChange={(e) => {
                  setFlashcardChapterFilter(e.target.value);
                  setFlashcardIndex(0);
                  setIsFlipped(false);
                }}
                className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white font-medium focus:outline-none focus:border-emerald-500"
              >
                <option value="All">All Chapters in {flashcardFilter === 'All' ? 'Curriculum' : flashcardFilter} ({filteredFlashcards.length} cards)</option>
                {availableChapters.map((chap) => {
                  const cCount = flashcardDeck.filter(
                    (fc) => fc.chapter === chap && (flashcardFilter === 'All' || fc.subject === flashcardFilter)
                  ).length;
                  return (
                    <option key={chap} value={chap}>
                      {chap} ({cCount} cards)
                    </option>
                  );
                })}
              </select>
            </div>

            {/* Chapter Mastery Progress Bar */}
            <div className="md:col-span-3 flex flex-col justify-center text-right">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-[11px] text-slate-400 font-semibold flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-amber-400" />
                  <span>Mastery:</span>
                </span>
                <span className="font-mono font-bold text-emerald-400">
                  {masteredInFilterCount} / {filteredFlashcards.length} Mastered
                </span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden border border-slate-800">
                <div 
                  className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-300"
                  style={{ 
                    width: `${filteredFlashcards.length > 0 ? (masteredInFilterCount / filteredFlashcards.length) * 100 : 0}%` 
                  }}
                />
              </div>
            </div>
          </div>

          {/* Flashcard Body */}
          {currentCard ? (
            <div className="max-w-2xl mx-auto space-y-4">
              {/* Card Meta & Breadcrumb */}
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <div className="flex items-center gap-2 truncate">
                  <span className="font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    {currentCard.subject}
                  </span>
                  <span className="text-slate-300 font-medium truncate">
                    {currentCard.chapter || currentCard.topic}
                  </span>
                  {currentCard.importance && (
                    <span className="hidden sm:inline-flex items-center gap-1 text-[10px] text-amber-300 font-bold bg-amber-500/15 px-2 py-0.5 rounded border border-amber-500/30">
                      <Flame className="w-3 h-3 text-amber-400" />
                      {currentCard.importance}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => toggleMastered(currentCard.id)}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      masteredCards[currentCard.id]
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50'
                        : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                    }`}
                  >
                    <Check className={`w-3.5 h-3.5 ${masteredCards[currentCard.id] ? 'text-emerald-400' : 'text-slate-500'}`} />
                    <span>{masteredCards[currentCard.id] ? 'Mastered' : 'Mark Mastered'}</span>
                  </button>
                  <span className="font-mono text-slate-400">
                    {flashcardIndex + 1} / {filteredFlashcards.length}
                  </span>
                </div>
              </div>

              {/* Interactive Flip Card Component */}
              <div
                onClick={() => setIsFlipped(!isFlipped)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setIsFlipped(!isFlipped);
                  }
                }}
                className={`cursor-pointer min-h-[340px] p-6 sm:p-7 rounded-2xl border-2 transition-all flex flex-col justify-between shadow-2xl relative select-none group ${
                  isFlipped
                    ? 'bg-gradient-to-br from-slate-950 via-emerald-950/20 to-slate-900 border-emerald-500/70 shadow-emerald-950/30'
                    : 'bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950/20 border-slate-700/80 hover:border-emerald-500/80 shadow-indigo-950/20'
                }`}
              >
                {/* Top Section */}
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <span className={`w-2 h-2 rounded-full ${isFlipped ? 'bg-emerald-400 animate-ping' : 'bg-indigo-400'}`} />
                      {isFlipped ? 'BACK: FORMULA & DERIVATION' : 'FRONT: CORE CONCEPT & QUESTION'}
                    </span>
                    {currentCard.examFrequency && (
                      <span className="text-[11px] text-amber-400/90 font-mono font-semibold">
                        {currentCard.examFrequency}
                      </span>
                    )}
                  </div>

                  <h3 className="text-lg sm:text-xl font-extrabold text-white mb-4 tracking-tight group-hover:text-emerald-300 transition-colors">
                    {currentCard.title}
                  </h3>

                  {/* FRONT CONTENT */}
                  {!isFlipped && (
                    <div className="space-y-3">
                      {(cardLang === 'en' || cardLang === 'bilingual') && (
                        <div className="text-sm sm:text-base font-normal text-slate-200 leading-relaxed whitespace-pre-line font-sans">
                          {currentCard.front}
                        </div>
                      )}
                      {(cardLang === 'hi' || cardLang === 'bilingual') && (currentCard.frontHindi) && (
                        <div className={`text-xs sm:text-sm leading-relaxed whitespace-pre-line text-slate-300 ${
                          cardLang === 'bilingual' ? 'bg-slate-900/60 p-3 rounded-xl border border-indigo-500/20' : ''
                        }`}>
                          {cardLang === 'bilingual' && (
                            <strong className="text-[10px] text-amber-400 block mb-1 font-bold uppercase tracking-wider">
                              🌐 हिन्दी अनुवाद:
                            </strong>
                          )}
                          {currentCard.frontHindi}
                        </div>
                      )}
                    </div>
                  )}

                  {/* BACK CONTENT (FORMULAS, DERIVATIONS & RULES) */}
                  {isFlipped && (
                    <div className="space-y-3">
                      {/* Prominent Formula Callout */}
                      {currentCard.formula && (
                        <div className="bg-emerald-950/40 border border-emerald-500/40 p-3 sm:p-3.5 rounded-xl text-emerald-200 font-mono text-xs sm:text-sm font-semibold shadow-inner">
                          <span className="text-[10px] text-emerald-400 font-sans uppercase font-bold block mb-1">
                            📌 Key Governing Formula:
                          </span>
                          <code>{currentCard.formula}</code>
                        </div>
                      )}

                      {/* Derivation / Step breakdown */}
                      {(cardLang === 'en' || cardLang === 'bilingual') && (
                        <div className="text-xs sm:text-sm text-slate-200 font-mono whitespace-pre-line leading-relaxed bg-slate-950/80 p-3.5 rounded-xl border border-slate-800">
                          {currentCard.back}
                        </div>
                      )}

                      {/* Hindi Explanation if applicable */}
                      {(cardLang === 'hi' || (cardLang === 'bilingual' && currentCard.backHindi)) && (
                        <div className="text-xs sm:text-sm text-slate-300 whitespace-pre-line leading-relaxed bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
                          {cardLang === 'bilingual' && (
                            <strong className="text-[10px] text-amber-400 block mb-1 font-bold uppercase tracking-wider">
                              🌐 हिन्दी व्याख्या:
                            </strong>
                          )}
                          {currentCard.backHindi || currentCard.back}
                        </div>
                      )}

                      {/* Kota Ranker Hack */}
                      {currentCard.topperHack && (
                        <div className="p-3 bg-gradient-to-r from-indigo-950/40 to-slate-900 border border-indigo-500/30 rounded-xl text-xs text-indigo-200 flex items-start gap-2">
                          <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                          <div>
                            <strong className="text-indigo-300 block mb-0.5">Kota AIR Speed Hack:</strong>
                            <span>{currentCard.topperHack}</span>
                          </div>
                        </div>
                      )}

                      {/* Trap Warning Alert */}
                      {currentCard.tips && (
                        <div className="p-3 bg-amber-950/30 border border-amber-800/40 rounded-xl text-xs text-amber-300 flex items-start gap-2">
                          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                          <div>
                            <strong className="text-amber-400 block mb-0.5">⚠️ Common JEE Trap:</strong>
                            <span>{currentCard.tips}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Bottom Card Action Hint */}
                <div className="pt-4 mt-6 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                  <span className="flex items-center gap-1.5 font-medium">
                    <RotateCcw className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{isFlipped ? 'Click or press [Space] to see question' : 'Click or press [Space] to reveal formula'}</span>
                  </span>
                  <span className="hidden sm:inline font-mono text-[11px] text-slate-500">
                    Use [← / →] to navigate
                  </span>
                </div>
              </div>

              {/* Navigation Controls & Action Buttons */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
                {/* Previous & Next */}
                <div className="flex items-center gap-2">
                  <button
                    disabled={flashcardIndex === 0}
                    onClick={() => {
                      setFlashcardIndex((prev) => Math.max(0, prev - 1));
                      setIsFlipped(false);
                    }}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-bold disabled:opacity-40 disabled:hover:bg-slate-950 cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Previous</span>
                  </button>

                  <button
                    onClick={() => setIsFlipped(!isFlipped)}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-xl bg-emerald-600/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600/30 text-xs font-extrabold cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>{isFlipped ? 'Show Front' : 'Flip Card'}</span>
                  </button>

                  <button
                    disabled={flashcardIndex + 1 >= filteredFlashcards.length}
                    onClick={() => {
                      setFlashcardIndex((prev) => Math.min(filteredFlashcards.length - 1, prev + 1));
                      setIsFlipped(false);
                    }}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-bold disabled:opacity-40 disabled:hover:bg-slate-950 cursor-pointer"
                  >
                    <span>Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Direct Link to Chapter Practice Sheet */}
                {(() => {
                  const targetChapter = currentCard.chapter;
                  const matchingSheetIndex = chapterPracticeSheets.findIndex(
                    (s) => targetChapter && s.chapter.toLowerCase().includes(targetChapter.toLowerCase().slice(0, 8))
                  );

                  if (matchingSheetIndex !== -1) {
                    return (
                      <button
                        onClick={() => {
                          setSelectedSheetIndex(matchingSheetIndex);
                          setActiveSubMode('sheets');
                          setSheetQIndex(0);
                        }}
                        className="flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-bold transition-all cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Practice 20 PYQs for this Chapter</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    );
                  }
                  return null;
                })()}
              </div>
            </div>
          ) : (
            <div className="text-center py-12 bg-slate-950 rounded-xl border border-slate-800 max-w-md mx-auto">
              <RotateCcw className="w-10 h-10 text-slate-600 mx-auto mb-3" />
              <h4 className="text-sm font-bold text-white mb-1">No Flashcards Found</h4>
              <p className="text-xs text-slate-400 mb-4">
                No cards match the selected chapter filter.
              </p>
              <button
                onClick={() => {
                  setFlashcardFilter('All');
                  setFlashcardChapterFilter('All');
                }}
                className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-xs font-bold"
              >
                Reset Filters
              </button>
            </div>
          )}
        </div>
      )}

      {/* --- RENDER AI ADAPTIVE DRILL --- */}
      {activeSubMode === 'custom' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 text-center max-w-lg mx-auto">
          <div className="w-14 h-14 rounded-2xl bg-purple-500/10 text-purple-400 flex items-center justify-center mx-auto mb-4 border border-purple-500/20">
            <Sparkles className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-bold text-white mb-2">AI Adaptive Question Generator</h3>
          <p className="text-xs text-slate-400 mb-6 leading-relaxed">
            Need fresh custom questions for your weak chapters? Tell Guru AI what topic to generate at JEE Main or JEE Advanced level!
          </p>

          <div className="space-y-3 text-left mb-6">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Target Topic</label>
              <input
                type="text"
                placeholder="e.g. Rotational toppling, Carbocation rearrangement, Leibnitz rule"
                defaultValue="Rotational toppling and friction"
                id="ai-topic-input"
                className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Subject</label>
                <select id="ai-subject-select" className="w-full px-2.5 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200">
                  <option value="Physics">Physics</option>
                  <option value="Chemistry">Chemistry</option>
                  <option value="Mathematics">Mathematics</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Exam Level</label>
                <select id="ai-diff-select" className="w-full px-2.5 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200">
                  <option value="JEE Main">JEE Main</option>
                  <option value="JEE Advanced">JEE Advanced</option>
                </select>
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              const topicEl = document.getElementById('ai-topic-input') as HTMLInputElement;
              const subEl = document.getElementById('ai-subject-select') as HTMLSelectElement;
              const diffEl = document.getElementById('ai-diff-select') as HTMLSelectElement;
              onAskAIMaster({
                id: 'custom-req',
                exam: diffEl?.value as any || 'JEE Main',
                year: 2025,
                subject: subEl?.value as any || 'Physics',
                topic: topicEl?.value || 'Mechanics',
                difficulty: 'Moderate',
                question: `Please generate 2 authentic ${diffEl?.value || 'JEE Main'} level questions on ${topicEl?.value || 'Rotational dynamics'} with step-by-step solutions and shortcut tricks.`,
                options: [],
                correctOption: 0,
                solution: '',
              });
            }}
            className="w-full py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>Generate with AI Master</span>
          </button>
        </div>
      )}
    </div>
  );
};
