import React, { useState, useEffect, useMemo } from 'react';
import { 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  RotateCcw, 
  BarChart3, 
  ArrowRight, 
  Sparkles, 
  Trophy, 
  Check, 
  Target, 
  FileText,
  Search,
  Zap,
  Globe,
  Flame,
  Award,
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Filter,
  CheckCircle
} from 'lucide-react';
import { MockTest, Question, Subject, UserTestAttempt, AppLanguage } from '../types';
import { saveTestAttempt } from '../services/storage';
import { getTranslation } from '../utils/translations';
import { 
  ALL_1000_TESTS, 
  queryTestsCatalog, 
  getCatalogTestByIdOrNumber, 
  TestCatalogItem 
} from '../data/testsCatalog';
import { catalogItemToMockTest } from '../data/generateTestQuestions';

interface CBTTestSimulatorProps {
  onAskAIMaster: (question: Question) => void;
  onTestCompleted: (goalJustCompleted?: boolean) => void;
  initialTest?: MockTest | null;
  onClearInitialTest?: () => void;
  language: AppLanguage;
}

type QuestionStatus = 'not_visited' | 'not_answered' | 'answered' | 'marked_for_review' | 'answered_and_marked';

export const CBTTestSimulator: React.FC<CBTTestSimulatorProps> = ({
  onAskAIMaster,
  onTestCompleted,
  initialTest,
  onClearInitialTest,
  language,
}) => {
  const t = getTranslation(language);

  // Active Test State
  const [selectedTest, setSelectedTest] = useState<MockTest | null>(null);
  const [isTestRunning, setIsTestRunning] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

  // In-test Live Language Switcher (NTA Official: English vs हिन्दी)
  const [inTestLang, setInTestLang] = useState<AppLanguage>(language);
  const [isBilingualView, setIsBilingualView] = useState<boolean>(false);

  // Catalog Browsing & Filter States
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [subjectFilter, setSubjectFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [jumpInput, setJumpInput] = useState<string>('');
  const pageSize = 12;

  // Time remaining in seconds
  const [secondsRemaining, setSecondsRemaining] = useState(0);

  // Answers: { [questionId]: optionIndex | null }
  const [userAnswers, setUserAnswers] = useState<Record<string, number | null>>({});

  // Question statuses
  const [questionStatuses, setQuestionStatuses] = useState<Record<string, QuestionStatus>>({});

  // Completed scorecard state
  const [completedAttempt, setCompletedAttempt] = useState<UserTestAttempt | null>(null);
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);

  // Subject filter in test
  const [activeSubject, setActiveSubject] = useState<Subject>('Physics');

  // Keep inTestLang synced when global language changes
  useEffect(() => {
    setInTestLang(language);
  }, [language]);

  // Query catalog items based on user filters
  const catalogResult = useMemo(() => {
    return queryTestsCatalog({
      searchQuery,
      category: categoryFilter,
      subject: subjectFilter,
      page: currentPage,
      pageSize,
    });
  }, [searchQuery, categoryFilter, subjectFilter, currentPage]);

  // Automatically start test if initialTest was passed from PYQExplorer or elsewhere
  useEffect(() => {
    if (initialTest) {
      handleStartTest(initialTest);
      if (onClearInitialTest) onClearInitialTest();
    }
  }, [initialTest]);

  // Start a test (MockTest)
  const handleStartTest = (test: MockTest) => {
    setSelectedTest(test);
    setSecondsRemaining(test.durationMinutes * 60);
    setCurrentQuestionIndex(0);
    setUserAnswers({});

    const initialStatuses: Record<string, QuestionStatus> = {};
    test.questions.forEach((q, idx) => {
      initialStatuses[q.id] = idx === 0 ? 'not_answered' : 'not_visited';
    });
    setQuestionStatuses(initialStatuses);
    setIsTestRunning(true);
    setCompletedAttempt(null);
  };

  // Launch a test from catalog item
  const handleLaunchCatalogTest = (item: TestCatalogItem) => {
    const fullTest = catalogItemToMockTest(item);
    handleStartTest(fullTest);
  };

  // Jump to specific test number
  const handleJumpToTestNumber = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!jumpInput.trim()) return;
    const item = getCatalogTestByIdOrNumber(jumpInput.trim());
    if (item) {
      handleLaunchCatalogTest(item);
      setJumpInput('');
    }
  };

  // Timer countdown
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTestRunning && secondsRemaining > 0) {
      interval = setInterval(() => {
        setSecondsRemaining((prev) => {
          if (prev <= 1) {
            handleFinalSubmit();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTestRunning, secondsRemaining]);

  const formatTimer = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    if (hours > 0) {
      return `${hours}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const currentQuestion = selectedTest ? selectedTest.questions[currentQuestionIndex] : null;

  // Question selection from palette
  const handleJumpToQuestion = (index: number) => {
    if (!selectedTest) return;
    const q = selectedTest.questions[index];
    if (questionStatuses[q.id] === 'not_visited') {
      setQuestionStatuses((prev) => ({ ...prev, [q.id]: 'not_answered' }));
    }
    setCurrentQuestionIndex(index);
    if (q.subject !== activeSubject) {
      setActiveSubject(q.subject);
    }
  };

  // Select option for current question
  const handleSelectOption = (optionIndex: number) => {
    if (!currentQuestion) return;
    setUserAnswers((prev) => ({ ...prev, [currentQuestion.id]: optionIndex }));
  };

  // Save and Next
  const handleSaveAndNext = () => {
    if (!selectedTest || !currentQuestion) return;
    const hasAnswer = userAnswers[currentQuestion.id] !== undefined && userAnswers[currentQuestion.id] !== null;

    setQuestionStatuses((prev) => ({
      ...prev,
      [currentQuestion.id]: hasAnswer ? 'answered' : 'not_answered',
    }));

    if (currentQuestionIndex + 1 < selectedTest.questions.length) {
      handleJumpToQuestion(currentQuestionIndex + 1);
    }
  };

  // Clear Response
  const handleClearResponse = () => {
    if (!currentQuestion) return;
    setUserAnswers((prev) => ({ ...prev, [currentQuestion.id]: null }));
    setQuestionStatuses((prev) => ({ ...prev, [currentQuestion.id]: 'not_answered' }));
  };

  // Mark for Review & Next
  const handleMarkForReview = () => {
    if (!selectedTest || !currentQuestion) return;
    const hasAnswer = userAnswers[currentQuestion.id] !== undefined && userAnswers[currentQuestion.id] !== null;

    setQuestionStatuses((prev) => ({
      ...prev,
      [currentQuestion.id]: hasAnswer ? 'answered_and_marked' : 'marked_for_review',
    }));

    if (currentQuestionIndex + 1 < selectedTest.questions.length) {
      handleJumpToQuestion(currentQuestionIndex + 1);
    }
  };

  // Final Submit Test
  const handleFinalSubmit = () => {
    if (!selectedTest) return;
    setIsTestRunning(false);
    setShowSubmitConfirm(false);

    let score = 0;
    let correctCount = 0;
    let incorrectCount = 0;
    let unattemptedCount = 0;

    const subjectScores = {
      Physics: { score: 0, total: 0, correct: 0, incorrect: 0 },
      Chemistry: { score: 0, total: 0, correct: 0, incorrect: 0 },
      Mathematics: { score: 0, total: 0, correct: 0, incorrect: 0 },
    };

    selectedTest.questions.forEach((q) => {
      const ans = userAnswers[q.id];
      subjectScores[q.subject].total += 4;

      if (ans === undefined || ans === null) {
        unattemptedCount += 1;
      } else if (ans === q.correctOption) {
        score += 4;
        correctCount += 1;
        subjectScores[q.subject].score += 4;
        subjectScores[q.subject].correct += 1;
      } else {
        score -= 1;
        incorrectCount += 1;
        subjectScores[q.subject].score -= 1;
        subjectScores[q.subject].incorrect += 1;
      }
    });

    const totalAttempted = correctCount + incorrectCount;
    const accuracy = totalAttempted > 0 ? Math.round((correctCount / totalAttempted) * 100) : 0;
    const totalTimeSpentSeconds = selectedTest.durationMinutes * 60 - secondsRemaining;

    const attempt: UserTestAttempt = {
      id: `attempt-${Date.now()}`,
      testId: selectedTest.id,
      testTitle: selectedTest.title,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      totalTimeSpentSeconds,
      score,
      maxScore: selectedTest.totalMarks,
      accuracy,
      correctCount,
      incorrectCount,
      unattemptedCount,
      subjectScores,
      answers: userAnswers,
    };

    const { goalJustCompleted } = saveTestAttempt(attempt);
    setCompletedAttempt(attempt);
    onTestCompleted(goalJustCompleted);
  };

  // Count summaries for palette
  const answeredCount = Object.values(questionStatuses).filter((s) => s === 'answered' || s === 'answered_and_marked').length;
  const notAnsweredCount = Object.values(questionStatuses).filter((s) => s === 'not_answered').length;
  const markedReviewCount = Object.values(questionStatuses).filter((s) => s === 'marked_for_review' || s === 'answered_and_marked').length;
  const notVisitedCount = selectedTest ? selectedTest.questions.length - answeredCount - notAnsweredCount - (markedReviewCount - Object.values(questionStatuses).filter(s => s === 'answered_and_marked').length) : 0;

  // =========================================================================
  // --- RENDER 1: 1,000 TESTS CATALOG & SELECTION SCREEN ---
  // =========================================================================
  if (!isTestRunning && !completedAttempt) {
    return (
      <div className="space-y-6">
        {/* Hero Banner */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-7 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
          
          <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 mb-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/10 border border-amber-500/30 text-amber-300 flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span>1,000 Complete Tests Vault (75 Qs / 300 Marks Each)</span>
                </span>
                <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center gap-1">
                  <Globe className="w-3 h-3" />
                  <span>Hindi & English</span>
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                {t.cbtHeading}
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-3xl leading-relaxed">
                {t.cbtSubheading}
              </p>
            </div>

            {/* Jump to Test # Input */}
            <form 
              onSubmit={handleJumpToTestNumber} 
              className="flex items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800 shrink-0 w-full sm:w-auto"
            >
              <div className="flex items-center gap-1.5 px-2 text-xs text-slate-400 font-mono">
                <Target className="w-4 h-4 text-indigo-400" />
                <span>{t.jumpToTest}</span>
              </div>
              <input
                type="number"
                min="1"
                max="1000"
                placeholder="1–1000"
                value={jumpInput}
                onChange={(e) => setJumpInput(e.target.value)}
                className="w-20 px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs font-mono font-bold text-white text-center focus:outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg transition-all"
              >
                Go
              </button>
            </form>
          </div>

          {/* Search Bar & Subject Filter */}
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 mb-5">
            <div className="sm:col-span-8 relative">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder={t.searchTestsPlaceholder}
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>

            <div className="sm:col-span-4 flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
              {(['All', 'Physics', 'Chemistry', 'Mathematics'] as const).map((sub) => (
                <button
                  key={sub}
                  onClick={() => {
                    setSubjectFilter(sub);
                    setCurrentPage(1);
                  }}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all text-center ${
                    subjectFilter === sub
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {sub === 'All' ? 'All' : sub.slice(0, 4)}
                </button>
              ))}
            </div>
          </div>

          {/* Category Track Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin border-b border-slate-800/80 mb-6">
            {[
              { id: 'all', label: `All 1,000 Tests (${ALL_1000_TESTS.length})`, icon: Sparkles },
              { id: 'high_yield_ranker', label: t.highYieldTrack, icon: Flame },
              { id: 'chapter', label: t.chapterHardTrack, icon: Target },
              { id: 'hard_advanced', label: t.advancedTrack, icon: Award },
              { id: 'grand_mock', label: t.grandMockTrack, icon: FileText },
              { id: 'tricky_traps', label: t.trickyTrapsTrack, icon: Zap },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = categoryFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setCategoryFilter(tab.id);
                    setCurrentPage(1);
                  }}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                      : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 shrink-0" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Catalog Count & Active Info */}
          <div className="flex items-center justify-between text-xs text-slate-400 mb-4 px-1">
            <span>
              Showing <strong className="text-white">{catalogResult.tests.length}</strong> of{' '}
              <strong className="text-white">{catalogResult.totalCount}</strong> tests
              {searchQuery && ` matching "${searchQuery}"`}
            </span>
            <span className="text-[11px] font-mono">
              Page {catalogResult.currentPage} of {catalogResult.totalPages}
            </span>
          </div>

          {/* 1,000 Tests Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {catalogResult.tests.map((item) => (
              <div
                key={item.id}
                className="bg-slate-950 border border-slate-800 hover:border-indigo-500/50 rounded-xl p-5 flex flex-col justify-between transition-all duration-200 group shadow-sm hover:shadow-indigo-950/20"
              >
                <div>
                  {/* Top Badges */}
                  <div className="flex items-center justify-between gap-2 mb-2.5">
                    <span className="font-mono text-[11px] font-black text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                      TEST #{item.testNumber.toString().padStart(3, '0')}
                    </span>
                    <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                      {item.examType}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors line-clamp-2 leading-snug mb-2">
                    {language === 'hi' ? item.titleHindi : item.title}
                  </h3>

                  {/* Weightage Banner */}
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[11px] font-semibold mb-3">
                    <Flame className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>{language === 'hi' ? item.weightageTagHindi : item.weightageTag}</span>
                  </div>

                  {/* High Yield Tip Box */}
                  <div className="bg-slate-900/80 rounded-lg p-2.5 border border-slate-800/80 text-[11px] text-slate-300 mb-4 leading-relaxed">
                    <span className="font-bold text-indigo-400 block mb-0.5">
                      💡 {language === 'hi' ? 'कम समय में सर्वाधिक अंक सलाह:' : 'Fast-Marks Score Strategy:'}
                    </span>
                    <span className="line-clamp-2">
                      {language === 'hi' ? item.highYieldTipsHindi : item.highYieldTips}
                    </span>
                  </div>

                  {/* Exam Specs Table */}
                  <div className="space-y-1.5 text-xs text-slate-300 border-t border-slate-800/80 pt-3 mb-4 font-mono">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Pattern:</span>
                      <span className="text-emerald-400 font-bold">75 Qs · 300 Marks</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Duration:</span>
                      <span className="text-white font-semibold">180 Minutes (+4 / -1)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Language:</span>
                      <span className="text-indigo-400 font-semibold flex items-center gap-1">
                        <Globe className="w-3 h-3" />
                        <span>English + हिंदी</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Launch Button */}
                <button
                  onClick={() => handleLaunchCatalogTest(item)}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-lg transition-all flex items-center justify-center gap-2 shadow-sm shadow-indigo-600/30 cursor-pointer"
                >
                  <span>{language === 'hi' ? '75-प्रश्नों का टेस्ट शुरू करें' : 'Start 75-Q CBT Test'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

          {/* Empty Search State */}
          {catalogResult.tests.length === 0 && (
            <div className="text-center py-16 bg-slate-950 rounded-xl border border-slate-800">
              <AlertCircle className="w-10 h-10 text-slate-600 mx-auto mb-3" />
              <p className="text-slate-300 font-bold text-sm">No tests match your filter or search query.</p>
              <p className="text-xs text-slate-500 mt-1">Try searching by topic, chapter, or entering a number like "142".</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setCategoryFilter('all');
                  setSubjectFilter('All');
                }}
                className="mt-4 px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-lg"
              >
                Reset All Filters
              </button>
            </div>
          )}

          {/* Pagination Controls */}
          {catalogResult.totalPages > 1 && (
            <div className="flex items-center justify-between gap-4 pt-6 border-t border-slate-800">
              <button
                disabled={catalogResult.currentPage <= 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                className="px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Previous</span>
              </button>

              <div className="flex items-center gap-1.5">
                {Array.from({ length: Math.min(5, catalogResult.totalPages) }, (_, i) => {
                  let pageNum: number;
                  if (catalogResult.totalPages <= 5) {
                    pageNum = i + 1;
                  } else if (catalogResult.currentPage <= 3) {
                    pageNum = i + 1;
                  } else if (catalogResult.currentPage >= catalogResult.totalPages - 2) {
                    pageNum = catalogResult.totalPages - 4 + i;
                  } else {
                    pageNum = catalogResult.currentPage - 2 + i;
                  }

                  return (
                    <button
                      key={pageNum}
                      onClick={() => setCurrentPage(pageNum)}
                      className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${
                        catalogResult.currentPage === pageNum
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                      }`}
                    >
                      {pageNum}
                    </button>
                  );
                })}
              </div>

              <button
                disabled={catalogResult.currentPage >= catalogResult.totalPages}
                onClick={() => setCurrentPage((p) => Math.min(catalogResult.totalPages, p + 1))}
                className="px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 transition-colors"
              >
                <span>Next</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* NTA Exam Guidelines Banner */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
          <h4 className="font-bold text-slate-200 text-sm mb-2 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400" />
            Official NTA Computer-Based Test (CBT) Guidelines:
          </h4>
          <p>• <strong>Marking Scheme:</strong> Each correct response fetches <strong>+4 marks</strong>; each incorrect response deducts <strong>-1 mark</strong>. Unattempted questions fetch <strong>0 marks</strong>.</p>
          <p>• <strong>Bilingual Switch:</strong> You can switch questions between English and Hindi in real time during the examination using the top-right language bar.</p>
          <p>• <strong>High-Yield Section:</strong> Tests are curated from authentic 2010 to 2026 JEE papers focusing on the highest return topics to achieve maximum marks in minimum time.</p>
        </div>
      </div>
    );
  }

  // =========================================================================
  // --- RENDER 2: SCORECARD / COMPLETED TEST SCREEN ---
  // =========================================================================
  if (completedAttempt && selectedTest) {
    return (
      <div className="space-y-6">
        {/* Scorecard Hero */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8">
          <div className="text-center max-w-lg mx-auto py-4">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center mx-auto mb-4 border border-amber-500/20">
              <Trophy className="w-8 h-8 fill-amber-400" />
            </div>
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/30 mb-2 inline-block">
              {t.testSubmitted}
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
              {selectedTest.title}
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Completed on {completedAttempt.date} · 75 Questions · Authentic JEE Scoring
            </p>
          </div>

          {/* Primary Metric Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 my-6">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center">
              <span className="text-xs text-slate-400 block mb-1">Your Total Score</span>
              <span className={`text-2xl font-black font-mono ${
                completedAttempt.score > 180 ? 'text-emerald-400' : completedAttempt.score > 100 ? 'text-amber-400' : 'text-rose-400'
              }`}>
                {completedAttempt.score}
              </span>
              <span className="text-[11px] text-slate-500 block">/ {completedAttempt.maxScore} Marks</span>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center">
              <span className="text-xs text-slate-400 block mb-1">{t.accuracy}</span>
              <span className="text-2xl font-black font-mono text-indigo-400">
                {completedAttempt.accuracy}%
              </span>
              <span className="text-[11px] text-slate-500 block">
                {completedAttempt.correctCount} / {completedAttempt.correctCount + completedAttempt.incorrectCount} attempted
              </span>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center">
              <span className="text-xs text-slate-400 block mb-1">{t.timeSpent}</span>
              <span className="text-2xl font-black font-mono text-cyan-400">
                {Math.floor(completedAttempt.totalTimeSpentSeconds / 60)}m {completedAttempt.totalTimeSpentSeconds % 60}s
              </span>
              <span className="text-[11px] text-slate-500 block">
                avg {Math.round(completedAttempt.totalTimeSpentSeconds / Math.max(1, completedAttempt.correctCount + completedAttempt.incorrectCount))}s / attempted
              </span>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center">
              <span className="text-xs text-slate-400 block mb-1">Estimated Percentile</span>
              <span className="text-2xl font-black font-mono text-purple-400">
                {completedAttempt.score >= 220 ? '99.4+ %ile' : completedAttempt.score >= 160 ? '98.2+ %ile' : completedAttempt.score >= 100 ? '93.5+ %ile' : '85.0+ %ile'}
              </span>
              <span className="text-[11px] text-slate-500 block">All India Projected</span>
            </div>
          </div>

          {/* Breakdown Pills */}
          <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-semibold pb-4">
            <span className="flex items-center gap-1.5 text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
              Correct (+4): {completedAttempt.correctCount} ({completedAttempt.correctCount * 4} Marks)
            </span>
            <span className="flex items-center gap-1.5 text-rose-400">
              <XCircle className="w-4 h-4" />
              Incorrect (-1): {completedAttempt.incorrectCount} (-{completedAttempt.incorrectCount} Marks)
            </span>
            <span className="flex items-center gap-1.5 text-slate-400">
              <AlertCircle className="w-4 h-4" />
              Unattempted: {completedAttempt.unattemptedCount} (0 Marks)
            </span>
          </div>

          {/* Action Row */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 border-t border-slate-800">
            <button
              onClick={() => {
                setCompletedAttempt(null);
                setSelectedTest(null);
              }}
              className="w-full sm:w-auto px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
            >
              {t.backToTests}
            </button>
            <button
              onClick={() => handleStartTest(selectedTest)}
              className="w-full sm:w-auto px-6 py-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Retake This 75-Q Test</span>
            </button>
          </div>
        </div>

        {/* Question-By-Question Detailed Solutions Review */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-indigo-400" />
                Comprehensive 75-Question Solutions & Derivations
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Review your response, official derivations, key formulas, and Kota AIR-ranker shortcut tricks in English & Hindi.
              </p>
            </div>
            
            {/* Bilingual Toggle inside Solutions */}
            <button
              onClick={() => setInTestLang((prev) => (prev === 'en' ? 'hi' : 'en'))}
              className="px-3 py-1.5 rounded-lg bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 text-xs font-bold flex items-center gap-1.5 transition-all"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{inTestLang === 'hi' ? 'Switch to English' : 'हिंदी में देखें'}</span>
            </button>
          </div>

          <div className="space-y-4">
            {selectedTest.questions.map((q, idx) => {
              const userAns = completedAttempt.answers[q.id];
              const isCorrect = userAns === q.correctOption;
              const isUnattempted = userAns === undefined || userAns === null;

              return (
                <div
                  key={q.id}
                  className={`p-4 rounded-xl border transition-all text-xs ${
                    isCorrect
                      ? 'bg-emerald-950/20 border-emerald-900/60'
                      : isUnattempted
                      ? 'bg-slate-950/60 border-slate-800/80'
                      : 'bg-rose-950/20 border-rose-900/60'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="font-bold font-mono text-slate-300">
                      Q{idx + 1}. [{q.exam} {q.year}] · {q.subtopic || q.topic}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                      isCorrect
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : isUnattempted
                        ? 'bg-slate-800 text-slate-400'
                        : 'bg-rose-500/20 text-rose-400'
                    }`}>
                      {isCorrect ? '+4 MARKS' : isUnattempted ? 'UNATTEMPTED (0)' : '-1 NEGATIVE'}
                    </span>
                  </div>

                  <p className="text-slate-200 font-medium mb-3 whitespace-pre-line leading-relaxed">
                    {inTestLang === 'hi' && q.questionHindi ? q.questionHindi : q.question}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-3">
                    {q.options.map((opt, optIdx) => {
                      const isOptionCorrect = optIdx === q.correctOption;
                      const isOptionSelected = optIdx === userAns;
                      return (
                        <div
                          key={optIdx}
                          className={`p-2 rounded-lg border text-[11px] flex items-center justify-between ${
                            isOptionCorrect
                              ? 'bg-emerald-950/50 border-emerald-500 text-emerald-200 font-bold'
                              : isOptionSelected
                              ? 'bg-rose-950/50 border-rose-500 text-rose-200'
                              : 'bg-slate-900 border-slate-800 text-slate-400'
                          }`}
                        >
                          <span>
                            {['A', 'B', 'C', 'D'][optIdx]}. {opt}
                          </span>
                          {isOptionCorrect && <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                        </div>
                      );
                    })}
                  </div>

                  {/* Step-by-Step Derivation */}
                  <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-slate-300 font-mono text-[11px] leading-relaxed mb-2 whitespace-pre-line">
                    <strong className="text-indigo-400 block mb-1">
                      {inTestLang === 'hi' ? 'आधिकारिक चरण-दर-चरण समाधान:' : 'Official Step-by-Step Solution:'}
                    </strong>
                    {inTestLang === 'hi' && q.solutionHindi ? q.solutionHindi : q.solution}
                  </div>

                  {/* Topper Trick / Fast Marks */}
                  {(q.topperTrick || q.topperTrickHindi) && (
                    <div className="bg-amber-950/20 border border-amber-500/30 rounded-lg p-2.5 text-[11px] text-amber-200 leading-relaxed mb-2">
                      <strong className="text-amber-400 block mb-0.5 flex items-center gap-1.5">
                        <Zap className="w-3.5 h-3.5" />
                        <span>{inTestLang === 'hi' ? 'टॉपर का शॉर्टकट ट्रिक (कम समय में हल):' : 'Kota AIR-Ranker Shortcut Trick:'}</span>
                      </strong>
                      <span>{inTestLang === 'hi' && q.topperTrickHindi ? q.topperTrickHindi : q.topperTrick}</span>
                    </div>
                  )}

                  <div className="flex justify-end pt-1">
                    <button
                      onClick={() => onAskAIMaster(q)}
                      className="px-3 py-1 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 rounded-md text-[11px] font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>{t.askGuruButton}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // --- RENDER 3: ACTIVE NTA CBT TEST SIMULATION SCREEN ---
  // =========================================================================
  if (!selectedTest || !currentQuestion) return null;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col min-h-[640px]">
      {/* NTA Exam Header Bar */}
      <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-400 font-bold">
              LIVE NTA CBT
            </span>
          </div>
          <div>
            <h2 className="text-xs sm:text-sm font-bold text-white truncate max-w-xs sm:max-w-md">
              {selectedTest.title}
            </h2>
            <span className="text-[11px] text-slate-400">
              75 Questions · 300 Marks · Single Correct Choice (+4 / -1)
            </span>
          </div>
        </div>

        {/* Center/Right Controls: Language Switcher, Timer, Submit */}
        <div className="flex items-center gap-3 ml-auto">
          {/* NTA Language Selector: View in English / हिन्दी */}
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-lg">
            <Globe className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-[11px] text-slate-400 font-medium hidden sm:inline">
              {t.viewInLanguage}:
            </span>
            <div className="flex items-center bg-slate-950 rounded-md p-0.5 border border-slate-800">
              <button
                onClick={() => setInTestLang('en')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all ${
                  inTestLang === 'en' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                English
              </button>
              <button
                onClick={() => setInTestLang('hi')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all ${
                  inTestLang === 'hi' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                हिन्दी
              </button>
            </div>
          </div>

          {/* Bilingual Toggle Button */}
          <button
            onClick={() => setIsBilingualView((v) => !v)}
            className={`px-2 py-1 rounded-lg text-[11px] font-bold transition-all hidden md:flex items-center gap-1 border ${
              isBilingualView
                ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500/40'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
            }`}
            title="Show both English and Hindi versions together"
          >
            <span>द्विभाषी</span>
          </button>

          {/* Countdown Timer */}
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-mono font-bold text-sm ${
            secondsRemaining <= 300
              ? 'bg-rose-950 text-rose-400 border border-rose-600 animate-pulse'
              : 'bg-slate-900 text-amber-400 border border-slate-800'
          }`}>
            <Clock className="w-4 h-4" />
            <span>{formatTimer(secondsRemaining)}</span>
          </div>

          {/* Submit Test Button */}
          <button
            onClick={() => setShowSubmitConfirm(true)}
            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-sm cursor-pointer transition-all"
          >
            {t.submitTest}
          </button>
        </div>
      </div>

      {/* Main CBT Split: Question Panel (Left) & Question Palette (Right) */}
      <div className="flex-1 flex flex-col lg:flex-row">
        {/* Left Question Area */}
        <div className="flex-1 p-5 sm:p-6 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-slate-800">
          <div>
            {/* Subject Selector Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-800/80">
              {selectedTest.isChapterTest ? (
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-3 py-1.5 rounded-md text-xs font-bold bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1.5">
                    <Target className="w-3.5 h-3.5" />
                    <span>{selectedTest.chapter || activeSubject}</span>
                    <span className="text-[10px] bg-indigo-500/30 px-1.5 py-0.5 rounded font-mono font-semibold">
                      75 Questions
                    </span>
                  </span>

                  {/* Section Navigation Buttons for 75-Question Marathon */}
                  <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
                    <span className="text-[10px] text-slate-500 px-1.5 font-mono uppercase font-semibold">
                      {inTestLang === 'hi' ? 'भाग:' : 'Sections:'}
                    </span>
                    <button
                      onClick={() => handleJumpToQuestion(0)}
                      className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-all ${
                        currentQuestionIndex < 25
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {inTestLang === 'hi' ? 'भाग 1 (Q1–25)' : 'Part 1 (Q1–25)'}
                    </button>
                    <button
                      onClick={() => handleJumpToQuestion(25)}
                      className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-all ${
                        currentQuestionIndex >= 25 && currentQuestionIndex < 50
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {inTestLang === 'hi' ? 'भाग 2 (Q26–50)' : 'Part 2 (Q26–50)'}
                    </button>
                    <button
                      onClick={() => handleJumpToQuestion(50)}
                      className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-all ${
                        currentQuestionIndex >= 50
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {inTestLang === 'hi' ? 'भाग 3 (Q51–75)' : 'Part 3 (Q51–75)'}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  {(['Physics', 'Chemistry', 'Mathematics'] as Subject[]).map((subj) => (
                    <button
                      key={subj}
                      onClick={() => {
                        setActiveSubject(subj);
                        const firstIdx = selectedTest.questions.findIndex((q) => q.subject === subj);
                        if (firstIdx !== -1) handleJumpToQuestion(firstIdx);
                      }}
                      className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                        currentQuestion.subject === subj
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-950 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {subj}
                    </button>
                  ))}
                </div>
              )}

              {/* Fast Marks / High Yield Badge for this question */}
              {selectedTest.weightageTag && (
                <span className="text-[11px] font-semibold text-amber-300 bg-amber-500/10 px-2 py-1 rounded border border-amber-500/20 hidden sm:inline-flex items-center gap-1">
                  <Flame className="w-3 h-3 text-amber-400" />
                  <span>{inTestLang === 'hi' && selectedTest.weightageTagHindi ? selectedTest.weightageTagHindi : selectedTest.weightageTag}</span>
                </span>
              )}
            </div>

            {/* Question Header */}
            <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
              <span className="font-bold text-slate-200">
                {inTestLang === 'hi' ? `प्रश्न सं. ${currentQuestionIndex + 1} / ${selectedTest.questions.length}` : `Question No. ${currentQuestionIndex + 1} of ${selectedTest.questions.length}`}
              </span>
              <div className="flex items-center gap-2 font-mono text-[11px]">
                <span className="text-emerald-400 font-semibold">+4.00</span>
                <span className="text-slate-600">|</span>
                <span className="text-rose-400 font-semibold">-1.00</span>
              </div>
            </div>

            {/* Question Text in Current or Bilingual Language */}
            <div className="space-y-3 mb-6">
              {/* Primary Question Language */}
              <div className="text-sm font-medium text-slate-100 whitespace-pre-line leading-relaxed">
                {inTestLang === 'hi' && currentQuestion.questionHindi
                  ? currentQuestion.questionHindi
                  : currentQuestion.question}
              </div>

              {/* Stacked Bilingual Representation if toggled */}
              {isBilingualView && currentQuestion.questionHindi && inTestLang === 'en' && (
                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300 whitespace-pre-line leading-relaxed font-sans">
                  <span className="text-[10px] font-bold text-indigo-400 block mb-1">हिन्दी अनुवाद:</span>
                  {currentQuestion.questionHindi}
                </div>
              )}
              {isBilingualView && inTestLang === 'hi' && (
                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300 whitespace-pre-line leading-relaxed font-sans">
                  <span className="text-[10px] font-bold text-indigo-400 block mb-1">English Text:</span>
                  {currentQuestion.question}
                </div>
              )}
            </div>

            {/* Options */}
            <div className="space-y-2.5">
              {currentQuestion.options.map((opt, optIdx) => {
                const isSelected = userAnswers[currentQuestion.id] === optIdx;
                const optText = (inTestLang === 'hi' && currentQuestion.optionsHindi && currentQuestion.optionsHindi[optIdx])
                  ? currentQuestion.optionsHindi[optIdx]
                  : opt;

                return (
                  <button
                    key={optIdx}
                    onClick={() => handleSelectOption(optIdx)}
                    className={`w-full flex items-start gap-3 p-3 rounded-lg border text-left text-xs transition-all ${
                      isSelected
                        ? 'bg-indigo-950/50 border-indigo-500 text-indigo-100 font-medium'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <span className={`w-5 h-5 rounded-full border flex items-center justify-center font-mono text-[11px] shrink-0 ${
                      isSelected
                        ? 'bg-indigo-600 border-indigo-500 text-white'
                        : 'border-slate-700 text-slate-400'
                    }`}>
                      {['A', 'B', 'C', 'D'][optIdx]}
                    </span>
                    <span className="flex-1 pt-0.5">{optText}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action Bar (NTA Standard) */}
          <div className="pt-6 mt-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button
                onClick={handleMarkForReview}
                className="px-3.5 py-2 rounded-lg bg-purple-950/60 hover:bg-purple-900/60 border border-purple-800 text-purple-300 text-xs font-semibold cursor-pointer transition-all"
              >
                {t.markForReview}
              </button>
              <button
                onClick={handleClearResponse}
                className="px-3.5 py-2 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 text-xs cursor-pointer transition-all"
              >
                {t.clearResponse}
              </button>
            </div>

            <button
              onClick={handleSaveAndNext}
              className="px-6 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md shadow-indigo-600/20 cursor-pointer transition-all"
            >
              {t.saveAndNext}
            </button>
          </div>
        </div>

        {/* Right Question Palette (75 Questions) */}
        <div className="w-full lg:w-80 bg-slate-950 p-4 flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
              {t.questionPalette} ({selectedTest.questions.length} Questions)
            </h4>

            {/* Status Counts Legend */}
            <div className="grid grid-cols-2 gap-2 text-[11px] mb-4 text-slate-400 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded bg-emerald-600 shrink-0" />
                <span>{t.answered} ({answeredCount})</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded bg-rose-600 shrink-0" />
                <span>{t.notAnswered} ({notAnsweredCount})</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded bg-purple-600 shrink-0" />
                <span>{t.markedReview} ({markedReviewCount})</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded bg-slate-800 shrink-0" />
                <span>{t.notVisited} ({notVisitedCount})</span>
              </div>
            </div>

            {/* 75 Question Palette Grid */}
            <div className="grid grid-cols-5 gap-1.5 max-h-[360px] overflow-y-auto pr-1">
              {selectedTest.questions.map((q, idx) => {
                const status = questionStatuses[q.id] || 'not_visited';
                const isCurrent = idx === currentQuestionIndex;

                let colorClasses = 'bg-slate-800 text-slate-400 border-slate-700';
                if (status === 'answered') {
                  colorClasses = 'bg-emerald-600 text-white border-emerald-500';
                } else if (status === 'not_answered') {
                  colorClasses = 'bg-rose-600 text-white border-rose-500';
                } else if (status === 'marked_for_review') {
                  colorClasses = 'bg-purple-600 text-white border-purple-500';
                } else if (status === 'answered_and_marked') {
                  colorClasses = 'bg-purple-600 text-white border-emerald-400 ring-2 ring-emerald-500';
                }

                return (
                  <button
                    key={q.id}
                    onClick={() => handleJumpToQuestion(idx)}
                    className={`h-8 rounded text-xs font-mono font-bold border transition-all flex items-center justify-center ${colorClasses} ${
                      isCurrent ? 'ring-2 ring-white scale-105 z-10' : ''
                    }`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick Submit Test in Palette */}
          <div className="pt-4 border-t border-slate-800 mt-4">
            <button
              onClick={() => setShowSubmitConfirm(true)}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg transition-all shadow-md cursor-pointer"
            >
              {t.submitTest}
            </button>
          </div>
        </div>
      </div>

      {/* Submit Confirmation Modal */}
      {showSubmitConfirm && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/20">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">
              {inTestLang === 'hi' ? 'क्या आप टेस्ट सबमिट करना चाहते हैं?' : 'Are you sure you want to submit?'}
            </h3>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-950 p-3 rounded-lg border border-slate-800 text-slate-300">
              <div>Answered: <strong className="text-emerald-400">{answeredCount}</strong></div>
              <div>Not Answered: <strong className="text-rose-400">{notAnsweredCount}</strong></div>
              <div>Marked Review: <strong className="text-purple-400">{markedReviewCount}</strong></div>
              <div>Not Visited: <strong className="text-slate-400">{notVisitedCount}</strong></div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowSubmitConfirm(false)}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-lg transition-all"
              >
                {inTestLang === 'hi' ? 'वापस टेस्ट पर जाएं' : 'Resume Test'}
              </button>
              <button
                onClick={handleFinalSubmit}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-md transition-all"
              >
                {inTestLang === 'hi' ? 'हाँ, सबमिट करें' : 'Confirm Submit'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
