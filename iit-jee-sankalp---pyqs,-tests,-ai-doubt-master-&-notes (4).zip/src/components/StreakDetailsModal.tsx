import React, { useState } from 'react';
import { 
  Flame, 
  Trophy, 
  Calendar, 
  Target, 
  CheckCircle2, 
  Coins, 
  Sparkles, 
  X, 
  ArrowRight,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { UserProfileStats } from '../types';
import { updateDailyGoal, getTodayKey } from '../services/storage';

interface StreakDetailsModalProps {
  stats: UserProfileStats;
  onClose: () => void;
  onStatsUpdated: () => void;
  onTriggerTestCelebration: () => void;
}

export const StreakDetailsModal: React.FC<StreakDetailsModalProps> = ({
  stats,
  onClose,
  onStatsUpdated,
  onTriggerTestCelebration,
}) => {
  const [selectedGoal, setSelectedGoal] = useState<number>(stats.dailyGoal || 5);
  const todayKey = getTodayKey();

  const handleSaveGoal = (goalVal: number) => {
    setSelectedGoal(goalVal);
    updateDailyGoal(goalVal);
    onStatsUpdated();
  };

  // Generate 7-day streak calendar preview
  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const today = new Date();
  
  const past7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(today.getDate() - (6 - i));
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const key = `${year}-${month}-${day}`;
    const dayName = daysOfWeek[d.getDay()];
    const isToday = key === todayKey;
    const questionsCount = (stats.activityHistory && stats.activityHistory[key]) || (isToday ? stats.todayQuestionsSolved : 5);
    const completed = isToday ? stats.todayGoalCompleted : (questionsCount >= (stats.dailyGoal || 5));

    return {
      dateKey: key,
      dayName,
      dayNum: d.getDate(),
      isToday,
      questionsCount,
      completed,
    };
  });

  const progressPercent = Math.min(100, Math.round((stats.todayQuestionsSolved / stats.dailyGoal) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Flame className="w-6 h-6 fill-amber-400" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Daily Streak & Study Target</h3>
              <p className="text-xs text-slate-400">Consistent effort creates IIT JEE Rankers</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Top Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {/* Current Streak */}
          <div className="p-3.5 rounded-2xl bg-amber-950/30 border border-amber-500/30 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-amber-400/90 uppercase tracking-wider">Current Streak</span>
            <div className="flex items-baseline gap-1 mt-2">
              <span className="text-3xl font-extrabold text-amber-400">{stats.streakDays}</span>
              <span className="text-xs text-amber-300 font-semibold">Days</span>
            </div>
            <span className="text-[10px] text-amber-300/70 mt-1">Keep burning!</span>
          </div>

          {/* Longest Streak */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Best Record</span>
            <div className="flex items-baseline gap-1 mt-2">
              <span className="text-3xl font-extrabold text-white">{stats.longestStreak || stats.streakDays}</span>
              <span className="text-xs text-slate-400 font-semibold">Days</span>
            </div>
            <span className="text-[10px] text-slate-500 mt-1">Personal milestone</span>
          </div>

          {/* Today's Goal Progress */}
          <div className="p-3.5 rounded-2xl bg-indigo-950/30 border border-indigo-500/30 flex flex-col justify-between col-span-2 sm:col-span-1">
            <span className="text-[11px] font-semibold text-indigo-400/90 uppercase tracking-wider">Today's Goal</span>
            <div className="flex items-baseline gap-1 mt-2">
              <span className="text-3xl font-extrabold text-indigo-300">
                {stats.todayQuestionsSolved}
              </span>
              <span className="text-xs text-slate-400 font-semibold">/ {stats.dailyGoal} Qs</span>
            </div>
            <span className="text-[10px] text-indigo-300/70 mt-1">
              {stats.todayGoalCompleted ? '✓ Completed Today!' : `${stats.dailyGoal - stats.todayQuestionsSolved} more needed`}
            </span>
          </div>
        </div>

        {/* Today's Goal Progress Bar */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Target className="w-4 h-4 text-indigo-400" />
              <span>Daily Target Progress</span>
            </span>
            <span className={`font-bold ${stats.todayGoalCompleted ? 'text-emerald-400' : 'text-amber-400'}`}>
              {stats.todayGoalCompleted ? 'Goal Reached 🎉' : `${progressPercent}% Complete`}
            </span>
          </div>

          <div className="w-full bg-slate-800/80 h-3 rounded-full overflow-hidden p-0.5">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                stats.todayGoalCompleted
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-400 shadow-sm shadow-emerald-500/50'
                  : 'bg-gradient-to-r from-amber-500 to-orange-500 shadow-sm shadow-amber-500/50'
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
            <span>Solve 1 question = +1 towards daily goal</span>
            <span>Reward: +25 Sankalp Coins</span>
          </div>
        </div>

        {/* 7-Day Visual Calendar */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between text-xs text-slate-300 font-semibold">
            <span className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-slate-400" />
              <span>Past 7 Days Activity</span>
            </span>
            <span className="text-[11px] text-slate-400 font-normal">Active days earn streak flames</span>
          </div>

          <div className="grid grid-cols-7 gap-2">
            {past7Days.map((day) => (
              <div
                key={day.dateKey}
                className={`p-2.5 rounded-xl border text-center flex flex-col items-center justify-between transition-all ${
                  day.isToday
                    ? 'border-indigo-500/80 bg-indigo-950/20 ring-1 ring-indigo-500/50'
                    : day.completed
                    ? 'border-amber-500/30 bg-amber-950/20'
                    : 'border-slate-800 bg-slate-950'
                }`}
              >
                <span className="text-[10px] text-slate-400 font-medium">{day.dayName}</span>
                <div className="my-1.5">
                  {day.completed ? (
                    <Flame className="w-5 h-5 fill-amber-400 text-amber-400 animate-pulse mx-auto" />
                  ) : day.isToday ? (
                    <div className="w-5 h-5 rounded-full border-2 border-dashed border-indigo-400 flex items-center justify-center text-[10px] text-indigo-300 font-bold mx-auto">
                      {day.questionsCount}
                    </div>
                  ) : (
                    <div className="w-5 h-5 rounded-full bg-slate-800/80 mx-auto" />
                  )}
                </div>
                <span className={`text-[10px] font-mono ${day.isToday ? 'font-bold text-white' : 'text-slate-500'}`}>
                  {day.dayNum}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Set Daily Goal Selector */}
        <div className="space-y-2.5 pt-2 border-t border-slate-800">
          <label className="text-xs font-semibold text-slate-300 block">
            Set Your Daily Study Goal:
          </label>
          <div className="grid grid-cols-3 gap-2.5">
            {[
              { val: 3, title: '3 Questions', desc: 'Light Revision' },
              { val: 5, title: '5 Questions', desc: 'Recommended' },
              { val: 10, title: '10 Questions', desc: 'Intense JEE Drill' },
            ].map((option) => {
              const isSelected = selectedGoal === option.val;
              return (
                <button
                  key={option.val}
                  onClick={() => handleSaveGoal(option.val)}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    isSelected
                      ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-sm'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs">{option.title}</span>
                    {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" />}
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-1">{option.desc}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Milestone Rewards & Preview Button */}
        <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={() => {
              onClose();
              onTriggerTestCelebration();
            }}
            className="w-full sm:w-auto px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Test Celebration Animation</span>
          </button>

          <button
            onClick={onClose}
            className="w-full sm:w-auto px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-indigo-600/20"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
