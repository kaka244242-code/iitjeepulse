import React, { useState, useMemo } from 'react';
import { 
  X, 
  BookOpen, 
  Sparkles, 
  ZoomIn, 
  ZoomOut, 
  Bookmark, 
  Printer, 
  ChevronRight, 
  ChevronLeft,
  Share2,
  CheckCircle2,
  HelpCircle,
  Award,
  Languages,
  Eye,
  EyeOff,
  FileText,
  Flame,
  ArrowRight,
  Download
} from 'lucide-react';
import { BookItem, PremiumNoteBundle, Question } from '../types';
import { chapterPracticeSheets } from '../data/chapterPracticeSheets';

interface PDFReaderModalProps {
  item: BookItem | PremiumNoteBundle;
  onClose: () => void;
  onAskAIMaster: (question: Question) => void;
}

export const PDFReaderModal: React.FC<PDFReaderModalProps> = ({
  item,
  onClose,
  onAskAIMaster,
}) => {
  const [fontSize, setFontSize] = useState<number>(14);
  const [activeChapterIndex, setActiveChapterIndex] = useState<number>(0);
  const [isBookmarked, setIsBookmarked] = useState<boolean>(false);
  const [selectedLang, setSelectedLang] = useState<'bilingual' | 'en' | 'hi'>('bilingual');
  const [expandedSolutions, setExpandedSolutions] = useState<Record<number, boolean>>({});
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});

  const title = item.title;
  const author = item.author;
  const chapters = 'chapters' in item ? item.chapters : ('previewPages' in item ? item.previewPages : ['Full Notes']);
  const content = 'sampleContent' in item ? item.sampleContent : ('fullContentSnippet' in item ? item.fullContentSnippet : 'Notes content');

  const currentChapterTitle = chapters[activeChapterIndex] || 'Chapter Overview';

  // Determine the 20 bilingual questions for this chapter
  const activeQuestions = useMemo(() => {
    // 1. If item itself has exemplarQuestions (like a chapter practice sheet)
    if ('exemplarQuestions' in item && item.exemplarQuestions && item.exemplarQuestions.length > 0) {
      return item.exemplarQuestions;
    }

    // 2. If item has chapterQuestions matching activeChapterIndex
    if ('chapterQuestions' in item && item.chapterQuestions && item.chapterQuestions[activeChapterIndex]) {
      return item.chapterQuestions[activeChapterIndex].questions;
    }

    // 3. Match from chapterPracticeSheets based on chapter title or subject
    const matchedSheet = chapterPracticeSheets.find((s) => {
      const matchSub = item.subject === 'All Subjects' || item.subject === 'Full PCM' || s.subject === item.subject;
      if (!matchSub) return false;
      const cleanTitle = currentChapterTitle.toLowerCase();
      const cleanSheet = s.chapter.toLowerCase();
      const firstWord = cleanTitle.replace(/[^a-zA-Z]/g, ' ').trim().split(' ')[0] || '';
      return firstWord.length > 2 && cleanSheet.includes(firstWord);
    });

    if (matchedSheet) {
      return matchedSheet.exemplarQuestions;
    }

    // 4. Default fallback to sheet of current subject or matching modulo index
    const subjectSheets = chapterPracticeSheets.filter(s => s.subject === item.subject);
    if (subjectSheets.length > 0) {
      return subjectSheets[activeChapterIndex % subjectSheets.length].exemplarQuestions;
    }

    return chapterPracticeSheets[activeChapterIndex % chapterPracticeSheets.length]?.exemplarQuestions || [];
  }, [item, activeChapterIndex, currentChapterTitle]);

  const toggleSolution = (qIdx: number) => {
    setExpandedSolutions(prev => ({
      ...prev,
      [qIdx]: !prev[qIdx]
    }));
  };

  const handleSelectOption = (qIdx: number, optIdx: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [qIdx]: optIdx
    }));
    // Auto-reveal solution on answer
    setExpandedSolutions(prev => ({
      ...prev,
      [qIdx]: true
    }));
  };

  const scrollToQuestion = (idx: number) => {
    const el = document.getElementById(`pyq-q-${idx}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex flex-col">
      {/* Reader Top Bar */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3 truncate">
          <BookOpen className="w-5 h-5 text-indigo-400 shrink-0" />
          <div className="truncate">
            <h3 className="text-sm font-bold text-white truncate flex items-center gap-2">
              <span>{title}</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-mono">
                PDF Sheet
              </span>
            </h3>
            <span className="text-[11px] text-slate-400 truncate block">
              {author} · {item.subject} · {activeQuestions.length > 0 ? `${activeQuestions.length} Solved Qs` : 'PDF'}
            </span>
          </div>
        </div>

        {/* Toolbar Controls */}
        <div className="flex items-center gap-2">
          {/* Language Switch */}
          <div className="flex items-center bg-slate-950 rounded-lg border border-slate-800 p-0.5 text-xs font-semibold">
            <button
              onClick={() => setSelectedLang('bilingual')}
              className={`px-2 py-1 rounded transition-colors ${
                selectedLang === 'bilingual' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="Both English & Hindi"
            >
              दोनों (Bilingual)
            </button>
            <button
              onClick={() => setSelectedLang('en')}
              className={`px-2 py-1 rounded transition-colors ${
                selectedLang === 'en' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="English Only"
            >
              EN
            </button>
            <button
              onClick={() => setSelectedLang('hi')}
              className={`px-2 py-1 rounded transition-colors ${
                selectedLang === 'hi' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="Hindi Only"
            >
              हिन्दी
            </button>
          </div>

          {/* Font Zoom */}
          <div className="hidden sm:flex items-center bg-slate-950 rounded-lg border border-slate-800 p-0.5">
            <button
              onClick={() => setFontSize((prev) => Math.max(prev - 2, 12))}
              className="p-1.5 text-slate-400 hover:text-white rounded"
              title="Decrease font size"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-mono px-2 text-slate-300">{fontSize}px</span>
            <button
              onClick={() => setFontSize((prev) => Math.min(prev + 2, 22))}
              className="p-1.5 text-slate-400 hover:text-white rounded"
              title="Increase font size"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Print / Save as PDF */}
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-sm shadow-emerald-600/20 cursor-pointer"
            title="Print or Save as PDF"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Save / Print PDF</span>
          </button>

          {/* Ask AI about this text */}
          <button
            onClick={() => {
              onClose();
              onAskAIMaster({
                id: `reader-${item.id}`,
                exam: 'JEE Advanced',
                year: 2026,
                subject: (item.subject === 'Full PCM' || item.subject === 'All Subjects' ? 'Physics' : item.subject) as any,
                topic: title,
                difficulty: 'Moderate',
                question: `I am studying "${title}" (${currentChapterTitle}). Can you explain the core concepts and give 2 tricky IIT JEE questions based on this?`,
                options: [],
                correctOption: 0,
                solution: '',
              });
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Ask AI Master</span>
          </button>

          {/* Close */}
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Reader Body Split: Sidebar Chapters & Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Table of Contents Sidebar */}
        <div className="w-64 bg-slate-900/70 border-r border-slate-800 p-4 hidden md:flex flex-col shrink-0">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Chapters / Sections
            </h4>
            <span className="text-[10px] text-indigo-400 font-mono font-bold">
              {chapters.length} Parts
            </span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
            {chapters.map((ch, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setActiveChapterIndex(idx);
                  setExpandedSolutions({});
                  setSelectedAnswers({});
                }}
                className={`w-full text-left p-2.5 rounded-xl text-xs transition-all cursor-pointer ${
                  activeChapterIndex === idx
                    ? 'bg-indigo-600 text-white font-bold shadow-md shadow-indigo-600/30'
                    : 'text-slate-400 hover:bg-slate-800/80 hover:text-slate-200 border border-transparent'
                }`}
              >
                <div className="line-clamp-2">{ch}</div>
                <div className="text-[10px] opacity-75 mt-1 font-mono">
                  {idx + 1}. Solved PYQ Sheet
                </div>
              </button>
            ))}
          </div>

          {/* Question Navigator in Sidebar */}
          {activeQuestions.length > 0 && (
            <div className="pt-4 border-t border-slate-800 mt-2">
              <span className="text-[11px] font-bold text-slate-400 block mb-2">
                Quick Jump (1 to {activeQuestions.length}):
              </span>
              <div className="grid grid-cols-5 gap-1">
                {activeQuestions.map((_, qIdx) => {
                  const isAnswered = selectedAnswers[qIdx] !== undefined;
                  const isCorrect = selectedAnswers[qIdx] === activeQuestions[qIdx].correctOption;

                  return (
                    <button
                      key={qIdx}
                      onClick={() => scrollToQuestion(qIdx)}
                      className={`h-7 rounded text-[11px] font-mono font-bold border transition-colors cursor-pointer ${
                        isAnswered
                          ? isCorrect
                            ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                            : 'bg-rose-500/20 border-rose-500 text-rose-300'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {qIdx + 1}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Main Document Content */}
        <div className="flex-1 bg-slate-950 p-4 sm:p-8 overflow-y-auto">
          <div className="max-w-4xl mx-auto space-y-6">
            
            {/* PDF Sheet Header Banner */}
            <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      {item.subject}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      2010 – 2026 Official PYQs
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      English + हिन्दी (Bilingual)
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                      +4 / -1 Marking
                    </span>
                  </div>

                  <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                    {currentChapterTitle}
                  </h1>
                  <p className="text-xs text-slate-400 mt-1">
                    {author} · Chapter {activeChapterIndex + 1} of {chapters.length} · {activeQuestions.length} Questions with Step-by-Step Solutions & Kota Shortcuts.
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => {
                      const all: Record<number, boolean> = {};
                      activeQuestions.forEach((_, idx) => { all[idx] = true; });
                      setExpandedSolutions(all);
                    }}
                    className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 rounded-lg text-xs font-semibold cursor-pointer"
                  >
                    Expand All Solutions
                  </button>
                  <button
                    onClick={() => window.print()}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download / Print</span>
                  </button>
                </div>
              </div>

              {/* Mobile Quick Jump Palette */}
              {activeQuestions.length > 0 && (
                <div className="md:hidden mt-4 pt-4 border-t border-slate-800">
                  <span className="text-[11px] font-bold text-slate-400 block mb-2">
                    Quick Jump to Question:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {activeQuestions.map((_, qIdx) => (
                      <button
                        key={qIdx}
                        onClick={() => scrollToQuestion(qIdx)}
                        className="w-7 h-7 rounded text-[11px] font-mono font-bold bg-slate-950 border border-slate-800 text-slate-400 hover:text-white"
                      >
                        {qIdx + 1}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Questions List (PDF Form) */}
            {activeQuestions.length > 0 ? (
              <div className="space-y-6">
                {activeQuestions.map((q, qIdx) => {
                  const isSolutionExpanded = !!expandedSolutions[qIdx];
                  const userSelectedOpt = selectedAnswers[qIdx];
                  const isCorrect = userSelectedOpt === q.correctOption;

                  return (
                    <div
                      key={qIdx}
                      id={`pyq-q-${qIdx}`}
                      className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 transition-all hover:border-slate-700 shadow-sm"
                    >
                      {/* Question Header */}
                      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-800/80">
                        <div className="flex items-center gap-2">
                          <span className="w-7 h-7 rounded-lg bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 flex items-center justify-center font-mono font-black text-xs">
                            {qIdx + 1}
                          </span>
                          <span className="text-xs font-bold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                            {q.exam} {q.year}
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono">
                            Marks: +4 / -1
                          </span>
                        </div>

                        <button
                          onClick={() => {
                            onClose();
                            onAskAIMaster({
                              id: `pyq-q-${qIdx}`,
                              exam: q.exam as any,
                              year: q.year,
                              subject: item.subject === 'All Subjects' || item.subject === 'Full PCM' ? 'Physics' : item.subject as any,
                              topic: currentChapterTitle,
                              difficulty: 'Moderate',
                              question: `${q.questionEn}\n\n[Hindi]: ${q.questionHi}`,
                              options: q.optionsEn,
                              correctOption: q.correctOption,
                              solution: `${q.solutionEn}\n\n${q.solutionHi}`,
                            });
                          }}
                          className="flex items-center gap-1 text-[11px] text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Ask AI</span>
                        </button>
                      </div>

                      {/* Question Body */}
                      <div style={{ fontSize: `${fontSize}px` }} className="space-y-3 leading-relaxed">
                        {/* English Question */}
                        {(selectedLang === 'bilingual' || selectedLang === 'en') && (
                          <div className="text-slate-100 font-medium">
                            <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-mono bg-blue-500/20 text-blue-300 mr-2 uppercase font-bold">
                              EN
                            </span>
                            {q.questionEn}
                          </div>
                        )}

                        {/* Hindi Question */}
                        {(selectedLang === 'bilingual' || selectedLang === 'hi') && (
                          <div className="text-slate-200 font-normal">
                            <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 mr-2 uppercase font-bold">
                              हिन्दी
                            </span>
                            {q.questionHi}
                          </div>
                        )}
                      </div>

                      {/* Options Grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mt-4">
                        {q.optionsEn.map((optEn, optIdx) => {
                          const optLabel = ['(A)', '(B)', '(C)', '(D)'][optIdx];
                          const optHi = q.optionsHi[optIdx] || optEn;
                          const isThisOptionSelected = userSelectedOpt === optIdx;
                          const isThisCorrect = q.correctOption === optIdx;

                          let btnStyle = 'bg-slate-950/70 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-950';

                          if (userSelectedOpt !== undefined) {
                            if (isThisCorrect) {
                              btnStyle = 'bg-emerald-500/20 border-emerald-500 text-emerald-200 font-bold';
                            } else if (isThisOptionSelected) {
                              btnStyle = 'bg-rose-500/20 border-rose-500 text-rose-200 font-bold';
                            }
                          }

                          return (
                            <button
                              key={optIdx}
                              onClick={() => handleSelectOption(qIdx, optIdx)}
                              className={`p-3 rounded-xl border text-left transition-all flex items-start gap-2.5 cursor-pointer ${btnStyle}`}
                            >
                              <span className="font-mono font-bold text-xs text-indigo-400 shrink-0">
                                {optLabel}
                              </span>
                              <div className="text-xs space-y-1">
                                {(selectedLang === 'bilingual' || selectedLang === 'en') && (
                                  <div>{optEn}</div>
                                )}
                                {(selectedLang === 'bilingual' || selectedLang === 'hi') && (
                                  <div className="text-slate-400 text-[11px]">{optHi}</div>
                                )}
                              </div>
                            </button>
                          );
                        })}
                      </div>

                      {/* Solution Toggle & Derivation */}
                      <div className="mt-4 pt-3 border-t border-slate-800/80">
                        <button
                          onClick={() => toggleSolution(qIdx)}
                          className="flex items-center gap-1.5 text-xs font-bold text-indigo-400 hover:text-indigo-300 cursor-pointer"
                        >
                          {isSolutionExpanded ? (
                            <>
                              <EyeOff className="w-3.5 h-3.5" />
                              <span>हल छिपाएं (Hide Solution)</span>
                            </>
                          ) : (
                            <>
                              <Eye className="w-3.5 h-3.5" />
                              <span>विस्तृत हल व शॉर्टकट ट्रिक देखें (View Solution & Trick)</span>
                            </>
                          )}
                        </button>

                        {isSolutionExpanded && (
                          <div className="mt-3 bg-slate-950/90 rounded-xl p-4 border border-slate-800 space-y-3">
                            {/* Correct Answer Badge */}
                            <div className="flex items-center gap-2">
                              <span className="px-2.5 py-1 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold font-mono text-xs flex items-center gap-1">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>सही विकल्प: {['(A)', '(B)', '(C)', '(D)'][q.correctOption]}</span>
                              </span>
                            </div>

                            {/* Derivation English */}
                            {(selectedLang === 'bilingual' || selectedLang === 'en') && (
                              <div className="text-xs text-slate-300 whitespace-pre-line leading-relaxed">
                                <span className="font-bold text-indigo-300 block mb-1">
                                  [Step-by-Step Derivation]:
                                </span>
                                {q.solutionEn}
                              </div>
                            )}

                            {/* Derivation Hindi */}
                            {(selectedLang === 'bilingual' || selectedLang === 'hi') && (
                              <div className="text-xs text-slate-300 whitespace-pre-line leading-relaxed">
                                <span className="font-bold text-emerald-300 block mb-1">
                                  [विस्तृत चरणबद्ध हल]:
                                </span>
                                {q.solutionHi}
                              </div>
                            )}

                            {/* Kota Ranker Trick */}
                            {(q.topperTrickEn || q.topperTrickHi) && (
                              <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-3 text-xs text-amber-200">
                                <span className="font-bold flex items-center gap-1 mb-1">
                                  <Flame className="w-3.5 h-3.5 text-amber-400" />
                                  <span>Kota AIR Shortcut & Speed Hack:</span>
                                </span>
                                <div>{q.topperTrickEn}</div>
                                {q.topperTrickHi && (
                                  <div className="text-amber-300/80 text-[11px] mt-1">{q.topperTrickHi}</div>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              /* Static Content Fallback */
              <div
                style={{ fontSize: `${fontSize}px` }}
                className="font-mono text-slate-200 whitespace-pre-line leading-relaxed bg-slate-900/40 p-6 rounded-2xl border border-slate-800/80"
              >
                {content}
              </div>
            )}

            {/* Bottom Navigator */}
            <div className="flex items-center justify-between pt-6 border-t border-slate-800 text-xs text-slate-400">
              <button
                disabled={activeChapterIndex === 0}
                onClick={() => {
                  setActiveChapterIndex((p) => p - 1);
                  setExpandedSolutions({});
                  setSelectedAnswers({});
                }}
                className="flex items-center gap-1 hover:text-white disabled:opacity-30 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>पिछला अध्याय (Previous)</span>
              </button>
              <span>अध्याय {activeChapterIndex + 1} of {chapters.length}</span>
              <button
                disabled={activeChapterIndex + 1 >= chapters.length}
                onClick={() => {
                  setActiveChapterIndex((p) => p + 1);
                  setExpandedSolutions({});
                  setSelectedAnswers({});
                }}
                className="flex items-center gap-1 hover:text-white disabled:opacity-30 cursor-pointer"
              >
                <span>अगला अध्याय (Next)</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

