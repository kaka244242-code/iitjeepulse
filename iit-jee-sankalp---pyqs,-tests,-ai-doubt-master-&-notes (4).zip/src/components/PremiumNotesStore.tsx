import React, { useState } from 'react';
import { 
  Sparkles, 
  Coins, 
  Check, 
  Lock, 
  BookOpen, 
  Download, 
  Star, 
  Eye, 
  ShieldCheck, 
  Flame, 
  FileText,
  X,
  Target,
  Zap,
  Globe,
  Upload,
  AlertTriangle,
  ChevronRight,
  Printer,
  CheckCircle2,
  Bookmark,
  Clock,
  Layers
} from 'lucide-react';
import { PremiumNoteBundle, UserProfileStats, AppLanguage, Subject } from '../types';
import { premiumNoteBundles } from '../data/mockNotes';
import { 
  allChaptersShortNotes, 
  allChaptersPYQSheets, 
  ChapterShortNote, 
  PYQSheetItem 
} from '../data/allChaptersNotesAndSheets';
import { chapterPracticeSheets } from '../data/chapterPracticeSheets';
import { unlockNoteBundle } from '../services/storage';
import { getTranslation } from '../utils/translations';

interface PremiumNotesStoreProps {
  stats: UserProfileStats;
  onStatsUpdated: () => void;
  onOpenNotesReader: (bundle: PremiumNoteBundle) => void;
  language: AppLanguage;
  onLaunchChapterTest?: (chapterTitle: string) => void;
}

export const PremiumNotesStore: React.FC<PremiumNotesStoreProps> = ({
  stats,
  onStatsUpdated,
  onOpenNotesReader,
  language,
  onLaunchChapterTest,
}) => {
  const t = getTranslation(language);

  // Active Main Tab
  const [activeSection, setActiveSection] = useState<'short-notes' | 'pyq-sheets' | 'master-bundles' | 'upload'>('short-notes');
  const [subjectFilter, setSubjectFilter] = useState<'All' | 'Physics' | 'Chemistry' | 'Mathematics'>('All');
  
  // Independent language toggle for notes
  const [notesLang, setNotesLang] = useState<AppLanguage>(language);

  // Selected Short Note or PYQ Sheet for reading
  const [activeShortNote, setActiveShortNote] = useState<ChapterShortNote | null>(null);
  const [activePYQSheet, setActivePYQSheet] = useState<PYQSheetItem | null>(null);

  // Custom User Uploaded Notes
  const [customNotes, setCustomNotes] = useState<{ id: string; title: string; chapter: string; subject: Subject; date: string; content: string }[]>(() => {
    try {
      const saved = localStorage.getItem('sankalp_custom_notes');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadChapter, setUploadChapter] = useState('');
  const [uploadSubject, setUploadSubject] = useState<Subject>('Physics');
  const [uploadText, setUploadText] = useState('');
  const [uploadSuccess, setUploadSuccess] = useState(false);

  // Master Bundles Modal & Unlock state
  const [selectedBundle, setSelectedBundle] = useState<PremiumNoteBundle | null>(null);
  const [unlockMessage, setUnlockMessage] = useState<string | null>(null);

  const handleUnlock = (bundle: PremiumNoteBundle) => {
    if (stats.unlockedNoteIds.includes(bundle.id)) {
      onOpenNotesReader(bundle);
      return;
    }

    if (stats.coins < bundle.priceCoins) {
      setUnlockMessage(`You need ${bundle.priceCoins} Sankalp Coins! Earn more by solving PYQs (+5) or taking Mock Tests (+50).`);
      setTimeout(() => setUnlockMessage(null), 3500);
      return;
    }

    const success = unlockNoteBundle(bundle.id, bundle.priceCoins);
    if (success) {
      onStatsUpdated();
      setUnlockMessage(`🎉 "${bundle.title}" unlocked successfully! Opening notes...`);
      setTimeout(() => {
        setUnlockMessage(null);
        onOpenNotesReader(bundle);
      }, 1000);
    }
  };

  const handleSaveCustomNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadTitle.trim() || !uploadChapter.trim()) return;

    const newNote = {
      id: `custom-note-${Date.now()}`,
      title: uploadTitle.trim(),
      chapter: uploadChapter.trim(),
      subject: uploadSubject,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      content: uploadText.trim() || `Chapter formula notes and high-yield problem sheet for ${uploadChapter}.`,
    };

    const updated = [newNote, ...customNotes];
    setCustomNotes(updated);
    try {
      localStorage.setItem('sankalp_custom_notes', JSON.stringify(updated));
    } catch {}

    setUploadTitle('');
    setUploadChapter('');
    setUploadText('');
    setUploadSuccess(true);
    setTimeout(() => setUploadSuccess(false), 3000);
  };

  // Filtered data
  const filteredShortNotes = allChaptersShortNotes.filter(
    (n) => subjectFilter === 'All' || n.subject === subjectFilter
  );

  const combinedSheets = [...chapterPracticeSheets, ...allChaptersPYQSheets];
  const filteredPYQSheets = combinedSheets.filter(
    (s) => subjectFilter === 'All' || s.subject === subjectFilter
  );

  const filteredBundles = premiumNoteBundles.filter(
    (b) => subjectFilter === 'All' || b.subject === subjectFilter
  );

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/20 rounded-2xl p-6 sm:p-7 relative overflow-hidden shadow-xl">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-amber-400 mb-2">
              <Sparkles className="w-4 h-4 fill-amber-400" />
              <span>ALL CHAPTERS REVISION VAULT (2010–2026)</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              {notesLang === 'hi' ? 'सभी अध्यायों के शॉर्ट नोट्स व पीवाईक्यू शीट्स' : 'All Chapters Short Notes & PYQ Sheets'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              {notesLang === 'hi'
                ? 'भौतिकी, रसायन और गणित के सभी चैप्टर्स के अति-संक्षिप्त सूत्र, कोटा टॉपर्स शॉर्टकट ट्रिक्स, सामान्य गलतियां और 2010 से 2026 की हल की गई पीवाईक्यू शीट्स।'
                : 'Ultra-condensed formula sheets, Kota AIR-ranker shortcut tricks, common mistake traps, and 2010–2026 solved chapter sheets for Physics, Chemistry & Mathematics.'}
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {/* Bilingual Switcher */}
            <div className="flex items-center gap-1.5 bg-slate-950/80 p-1.5 rounded-xl border border-slate-800">
              <Globe className="w-3.5 h-3.5 text-indigo-400 ml-1.5" />
              <button
                onClick={() => setNotesLang('en')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  notesLang === 'en' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                English
              </button>
              <button
                onClick={() => setNotesLang('hi')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  notesLang === 'hi' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                हिन्दी
              </button>
            </div>

            {/* Coins Balance Indicator */}
            <div className="flex items-center gap-2 bg-slate-950/80 border border-amber-500/30 px-3.5 py-2 rounded-xl text-xs">
              <Coins className="w-4 h-4 text-amber-400" />
              <span className="font-bold text-amber-300">{stats.coins}</span>
              <span className="text-slate-400">Coins</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Section Navigation Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pb-2 border-b border-slate-800">
        {/* Section Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto p-1 bg-slate-950 rounded-xl border border-slate-800 scrollbar-none">
          <button
            onClick={() => setActiveSection('short-notes')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
              activeSection === 'short-notes'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{notesLang === 'hi' ? 'शॉर्ट नोट्स (सभी अध्याय)' : 'Chapter Short Notes'}</span>
          </button>

          <button
            onClick={() => setActiveSection('pyq-sheets')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
              activeSection === 'pyq-sheets'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>{notesLang === 'hi' ? 'चैप्टर प्रैक्टिस शीट्स (20 Qs प्रति अध्याय)' : 'Chapter Practice Sheets (20 Qs/Chap)'}</span>
          </button>

          <button
            onClick={() => setActiveSection('master-bundles')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
              activeSection === 'master-bundles'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{notesLang === 'hi' ? 'कोटा टॉपर्स हैंडबुक्स' : 'Kota Master Handbooks'}</span>
          </button>

          <button
            onClick={() => setActiveSection('upload')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
              activeSection === 'upload'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>{notesLang === 'hi' ? 'अपनी शीट अपलोड करें' : 'Upload Custom Notes'}</span>
          </button>
        </div>

        {/* Subject Filter Pills */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 shrink-0">
          {(['All', 'Physics', 'Chemistry', 'Mathematics'] as const).map((sub) => (
            <button
              key={sub}
              onClick={() => setSubjectFilter(sub)}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                subjectFilter === sub
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {sub}
            </button>
          ))}
        </div>
      </div>

      {unlockMessage && (
        <div className="p-3 bg-indigo-950/80 border border-indigo-500/50 rounded-xl text-xs text-indigo-200 text-center animate-in fade-in">
          {unlockMessage}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. SHORT NOTES GRID (ALL CHAPTERS) */}
      {/* ========================================================================= */}
      {activeSection === 'short-notes' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>
              Showing <strong className="text-white">{filteredShortNotes.length}</strong> Chapter Short Notes
            </span>
            <span className="text-[11px] text-indigo-400 font-semibold flex items-center gap-1">
              <Zap className="w-3.5 h-3.5" />
              <span>Available in English & हिन्दी</span>
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredShortNotes.map((note) => (
              <div
                key={note.id}
                className="bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-xl p-5 flex flex-col justify-between transition-all group shadow-sm hover:shadow-md"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2.5">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                      note.subject === 'Physics' ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20' :
                      note.subject === 'Chemistry' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                      'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                    }`}>
                      {note.subject}
                    </span>
                    <span className="flex items-center gap-1 text-[11px] text-slate-400">
                      <Clock className="w-3 h-3" />
                      <span>{note.readTimeMinutes} mins read</span>
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors mb-2 leading-snug">
                    {notesLang === 'hi' ? note.chapterHindi : note.chapter}
                  </h3>

                  <div className="inline-block px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[11px] font-semibold mb-3">
                    {notesLang === 'hi' ? note.weightageHindi : note.weightage}
                  </div>

                  <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed mb-4">
                    {notesLang === 'hi' ? note.summaryHindi : note.summary}
                  </p>

                  <div className="bg-slate-900/80 rounded-lg p-2.5 border border-slate-800/80 text-[11px] text-slate-300 space-y-1 mb-4">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Key Formulas:</span>
                      <strong className="text-white font-mono">{note.keyFormulas.length} Core Formulas</strong>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Topper Tricks:</span>
                      <strong className="text-amber-400 font-mono">{note.highYieldTricks.length} Shortcuts</strong>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setActiveShortNote(note)}
                  className="w-full py-2.5 bg-slate-900 hover:bg-indigo-600 text-slate-200 hover:text-white border border-slate-800 hover:border-indigo-500 font-bold text-xs rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>{notesLang === 'hi' ? 'शॉर्ट नोट पढ़ें' : 'Read Short Note'}</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. PYQ SHEETS GRID (ALL CHAPTERS 2010–2026) */}
      {/* ========================================================================= */}
      {activeSection === 'pyq-sheets' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>
              Showing <strong className="text-white">{filteredPYQSheets.length}</strong> Chapter-Wise PYQ Sheets (2010–2026)
            </span>
            <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>75 Questions / 300 Marks Scheme</span>
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredPYQSheets.map((sheet) => (
              <div
                key={sheet.id}
                className="bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-xl p-5 flex flex-col justify-between transition-all group shadow-sm"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2.5">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                      sheet.subject === 'Physics' ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20' :
                      sheet.subject === 'Chemistry' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                      'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                    }`}>
                      {sheet.subject}
                    </span>
                    <span className="font-mono text-[11px] text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                      {sheet.yearCoverage}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors mb-2 leading-snug">
                    {notesLang === 'hi' ? sheet.chapterHindi : sheet.chapter}
                  </h3>

                  <div className="flex flex-wrap gap-1 mb-3">
                    {(notesLang === 'hi' ? sheet.topSubtopicsHindi : sheet.topSubtopics).map((sub, sIdx) => (
                      <span key={sIdx} className="text-[10px] bg-slate-900 text-slate-300 px-2 py-0.5 rounded border border-slate-800">
                        {sub}
                      </span>
                    ))}
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-300 border-t border-slate-800/80 pt-3 mb-4 font-mono">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Sheet Questions:</span>
                      <span className="text-emerald-400 font-bold">{sheet.questionsCount} Questions</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Total Marks:</span>
                      <span className="text-white font-bold">{sheet.totalMarks} Marks (+4 / -1)</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <button
                    onClick={() => setActivePYQSheet(sheet)}
                    className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-lg transition-all flex items-center justify-center gap-1.5 shadow-sm shadow-indigo-600/30 cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>{notesLang === 'hi' ? 'हल सहित शीट देखें' : 'View Solved PYQ Sheet'}</span>
                  </button>

                  {onLaunchChapterTest && (
                    <button
                      onClick={() => onLaunchChapterTest(sheet.chapter)}
                      className="w-full py-1.5 bg-slate-900 hover:bg-slate-800 text-indigo-300 hover:text-white border border-slate-800 text-[11px] font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Target className="w-3 h-3 text-indigo-400" />
                      <span>{notesLang === 'hi' ? '75-Q टेस्ट शुरू करें' : 'Launch 75-Q Test'}</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. KOTA TOPPERS MASTER HANDBOOKS */}
      {/* ========================================================================= */}
      {activeSection === 'master-bundles' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {filteredBundles.map((bundle) => {
              const isUnlocked = stats.unlockedNoteIds.includes(bundle.id);
              return (
                <div
                  key={bundle.id}
                  className="bg-slate-950 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between shadow-lg relative group overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none" />

                  <div>
                    <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
                      <span className="px-2.5 py-0.5 rounded-full font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                        {bundle.subject}
                      </span>
                      <span className="flex items-center gap-1 text-amber-400 font-bold">
                        <Star className="w-3.5 h-3.5 fill-amber-400" />
                        <span>{bundle.rating}</span>
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors mb-1.5 leading-snug">
                      {bundle.title}
                    </h3>
                    <p className="text-xs text-slate-400 mb-3 font-medium">
                      By {bundle.author} ({bundle.authorRank})
                    </p>
                    <p className="text-xs text-slate-300 leading-relaxed mb-4 line-clamp-3">
                      {bundle.subtitle}
                    </p>

                    <div className="space-y-1.5 text-xs text-slate-400 mb-4 bg-slate-900/60 p-3 rounded-xl border border-slate-800/80">
                      <div className="flex justify-between">
                        <span>Total Pages:</span>
                        <strong className="text-white font-mono">{bundle.pages} Pages</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>Format:</span>
                        <strong className="text-white">Handwritten & Color Coded</strong>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      onClick={() => handleUnlock(bundle)}
                      className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                        isUnlocked
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md'
                          : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30'
                      }`}
                    >
                      {isUnlocked ? (
                        <>
                          <BookOpen className="w-4 h-4" />
                          <span>Open Unlocked Handbook</span>
                        </>
                      ) : (
                        <>
                          <Lock className="w-4 h-4" />
                          <span>Unlock ({bundle.priceCoins} Coins or Free)</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. UPLOAD CUSTOM NOTES / SHEETS SECTION */}
      {/* ========================================================================= */}
      {activeSection === 'upload' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Upload Form */}
            <div className="lg:col-span-6 bg-slate-950 border border-slate-800 rounded-2xl p-6 shadow-xl">
              <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2">
                <Upload className="w-4 h-4 text-indigo-400" />
                <span>{notesLang === 'hi' ? 'अपनी कोचिंग शीट या नोट्स अपलोड करें' : 'Upload Coaching Sheet or Notes'}</span>
              </h3>
              <p className="text-xs text-slate-400 mb-5 leading-relaxed">
                {notesLang === 'hi' 
                  ? 'अपने पर्सनल शॉर्ट नोट्स, फॉर्मूला शीट्स या कोचिंग प्रश्नों को ऐप में सेव करें और कभी भी रिवाइज करें।' 
                  : 'Save your personal short notes, formula sheets, or coaching problems in the app for instant revision.'}
              </p>

              {uploadSuccess && (
                <div className="mb-4 p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Note uploaded and saved successfully!</span>
                </div>
              )}

              <form onSubmit={handleSaveCustomNote} className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    Note / Sheet Title:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Allen Modern Physics Formula Chart"
                    value={uploadTitle}
                    onChange={(e) => setUploadTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-300 font-bold mb-1">
                      Subject:
                    </label>
                    <select
                      value={uploadSubject}
                      onChange={(e) => setUploadSubject(e.target.value as Subject)}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                    >
                      <option value="Physics">Physics</option>
                      <option value="Chemistry">Chemistry</option>
                      <option value="Mathematics">Mathematics</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-300 font-bold mb-1">
                      Chapter:
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Rotational Motion"
                      value={uploadChapter}
                      onChange={(e) => setUploadChapter(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    Formulas, Summary or Key Problems Text:
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Type or paste formula notes, shortcuts, key reactions, or problem statements..."
                    value={uploadText}
                    onChange={(e) => setUploadText(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
                >
                  Save to My Notes Vault
                </button>
              </form>
            </div>

            {/* Right Uploaded Notes List */}
            <div className="lg:col-span-6 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center justify-between">
                <span>My Uploaded Sheets ({customNotes.length})</span>
                <span className="text-[11px] text-slate-500 font-mono">Saved Locally</span>
              </h3>

              {customNotes.length === 0 ? (
                <div className="p-8 text-center bg-slate-950 border border-slate-800 rounded-2xl text-xs text-slate-400">
                  <FileText className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                  <p className="font-bold text-slate-300">No custom sheets uploaded yet.</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">Use the form on the left to add your personal formulas or coaching notes.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {customNotes.map((cn) => (
                    <div
                      key={cn.id}
                      className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white text-sm">{cn.title}</span>
                        <span className="text-[10px] text-slate-500 font-mono">{cn.date}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 font-semibold text-[10px]">
                          {cn.subject} · {cn.chapter}
                        </span>
                      </div>
                      <p className="text-slate-300 font-mono text-[11px] bg-slate-900 p-2.5 rounded-lg border border-slate-800/80 whitespace-pre-line leading-relaxed">
                        {cn.content}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: COMPLETE CHAPTER SHORT NOTE VIEWER */}
      {/* ========================================================================= */}
      {activeShortNote && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                    {activeShortNote.subject} SHORT NOTE
                  </span>
                  <span className="text-[10px] text-amber-300 font-bold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                    {notesLang === 'hi' ? activeShortNote.weightageHindi : activeShortNote.weightage}
                  </span>
                </div>
                <h2 className="text-base sm:text-lg font-bold text-white">
                  {notesLang === 'hi' ? activeShortNote.chapterHindi : activeShortNote.chapter}
                </h2>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setNotesLang((l) => (l === 'en' ? 'hi' : 'en'))}
                  className="px-2.5 py-1 bg-slate-900 border border-slate-700 text-xs font-bold text-slate-300 rounded-lg hover:text-white"
                >
                  {notesLang === 'hi' ? 'English' : 'हिन्दी'}
                </button>
                <button
                  onClick={() => setActiveShortNote(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Note Content */}
            <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5 text-xs">
              {/* Summary */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <strong className="text-slate-200 block mb-1 text-sm">
                  {notesLang === 'hi' ? 'अध्याय सारांश (Chapter Summary):' : 'Chapter Summary:'}
                </strong>
                <p className="text-slate-300 leading-relaxed">
                  {notesLang === 'hi' ? activeShortNote.summaryHindi : activeShortNote.summary}
                </p>
              </div>

              {/* Key Formulas */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span>{notesLang === 'hi' ? 'मुख्य सूत्र एवं शर्तें (Key Formulas & Conditions):' : 'Key Formulas & Principles:'}</span>
                </h4>
                <div className="space-y-2.5">
                  {activeShortNote.keyFormulas.map((kf, kfIdx) => (
                    <div key={kfIdx} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-indigo-300">
                          {notesLang === 'hi' ? kf.nameHindi : kf.name}
                        </span>
                      </div>
                      <div className="p-2 bg-slate-900 rounded-lg font-mono text-amber-300 text-xs font-bold border border-slate-800">
                        {kf.formula}
                      </div>
                      <p className="text-slate-400 text-[11px] leading-relaxed">
                        📌 {notesLang === 'hi' ? kf.notesHindi : kf.notes}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Topper Shortcut Tricks */}
              <div className="bg-amber-950/20 border border-amber-500/30 rounded-xl p-4 space-y-2">
                <strong className="text-amber-400 font-bold flex items-center gap-1.5 text-xs">
                  <Sparkles className="w-4 h-4" />
                  <span>{notesLang === 'hi' ? 'कोटा AIR-रैंकर शॉर्टकट ट्रिक्स:' : 'Kota AIR-Ranker Shortcuts:'}</span>
                </strong>
                <ul className="space-y-1.5 text-[11px] text-amber-200">
                  {(notesLang === 'hi' ? activeShortNote.highYieldTricksHindi : activeShortNote.highYieldTricks).map((tr, trIdx) => (
                    <li key={trIdx} className="flex items-start gap-2">
                      <span className="text-amber-400 font-bold">•</span>
                      <span>{tr}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Common Traps */}
              <div className="bg-rose-950/20 border border-rose-500/30 rounded-xl p-4 space-y-2">
                <strong className="text-rose-400 font-bold flex items-center gap-1.5 text-xs">
                  <AlertTriangle className="w-4 h-4" />
                  <span>{notesLang === 'hi' ? 'नेगेटिव मार्किंग से बचाव (Common Traps):' : 'Common Mistake Traps:'}</span>
                </strong>
                <ul className="space-y-1.5 text-[11px] text-rose-200">
                  {(notesLang === 'hi' ? activeShortNote.commonTrapsHindi : activeShortNote.commonTraps).map((trap, tpIdx) => (
                    <li key={tpIdx} className="flex items-start gap-2">
                      <span className="text-rose-400 font-bold">•</span>
                      <span>{trap}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Footer */}
            <div className="bg-slate-950 px-5 py-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                IIT JEE 2010–2026 High-Yield Series
              </span>
              <button
                onClick={() => setActiveShortNote(null)}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-lg"
              >
                Close Note
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: SOLVED PYQ SHEET VIEWER */}
      {/* ========================================================================= */}
      {activePYQSheet && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    {activePYQSheet.questionsCount}-Q PRACTICE SHEET (2010–2026)
                  </span>
                  <span className="text-[10px] text-amber-300 font-bold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                    {notesLang === 'hi' ? 'द्विभाषी (Hindi + English)' : 'Bilingual (Hindi + English)'}
                  </span>
                  <span className="text-[10px] text-indigo-300 font-bold bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                    {activePYQSheet.totalMarks} Marks
                  </span>
                </div>
                <h2 className="text-base sm:text-lg font-bold text-white">
                  {notesLang === 'hi' ? activePYQSheet.chapterHindi : activePYQSheet.chapter}
                </h2>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setNotesLang((l) => (l === 'en' ? 'hi' : 'en'))}
                  className="px-2.5 py-1 bg-slate-900 border border-slate-700 text-xs font-bold text-slate-300 rounded-lg hover:text-white"
                >
                  {notesLang === 'hi' ? 'English' : 'हिन्दी'}
                </button>
                <button
                  onClick={() => setActivePYQSheet(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Questions Body */}
            <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4 text-xs">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-white text-sm">
                    {notesLang === 'hi' ? 'प्रामाणिक प्रश्न व विस्तृत हल' : 'Authentic Questions & Detailed Derivations'}
                  </h4>
                  <p className="text-slate-400 text-xs mt-0.5">
                    Curated from past 17 years JEE papers with topper shortcuts.
                  </p>
                </div>
                {onLaunchChapterTest && (
                  <button
                    onClick={() => {
                      const chap = activePYQSheet.chapter;
                      setActivePYQSheet(null);
                      onLaunchChapterTest(chap);
                    }}
                    className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-lg transition-all shadow-md shrink-0 cursor-pointer"
                  >
                    Start 75-Q Live Test
                  </button>
                )}
              </div>

              {activePYQSheet.exemplarQuestions.map((eq, eqIdx) => (
                <div key={eqIdx} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-indigo-400">
                      Problem #{eqIdx + 1} · [{eq.exam} {eq.year}]
                    </span>
                    <span className="text-[10px] font-mono text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                      +4.00 / -1.00
                    </span>
                  </div>

                  <p className="text-slate-100 font-medium leading-relaxed">
                    {notesLang === 'hi' ? eq.questionHi : eq.questionEn}
                  </p>

                  {/* Options */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {(notesLang === 'hi' ? eq.optionsHi : eq.optionsEn).map((opt, optIdx) => (
                      <div
                        key={optIdx}
                        className={`p-2.5 rounded-lg border text-xs flex items-center justify-between ${
                          optIdx === eq.correctOption
                            ? 'bg-emerald-950/40 border-emerald-500/60 text-emerald-200 font-bold'
                            : 'bg-slate-900 border-slate-800 text-slate-400'
                        }`}
                      >
                        <span>{['A', 'B', 'C', 'D'][optIdx]}. {opt}</span>
                        {optIdx === eq.correctOption && (
                          <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Derivation */}
                  <div className="p-3 bg-slate-900 rounded-lg border border-slate-800/80 font-mono text-[11px] text-slate-300 leading-relaxed whitespace-pre-line">
                    <strong className="text-indigo-400 block mb-1">
                      {notesLang === 'hi' ? 'चरणबद्ध समाधान:' : 'Step-by-Step Derivation:'}
                    </strong>
                    {notesLang === 'hi' ? eq.solutionHi : eq.solutionEn}
                  </div>

                  {/* Topper Trick */}
                  <div className="p-2.5 bg-amber-950/20 border border-amber-500/30 rounded-lg text-[11px] text-amber-200 leading-relaxed">
                    <strong className="text-amber-400 block mb-0.5">
                      ⚡ {notesLang === 'hi' ? 'टॉपर का शॉर्टकट ट्रिक (कम समय में हल):' : 'Topper Shortcut Hack (Fast-Solve):'}
                    </strong>
                    {notesLang === 'hi' ? eq.topperTrickHi : eq.topperTrickEn}
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="bg-slate-950 px-5 py-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                Official JEE Main & Advanced Past Year Series
              </span>
              <button
                onClick={() => setActivePYQSheet(null)}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-lg"
              >
                Close Sheet
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
