import React from 'react';
import { 
  BarChart3, 
  Trophy, 
  Flame, 
  Target, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowUpRight,
  Clock,
  Sparkles
} from 'lucide-react';
import { UserProfileStats, UserTestAttempt } from '../types';
import { getTestAttempts } from '../services/storage';

interface AnalyticsDashboardProps {
  stats: UserProfileStats;
  onNavigateTab: (tab: string) => void;
  onOpenStreakModal?: () => void;
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  stats,
  onNavigateTab,
  onOpenStreakModal,
}) => {
  const attempts = getTestAttempts();

  const weakTopics = [
    { subject: 'Physics', topic: 'Rotational Motion & Rolling', accuracy: 52, questionsNeeded: 8 },
    { subject: 'Chemistry', topic: 'Carbocation Rearrangements (GOC)', accuracy: 60, questionsNeeded: 6 },
    { subject: 'Mathematics', topic: 'Skew Lines in 3D Geometry', accuracy: 58, questionsNeeded: 5 },
  ];

  const dailyGoal = stats.dailyGoal || 5;
  const todaySolved = stats.todayQuestionsSolved || 0;
  const goalPercent = Math.min(100, Math.round((todaySolved / dailyGoal) * 100));

  return (
    <div className="space-y-6">
      {/* Top Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Solved */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Questions Solved</span>
            <Target className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold text-white">{stats.questionsSolved}</div>
          <span className="text-[11px] text-emerald-400 mt-1 block">Active preparation</span>
        </div>

        {/* Accuracy Rate */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Overall Accuracy</span>
            <Trophy className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400">{stats.accuracyRate}%</div>
          <span className="text-[11px] text-slate-400 mt-1 block">JEE Cutoff Benchmark: &gt;70%</span>
        </div>

        {/* Tests Completed */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">CBT Tests Attempted</span>
            <Clock className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-white">{stats.testsCompleted}</div>
          <span className="text-[11px] text-indigo-400 mt-1 block">+50 Coins per test</span>
        </div>

        {/* Practice Streak */}
        <div 
          onClick={onOpenStreakModal}
          className="bg-slate-900 border border-amber-500/30 rounded-xl p-5 cursor-pointer hover:border-amber-500/60 transition-colors group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium text-amber-400/90">Daily Streak</span>
            <Flame className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
          </div>
          <div className="text-2xl font-bold text-amber-400 flex items-baseline gap-1">
            <span>{stats.streakDays}</span>
            <span className="text-sm font-normal text-amber-300">Days</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block group-hover:text-amber-300 transition-colors">
            {stats.todayGoalCompleted ? '✓ Today\'s Goal Achieved!' : `${todaySolved}/${dailyGoal} Qs Today · Click to view`}
          </span>
        </div>
      </div>

      {/* Daily Study Target Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-indigo-950/40 border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 fill-amber-400 text-amber-400" />
            <h4 className="text-sm font-bold text-white">Daily Target & Streak Consistency</h4>
            {stats.todayGoalCompleted && (
              <span className="px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-500/50 text-[10px] text-emerald-400 font-bold">
                Goal Met Today
              </span>
            )}
          </div>
          <p className="text-xs text-slate-300">
            {stats.todayGoalCompleted
              ? `You've solved ${todaySolved} questions today! Your streak is secured at ${stats.streakDays} days.`
              : `Solve ${dailyGoal - todaySolved} more questions today to keep your ${stats.streakDays}-day streak burning and earn +25 bonus coins!`}
          </p>
          <div className="w-64 bg-slate-800 h-2 rounded-full overflow-hidden mt-2">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                stats.todayGoalCompleted ? 'bg-emerald-500' : 'bg-amber-500'
              }`}
              style={{ width: `${goalPercent}%` }}
            />
          </div>
        </div>

        {onOpenStreakModal && (
          <button
            onClick={onOpenStreakModal}
            className="px-4 py-2 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 shrink-0"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Open Streak Calendar</span>
          </button>
        )}
      </div>

      {/* Weak Areas & AI Diagnosis */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              AI Weak Area Diagnosis & Rank Boosters
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Target these chapters to stop negative marking and gain +20 marks in JEE Main & Advanced.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('practice')}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1"
          >
            <span>Practice Drills</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {weakTopics.map((item, idx) => (
            <div key={idx} className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span className="text-indigo-400 font-mono font-bold uppercase">{item.subject}</span>
                  <span className="text-rose-400 font-semibold">{item.accuracy}% Accuracy</span>
                </div>
                <h4 className="text-xs font-bold text-white mb-2">{item.topic}</h4>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mb-3">
                  <div className="bg-rose-500 h-full rounded-full" style={{ width: `${item.accuracy}%` }} />
                </div>
              </div>
              <button
                onClick={() => onNavigateTab('pyq')}
                className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg text-center"
              >
                Solve PYQs on this
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* CBT Test History */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
          <Clock className="w-4 h-4 text-indigo-400" />
          Recent CBT Mock Test Attempts
        </h3>

        {attempts.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-500">
            No mock tests completed yet. Take your first CBT test to see analytics!
          </div>
        ) : (
          <div className="space-y-3">
            {attempts.map((att) => (
              <div
                key={att.id}
                className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
              >
                <div>
                  <h4 className="font-bold text-slate-200">{att.testTitle}</h4>
                  <div className="flex items-center gap-2 text-slate-400 mt-1">
                    <span>{att.date}</span>
                    <span>·</span>
                    <span>Time: {Math.floor(att.totalTimeSpentSeconds / 60)}m</span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <span className="text-sm font-bold text-white">{att.score} / {att.maxScore}</span>
                    <span className="text-[11px] text-slate-400 block">{att.accuracy}% Accuracy</span>
                  </div>
                  <div className="flex gap-1.5 text-[11px]">
                    <span className="px-2 py-1 bg-emerald-950/60 border border-emerald-800/40 text-emerald-400 rounded">
                      +{att.correctCount}
                    </span>
                    <span className="px-2 py-1 bg-rose-950/60 border border-rose-800/40 text-rose-400 rounded">
                      -{att.incorrectCount}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
