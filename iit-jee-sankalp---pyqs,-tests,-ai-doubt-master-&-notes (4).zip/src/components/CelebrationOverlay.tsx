import React, { useEffect, useRef } from 'react';
import { Flame, Trophy, Coins, Sparkles, CheckCircle2, X, ArrowRight } from 'lucide-react';

interface CelebrationOverlayProps {
  streakDays: number;
  dailyGoal: number;
  onClose: () => void;
  onViewStreakDetails?: () => void;
}

export const CelebrationOverlay: React.FC<CelebrationOverlayProps> = ({
  streakDays,
  dailyGoal,
  onClose,
  onViewStreakDetails,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Play celebratory audio chime via Web Audio API
  useEffect(() => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
        notes.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.value = freq;
          
          const startTime = ctx.currentTime + idx * 0.12;
          gain.gain.setValueAtTime(0, startTime);
          gain.gain.linearRampToValueAtTime(0.18, startTime + 0.04);
          gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.6);
          
          osc.connect(gain);
          gain.connect(ctx.destination);
          
          osc.start(startTime);
          osc.stop(startTime + 0.65);
        });
      }
    } catch {
      // Audio autoplay policy fallback
    }
  }, []);

  // Confetti Physics simulation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const colors = [
      '#f59e0b', // amber-500
      '#ef4444', // red-500
      '#10b981', // emerald-500
      '#6366f1', // indigo-500
      '#3b82f6', // blue-500
      '#ec4899', // pink-500
      '#fbbf24', // yellow-400
    ];

    const particles: Array<{
      x: number;
      y: number;
      w: number;
      h: number;
      vx: number;
      vy: number;
      rotation: number;
      vRot: number;
      color: string;
      alpha: number;
      shape: 'rect' | 'circle';
    }> = [];

    const particleCount = 140;
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: -20 - Math.random() * 200,
        w: 6 + Math.random() * 8,
        h: 4 + Math.random() * 10,
        vx: (Math.random() - 0.5) * 4,
        vy: 2.5 + Math.random() * 4.5,
        rotation: Math.random() * 360,
        vRot: (Math.random() - 0.5) * 8,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 1,
        shape: Math.random() > 0.3 ? 'rect' : 'circle',
      });
    }

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.rotation += p.vRot;
        p.vy += 0.05; // gravity

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rotation * Math.PI) / 180);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;

        if (p.shape === 'rect') {
          ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        } else {
          ctx.beginPath();
          ctx.arc(0, 0, p.w / 2, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();

        // Recycle particles for a rich 4-second cascade
        if (p.y > canvas.height + 20) {
          p.y = -20;
          p.x = Math.random() * canvas.width;
          p.vy = 2.5 + Math.random() * 4.5;
        }
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    const handleResize = () => {
      if (!canvas) return;
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
      {/* Confetti Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none z-0"
      />

      {/* Main Celebration Card */}
      <div className="relative z-10 w-full max-w-md bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-amber-500/50 rounded-3xl p-6 sm:p-8 text-center shadow-2xl shadow-amber-500/20 animate-in zoom-in-95 duration-300">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          title="Close celebration"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Floating Glowing Flame Icon */}
        <div className="relative mx-auto mb-4 w-20 h-20">
          <div className="absolute inset-0 bg-amber-500/30 rounded-full blur-xl animate-pulse" />
          <div className="relative w-full h-full rounded-2xl bg-gradient-to-tr from-amber-600 via-orange-500 to-yellow-400 flex items-center justify-center shadow-lg shadow-orange-500/40 animate-bounce">
            <Flame className="w-10 h-10 fill-white text-white drop-shadow-md" />
          </div>
        </div>

        {/* Celebration Title */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold tracking-wide uppercase mb-2">
          <Sparkles className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
          <span>Daily Goal Accomplished!</span>
        </div>

        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Day {streakDays} Streak Unlocked!
        </h2>

        <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
          Zabardast! You hit your daily target of <strong className="text-white">{dailyGoal} questions</strong> today. Consistent daily practice is the secret weapon of every top IIT JEE ranker!
        </p>

        {/* Rewards Earned Box */}
        <div className="grid grid-cols-2 gap-3 mt-6 p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
          <div className="flex flex-col items-center justify-center p-2 rounded-xl bg-amber-500/10 border border-amber-500/20">
            <div className="flex items-center gap-1.5 text-amber-400 font-extrabold text-lg sm:text-xl">
              <Flame className="w-5 h-5 fill-amber-400" />
              <span>{streakDays} Days</span>
            </div>
            <span className="text-[11px] text-amber-300/80 font-medium mt-0.5">Consecutive Streak</span>
          </div>

          <div className="flex flex-col items-center justify-center p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
            <div className="flex items-center gap-1.5 text-emerald-400 font-extrabold text-lg sm:text-xl">
              <Coins className="w-5 h-5" />
              <span>+25 Coins</span>
            </div>
            <span className="text-[11px] text-emerald-300/80 font-medium mt-0.5">Streak Reward Bonus</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-3 mt-6">
          {onViewStreakDetails && (
            <button
              onClick={() => {
                onClose();
                onViewStreakDetails();
              }}
              className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all flex items-center justify-center gap-1.5"
            >
              <span>View Streak Calendar</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={onClose}
            className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 text-xs font-extrabold transition-all shadow-lg shadow-amber-500/20"
          >
            Keep Cracking PYQs
          </button>
        </div>
      </div>
    </div>
  );
};
