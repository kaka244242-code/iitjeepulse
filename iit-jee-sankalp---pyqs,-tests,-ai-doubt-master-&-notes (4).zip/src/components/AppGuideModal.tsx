import React, { useState } from 'react';
import { 
  X, 
  BookOpen, 
  Clock, 
  Target, 
  Sparkles, 
  Library, 
  CheckCircle2, 
  ArrowRight, 
  Flame, 
  Globe, 
  HelpCircle,
  FileText,
  Bot,
  Zap,
  ChevronRight,
  Lightbulb,
  Award
} from 'lucide-react';
import { AppLanguage } from '../types';

interface AppGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  onNavigateTab: (tabId: string) => void;
}

export const AppGuideModal: React.FC<AppGuideModalProps> = ({
  isOpen,
  onClose,
  language,
  onNavigateTab,
}) => {
  const [guideLang, setGuideLang] = useState<AppLanguage>(language);
  const [activeStep, setActiveStep] = useState<number>(0);

  if (!isOpen) return null;

  const steps = [
    {
      id: 'pyq',
      icon: Library,
      badge: 'Step 1 / 6',
      titleEn: '2010–2026 PYQ Mega Library',
      titleHi: '2010–2026 पीवाईक्यू मेगा लाइब्रेरी',
      summaryEn: 'Solve official past year JEE papers from 2010 to 2026 with instant +4 / -1 evaluation.',
      summaryHi: '2010 से 2026 तक के आधिकारिक जेईई प्रश्न पत्रों को +4 / -1 मार्किंग और तुरंत समाधान के साथ हल करें।',
      featuresEn: [
        'Browse 17 years timeline (2026 predictor to 2010 past papers).',
        'Filter by Subject (Physics, Chemistry, Math), Exam (Main & Advanced), or Difficulty.',
        'View step-by-step derivations and Kota AIR-Ranker shortcut tricks.',
        'Click "Ask AI Guru" anytime to get instant step-by-step conceptual clarification.',
      ],
      featuresHi: [
        '17 वर्षों की टाइमलाइन (2026 प्रेडिक्टर से 2010) एक क्लिक पर ब्राउज़ करें।',
        'विषय (भौतिकी, रसायन, गणित), परीक्षा (मेन व एडवांस्ड) या कठिनाई के अनुसार फ़िल्टर करें।',
        'चरणबद्ध हल व कोटा टॉपर्स की शॉर्टकट ट्रिक्स देखें।',
        'किसी भी प्रश्न पर "AI गुरु" पर क्लिक करके तुरंत विस्तृत मार्गदर्शन प्राप्त करें।',
      ],
      actionTab: 'pyq',
      actionLabelEn: 'Go to PYQ Library',
      actionLabelHi: 'पीवाईक्यू लाइब्रेरी खोलें',
    },
    {
      id: 'cbt',
      icon: Clock,
      badge: 'Step 2 / 6',
      titleEn: '1,000 CBT Tests Vault (75 Qs / 300 Marks Each)',
      titleHi: '1,000 सीबीटी टेस्ट वॉल्ट (प्रत्येक में 75 प्रश्न / 300 अंक)',
      summaryEn: 'Simulate the exact NTA computer-based exam with strict timer, question palette, and negative marking.',
      summaryHi: 'वास्तविक NTA कंप्यूटर आधारित परीक्षा जैसा माहौल, 180 मिनट का टाइमर, क्वेश्चन पैलेट और नेगेटिव मार्किंग।',
      featuresEn: [
        'Over 1,000 authentic tests curated across high-yield weightage topics.',
        'Every single test features 75 Questions & 300 Marks (+4 / -1 scheme).',
        'Official NTA Language Switcher: Toggle between English and हिन्दी in real time during the exam!',
        'Easy navigation: Quick-jump to any test number (e.g. #142) and section jumps (Part 1, 2, 3).',
      ],
      featuresHi: [
        'उच्च वेटेज वाले विषयों पर आधारित 1,000 से अधिक प्रामाणिक टेस्ट।',
        'प्रत्येक टेस्ट में पूरे 75 प्रश्न व 300 अंक (+4 / -1 मार्किंग)।',
        'आधिकारिक NTA भाषा चयन: टेस्ट के दौरान कभी भी अंग्रेजी व हिन्दी में स्विच करें!',
        'सरल नेविगेशन: किसी भी टेस्ट नंबर (जैसे #142) व सेक्शन (भाग 1, 2, 3) पर त्वरित जंप करें।',
      ],
      actionTab: 'cbt',
      actionLabelEn: 'Open 1,000 CBT Tests',
      actionLabelHi: '1,000 सीबीटी टेस्ट देखें',
    },
    {
      id: 'notes',
      icon: FileText,
      badge: 'Step 3 / 6',
      titleEn: 'Short Notes & PYQ Sheets of All Chapters (Hindi & English)',
      titleHi: 'सभी अध्यायों के शॉर्ट नोट्स व पीवाईक्यू शीट्स (हिंदी व अंग्रेजी)',
      summaryEn: 'Revise high-yield formulas, common traps, and chapter-wise solved question sheets before your exam.',
      summaryHi: 'परीक्षा से पूर्व महत्वपूर्ण सूत्रों, सामान्य गलतियों व अध्याय-वार हल की गई शीट्स का त्वरित पुनरीक्षण करें।',
      featuresEn: [
        'Ultra-dense formula cheat sheets with condition notes for all Physics, Chem & Math chapters.',
        'Curated 2010–2026 PYQ Sheets with step-by-step derivations and topper tricks.',
        'Bilingual Mode: Switch all notes, formulas, and questions between English & हिन्दी.',
        'Custom Upload: Upload your own coaching PDFs or handwritten notes to view right in the app.',
      ],
      featuresHi: [
        'भौतिकी, रसायन व गणित के सभी अध्यायों हेतु अति-संक्षिप्त सूत्र शीट्स।',
        'चरणबद्ध हल व टॉपर ट्रिक्स के साथ 2010–2026 की प्रामाणिक पीवाईक्यू शीट्स।',
        'द्विभाषी सुविधा: सभी नोट्स, सूत्र व प्रश्न अंग्रेजी व हिन्दी दोनों में उपलब्ध।',
        'अपनी स्वयं की कोचिंग PDF या नोट्स अपलोड करके ऐप में पढ़ने की सुविधा।',
      ],
      actionTab: 'notes',
      actionLabelEn: 'View Short Notes & Sheets',
      actionLabelHi: 'शॉर्ट नोट्स व शीट्स देखें',
    },
    {
      id: 'books',
      icon: BookOpen,
      badge: 'Step 4 / 6',
      titleEn: 'Digital Book Library & 20,000+ Questions Archive',
      titleHi: 'डिजिटल बुक लाइब्रेरी व 20,000+ प्रश्नों का संग्रह',
      summaryEn: 'Access Disha, Arihant, Cengage 20,000+ questions compendiums and standard textbooks.',
      summaryHi: 'दिशा, अरिहंत, सेनगेज के 20,000+ हल किए गए प्रश्नों के संग्रह ग्रंथ व मानक पाठ्यपुस्तकें।',
      featuresEn: [
        'Mega 20,000+ questions compendiums covering all topics from 2010 to 2026.',
        'Built-in interactive PDF Reader with chapter index and jump-to-page navigation.',
        'Search across standard reference textbooks (HC Verma, Morrison Boyd, Irodov, RD Sharma).',
        'Upload your own study materials with one-click instant reading.',
      ],
      featuresHi: [
        '2010 से 2026 तक के 20,000+ प्रश्नों का विशाल संग्रह।',
        'चैप्टर इंडेक्स व पेज नेविगेशन के साथ इन-बिल्ट PDF रीडर।',
        'मानक संदर्भ पुस्तकें (एचसी वर्मा, इरोडोव, आरडी शर्मा) आसानी से खोजें।',
        'अपनी अध्ययन सामग्री एक क्लिक में अपलोड करके पढ़ें।',
      ],
      actionTab: 'books',
      actionLabelEn: 'Explore Books & 20K Qs',
      actionLabelHi: 'किताबें व 20K प्रश्न देखें',
    },
    {
      id: 'ai-master',
      icon: Bot,
      badge: 'Step 5 / 6',
      titleEn: 'AI Doubt Master (Guru AI Solver)',
      titleHi: 'गुरु AI डाउट सॉल्वर (AI गुरु)',
      summaryEn: 'Your personal 24/7 IIT JEE mentor for instant step-by-step doubt resolution and math derivations.',
      summaryHi: 'आपका 24/7 व्यक्तिगत जेईई मेंटॉर जो कठिन सवालों के चरणबद्ध हल व अवधारणाएं समझाता है।',
      featuresEn: [
        'Ask doubts via text or send any question from the app directly with 1 click.',
        'Provides step-by-step math derivations, key formula principles, and shortcut tricks.',
        'Fluent in both English and Hindi/Hinglish for clear understanding.',
        'Helps eliminate negative marking by explaining why incorrect options are wrong.',
      ],
      featuresHi: [
        'टेक्स्ट द्वारा डाउट पूछें या ऐप के किसी भी प्रश्न को 1 क्लिक में सीधे भेजें।',
        'चरणबद्ध गणितीय हल, मुख्य सूत्र व शॉर्टकट ट्रिक्स प्रदान करता है।',
        'सरल समझ के लिए अंग्रेजी, हिन्दी व हिंग्लिश में पारंगत।',
        'गलत विकल्पों के कारण समझाकर नेगेटिव मार्किंग से बचाता है।',
      ],
      actionTab: 'ai-master',
      actionLabelEn: 'Ask AI Guru a Doubt',
      actionLabelHi: 'AI गुरु से डाउट पूछें',
    },
    {
      id: 'streak',
      icon: Zap,
      badge: 'Step 6 / 6',
      titleEn: 'Daily Study Streak & Sankalp Coins',
      titleHi: 'दैनिक अध्ययन स्ट्रीक व संकल्प सिक्के',
      summaryEn: 'Stay consistent every day, earn rewards, and track your projected IIT All-India Rank percentile.',
      summaryHi: 'प्रतिदिन निरंतरता बनाए रखें, पुरस्कार अर्जित करें और अपनी अनुमानित ऑल इंडिया पर्सेंटाइल देखें।',
      featuresEn: [
        'Solve 5 questions daily to maintain your study streak and earn bonus coins.',
        'Earn +5 Coins per solved PYQ and +50 Coins per completed 75-question Mock Test.',
        'Use Sankalp Coins to unlock Kota Topper handwritten master bundles.',
        'Track your accuracy, subject-wise strengths, and performance analytics.',
      ],
      featuresHi: [
        'दैनिक स्ट्रीक बनाए रखने के लिए प्रतिदिन 5 प्रश्न हल करें व बोनस सिक्के प्राप्त करें।',
        'प्रत्येक हल प्रश्न पर +5 सिक्के तथा प्रत्येक 75-प्रश्नों के टेस्ट पर +50 सिक्के पाएं।',
        'सिक्कों का उपयोग करके कोटा टॉपर्स के हस्तलिखित मास्टर बंडल अनलॉक करें।',
        'अपनी सटीकता, विषय-वार पकड़ व प्रदर्शन ग्राफ को ट्रैक करें।',
      ],
      actionTab: 'analytics',
      actionLabelEn: 'Check My Performance',
      actionLabelHi: 'अपना प्रदर्शन देखें',
    },
  ];

  const currentStepData = steps[activeStep];
  const StepIcon = currentStepData.icon;

  const handleLaunchTab = (tabId: string) => {
    onClose();
    onNavigateTab(tabId);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                <span>{guideLang === 'hi' ? 'ऐप कैसे इस्तेमाल करें? (यूजर गाइड)' : 'How to Use IIT JEE Sankalp App (User Guide)'}</span>
              </h2>
              <span className="text-[11px] text-slate-400">
                {guideLang === 'hi' ? 'सभी फीचर्स, 1000 टेस्ट, शॉर्ट नोट्स व AI गुरु की जानकारी' : 'Complete walkthrough of all features, 1000 tests, notes & AI'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Guide Language Toggle */}
            <button
              onClick={() => setGuideLang((l) => (l === 'en' ? 'hi' : 'en'))}
              className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-750 text-xs font-bold text-slate-300 hover:text-white flex items-center gap-1.5 transition-all"
            >
              <Globe className="w-3.5 h-3.5 text-indigo-400" />
              <span>{guideLang === 'hi' ? 'English' : 'हिन्दी'}</span>
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Step Selector Pills Bar */}
        <div className="bg-slate-950/60 px-5 py-2.5 border-b border-slate-800/80 overflow-x-auto flex items-center gap-1.5 scrollbar-thin">
          {steps.map((st, idx) => {
            const Icon = st.icon;
            const isCurrent = activeStep === idx;
            return (
              <button
                key={st.id}
                onClick={() => setActiveStep(idx)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  isCurrent
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" />
                <span>{guideLang === 'hi' ? st.titleHi.split(' ')[0] : st.titleEn.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Main Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {/* Active Step Hero */}
          <div className="bg-gradient-to-r from-indigo-950/40 via-slate-950 to-slate-950 p-5 rounded-2xl border border-indigo-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <div className="w-12 h-12 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 border border-indigo-500/40">
                <StepIcon className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-bold font-mono text-amber-400 uppercase tracking-wider block mb-1">
                  {currentStepData.badge}
                </span>
                <h3 className="text-base sm:text-lg font-bold text-white leading-tight">
                  {guideLang === 'hi' ? currentStepData.titleHi : currentStepData.titleEn}
                </h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  {guideLang === 'hi' ? currentStepData.summaryHi : currentStepData.summaryEn}
                </p>
              </div>
            </div>

            <button
              onClick={() => handleLaunchTab(currentStepData.actionTab)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 shadow-md shadow-indigo-600/30 shrink-0"
            >
              <span>{guideLang === 'hi' ? currentStepData.actionLabelHi : currentStepData.actionLabelEn}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Feature List Points */}
          <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-3">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-amber-400" />
              <span>{guideLang === 'hi' ? 'महत्वपूर्ण बातें और उपयोग का तरीका:' : 'Key Features & Pro Tips:'}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {(guideLang === 'hi' ? currentStepData.featuresHi : currentStepData.featuresEn).map((point, pIdx) => (
                <div key={pIdx} className="flex items-start gap-2.5 text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-3 rounded-lg border border-slate-800/80">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{point}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick FAQ / Shortcut Tips Box */}
          <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 text-xs text-slate-400 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <Award className="w-5 h-5 text-amber-400 shrink-0" />
              <span>
                {guideLang === 'hi'
                  ? 'टॉपर सलाह: प्रतिदिन 5 प्रश्न हल करें, अपनी 7-दिवसीय स्ट्रीक बनाए रखें और वीकेंड पर 1 फुल 75-प्रश्नों का टेस्ट दें।'
                  : 'Topper Strategy: Solve 5 PYQs daily, maintain your 7-day streak, and take 1 full 75-Q CBT mock every weekend.'}
              </span>
            </div>
          </div>
        </div>

        {/* Modal Footer Controls */}
        <div className="bg-slate-950 px-5 py-3.5 border-t border-slate-800 flex items-center justify-between gap-3">
          <button
            disabled={activeStep === 0}
            onClick={() => setActiveStep((s) => Math.max(0, s - 1))}
            className="px-3.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed transition-all"
          >
            {guideLang === 'hi' ? 'पिछला' : 'Previous'}
          </button>

          {/* Dots Indicator */}
          <div className="flex items-center gap-1.5">
            {steps.map((_, dotIdx) => (
              <button
                key={dotIdx}
                onClick={() => setActiveStep(dotIdx)}
                className={`w-2.5 h-2.5 rounded-full transition-all ${
                  activeStep === dotIdx ? 'w-6 bg-indigo-500' : 'bg-slate-750 hover:bg-slate-600'
                }`}
              />
            ))}
          </div>

          {activeStep < steps.length - 1 ? (
            <button
              onClick={() => setActiveStep((s) => Math.min(steps.length - 1, s + 1))}
              className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white transition-all flex items-center gap-1.5"
            >
              <span>{guideLang === 'hi' ? 'अगला' : 'Next'}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white transition-all flex items-center gap-1.5 shadow-sm"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{guideLang === 'hi' ? 'समझ आ गया, पढ़ना शुरू करें!' : 'Got it, Let\'s Study!'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
