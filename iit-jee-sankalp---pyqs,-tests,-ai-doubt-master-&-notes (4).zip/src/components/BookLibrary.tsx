import React, { useState, useEffect, useRef } from 'react';
import { 
  BookMarked, 
  Upload, 
  BookOpen, 
  Trash2, 
  Sparkles, 
  Star, 
  FileText, 
  Plus, 
  X, 
  Eye, 
  Download,
  CheckCircle2,
  AlertCircle,
  Archive,
  Layers
} from 'lucide-react';
import { BookItem, Subject, Question, AppLanguage } from '../types';
import { standardBooks } from '../data/mockBooks';
import { getUploadedBooks, saveUploadedBook, deleteUploadedBook } from '../services/storage';
import { getTranslation } from '../utils/translations';

interface BookLibraryProps {
  onAskAIMaster: (question: Question) => void;
  onOpenBookReader: (book: BookItem) => void;
  language: AppLanguage;
}

export const BookLibrary: React.FC<BookLibraryProps> = ({
  onAskAIMaster,
  onOpenBookReader,
  language,
}) => {
  const t = getTranslation(language);
  const [booksList, setBooksList] = useState<BookItem[]>(standardBooks);
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [showUploadModal, setShowUploadModal] = useState(false);

  // Upload Form State
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadAuthor, setUploadAuthor] = useState('');
  const [uploadSubject, setUploadSubject] = useState<Subject>('Physics');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadFileContent, setUploadFileContent] = useState<string>('');
  const [uploadPages, setUploadPages] = useState<number>(50);
  const [uploadQuestionsCount, setUploadQuestionsCount] = useState<number>(500);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load uploaded books from storage
  useEffect(() => {
    loadBooks();
  }, []);

  const loadBooks = async () => {
    const userUploaded = await getUploadedBooks();
    setBooksList([...userUploaded, ...standardBooks]);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadFile(file);
      if (!uploadTitle) {
        setUploadTitle(file.name.replace(/\.[^/.]+$/, ''));
      }
      const reader = new FileReader();
      reader.onload = () => {
        setUploadFileContent(reader.result as string);
      };
      if (file.type.includes('text') || file.name.endsWith('.md') || file.name.endsWith('.txt')) {
        reader.readAsText(file);
      } else {
        reader.readAsDataURL(file);
      }
    }
  };

  const handleSaveUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadTitle.trim()) return;

    setIsUploading(true);

    const newBook: BookItem = {
      id: `user-book-${Date.now()}`,
      title: uploadTitle.trim(),
      author: uploadAuthor.trim() || (language === 'hi' ? 'मेरे नोट्स' : 'My Study Material'),
      subject: uploadSubject,
      category: 'Custom Upload',
      totalPages: uploadPages || 50,
      questionCount: uploadQuestionsCount || 250,
      yearCoverage: '2010 – 2026',
      rating: 5.0,
      coverColor: uploadSubject === 'Physics' 
        ? 'from-indigo-700 via-blue-800 to-slate-900' 
        : uploadSubject === 'Chemistry' 
        ? 'from-emerald-700 via-teal-800 to-slate-900' 
        : 'from-violet-700 via-purple-900 to-slate-900',
      description: `Student uploaded document: ${uploadFile?.name || 'Class notes and PYQs'}. Contains authentic solved questions and formulas.`,
      chapters: [
        'Chapter 1: 2010–2018 Past JEE Questions & Solutions',
        'Chapter 2: 2019–2026 Shift-Wise CBT Questions',
        'Chapter 3: High-Yield Formulas & Error Logs',
      ],
      sampleContent: uploadFileContent && typeof uploadFileContent === 'string' && !uploadFileContent.startsWith('data:')
        ? uploadFileContent
        : `# ${uploadTitle}\n\nUploaded study material: ${uploadFile?.name || 'PDF Document'}.\n\nContains comprehensive 2010–2026 JEE practice sets, formulas, and verified step solutions for ${uploadSubject}. Click 'Ask AI Master' to explore doubts or solve problems from this collection!`,
      fileName: uploadFile?.name,
      uploadedAt: new Date().toLocaleDateString(),
      isUserUploaded: true,
      fileDataUrl: typeof uploadFileContent === 'string' ? uploadFileContent : undefined,
    };

    saveUploadedBook(newBook);
    setUploadSuccess(true);
    setTimeout(() => {
      setIsUploading(false);
      setShowUploadModal(false);
      setUploadSuccess(false);
      setUploadTitle('');
      setUploadAuthor('');
      setUploadFile(null);
      setUploadFileContent('');
      loadBooks();
    }, 900);
  };

  const handleDeleteBook = async (bookId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm(language === 'hi' ? 'क्या आप इस पुस्तक को हटाना चाहते हैं?' : 'Are you sure you want to delete this uploaded book?')) {
      deleteUploadedBook(bookId);
      await loadBooks();
    }
  };

  const filteredBooks = booksList.filter((b) => {
    if (selectedSubject !== 'All' && b.subject !== selectedSubject && b.subject !== 'All Subjects') {
      return false;
    }
    if (selectedCategory === 'PYQ Compendium') {
      return b.category === 'PYQ Compendium' || b.category === 'PYQ Practice Sheet';
    }
    if (selectedCategory === 'PYQ Practice Sheet') {
      return b.category === 'PYQ Practice Sheet';
    }
    if (selectedCategory === 'Textbook') {
      return b.category === 'Textbook' || b.category === 'Problem Book' || b.category === 'Reference';
    }
    if (selectedCategory !== 'All' && b.category !== selectedCategory) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner & Upload Action */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
                <Archive className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? '10,000 बेसिक PYQs PDF' : '10,000 Basic PYQs (PDF)'}</span>
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {language === 'hi' ? 'भौतिकी + रसायन + गणित (हिन्दी व English)' : 'Physics, Chemistry & Math (Bilingual)'}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                2010 – 2026 Official
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2 tracking-tight">
              <BookMarked className="w-6 h-6 text-indigo-400" />
              {language === 'hi' ? '10,000 बेसिक PYQ लाइब्रेरी व पुस्तकें (PDF)' : '10,000 Basic PYQs & Book Library (PDF Form)'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              {language === 'hi' 
                ? 'तीनों विषयों (Physics, Chemistry, Math) के 10,000 बेसिक PYQs पूरे हल सहित PDF रूप में पढ़ें। साथ ही कोटा टॉपर्स के शॉर्टकट और मानक संदर्भ पुस्तकें।'
                : '10,000 curated basic to advance PYQs across Physics, Chemistry & Mathematics in full PDF reader format with side-by-side Hindi & English explanations, step derivations, and reference textbooks.'}
            </p>
          </div>

          <button
            onClick={() => setShowUploadModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-600/20 transition-all shrink-0 cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            <span>{t.uploadBookBtn}</span>
          </button>
        </div>

        {/* Category & Subject Filter Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6 pt-4 border-t border-slate-800">
          {/* Subject Filter */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs text-slate-400 mr-2 font-medium">
              {language === 'hi' ? 'विषय:' : 'Subject:'}
            </span>
            {[
              { id: 'All', label: language === 'hi' ? 'सभी विषय (10,000 PYQs)' : 'All Subjects (10,000 Qs)' },
              { id: 'Physics', label: language === 'hi' ? 'भौतिकी (3,300 PYQs)' : 'Physics (3,300 Qs)' },
              { id: 'Chemistry', label: language === 'hi' ? 'रसायन (3,500 PYQs)' : 'Chemistry (3,500 Qs)' },
              { id: 'Mathematics', label: language === 'hi' ? 'गणित (3,200 PYQs)' : 'Maths (3,200 Qs)' },
            ].map((sub) => (
              <button
                key={sub.id}
                onClick={() => setSelectedSubject(sub.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                  selectedSubject === sub.id
                    ? 'bg-indigo-600 border-indigo-500 text-white shadow-sm'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {sub.label}
              </button>
            ))}
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap items-center gap-1.5 sm:justify-end">
            <span className="text-xs text-slate-400 mr-2 font-medium">
              {language === 'hi' ? 'श्रेणी:' : 'Category:'}
            </span>
            {[
              { id: 'All', label: language === 'hi' ? 'सभी PYQ व पुस्तकें' : 'All' },
              { id: 'PYQ Compendium', label: language === 'hi' ? '10,000 बेसिक PYQs (PDF)' : '10,000 PYQs (PDF)' },
              { id: 'PYQ Practice Sheet', label: language === 'hi' ? 'चैप्टर PYQ शीट्स (PDF)' : 'Chapter PYQ Sheets (PDF)' },
              { id: 'Textbook', label: language === 'hi' ? 'मानक पुस्तकें व फॉर्मूले' : 'Textbooks & Formulas' },
              { id: 'Custom Upload', label: language === 'hi' ? 'अपलोड्स' : 'My Uploads' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-indigo-600 border-indigo-500 text-white shadow-sm'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Books Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredBooks.map((book) => {
          const isMega20k = book.questionCount && book.questionCount >= 6000;
          const isPYQSheet = book.category === 'PYQ Practice Sheet' || book.category === 'PYQ Compendium';

          return (
            <div
              key={book.id}
              onClick={() => onOpenBookReader(book)}
              className={`bg-slate-900 border rounded-2xl overflow-hidden hover:border-slate-700 transition-all cursor-pointer group flex flex-col justify-between shadow-sm relative ${
                isMega20k ? 'border-amber-500/40 ring-1 ring-amber-500/20' : 'border-slate-800'
              }`}
            >
              <div>
                {/* Book Spine / Cover Preview Banner */}
                <div className={`h-44 bg-gradient-to-br ${book.coverColor} p-5 flex flex-col justify-between relative overflow-hidden`}>
                  <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-white/10 rounded-full blur-xl" />

                  {/* Header badges */}
                  <div className="flex items-center justify-between text-xs text-white/90">
                    <span className="font-mono uppercase font-bold tracking-wider text-[11px] bg-black/30 backdrop-blur-sm px-2 py-0.5 rounded">
                      {book.subject}
                    </span>

                    <div className="flex items-center gap-1.5">
                      {book.questionCount && (
                        <span className="px-2 py-0.5 rounded bg-amber-400 text-slate-950 font-black text-[10px] uppercase tracking-wider shadow-sm">
                          {book.questionCount.toLocaleString()} Qs
                        </span>
                      )}
                      <div className="flex items-center gap-1 bg-black/40 backdrop-blur-sm px-2 py-0.5 rounded text-[11px] font-bold">
                        <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                        <span>{book.rating}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="px-1.5 py-0.5 rounded bg-black/40 text-emerald-300 font-bold text-[9px] uppercase tracking-wider border border-white/10">
                        Bilingual PDF (EN + हिन्दी)
                      </span>
                      {book.yearCoverage && (
                        <span className="px-1.5 py-0.5 rounded bg-black/40 text-sky-200 font-mono text-[9px] border border-white/10">
                          {book.yearCoverage}
                        </span>
                      )}
                    </div>
                    <h3 className="text-base font-bold text-white group-hover:text-amber-200 transition-colors line-clamp-2 leading-snug">
                      {book.title}
                    </h3>
                    <span className="text-xs text-white/80 block mt-0.5 font-medium">{book.author}</span>
                  </div>
                </div>

                {/* Book Details */}
                <div className="p-4 space-y-3">
                  <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed">
                    {book.description}
                  </p>

                  <div className="text-[11px] text-slate-500 flex items-center justify-between font-mono pt-2 border-t border-slate-800/80">
                    <span className="flex items-center gap-1 text-slate-300">
                      <FileText className="w-3 h-3 text-indigo-400" />
                      {book.totalPages} {t.totalPages}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-950 text-indigo-300 border border-indigo-500/20 text-[10px] font-semibold">
                      {book.category === 'PYQ Practice Sheet' ? '20 Qs PDF Sheet' : book.category}
                    </span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="p-4 pt-0 flex items-center justify-between gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenBookReader(book);
                  }}
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-sm shadow-indigo-600/20 cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5 text-amber-300" />
                  <span>{language === 'hi' ? 'PYQ शीट PDF खोलें / पढ़ें' : 'Read PYQ PDF Sheet'}</span>
                </button>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenBookReader(book);
                    setTimeout(() => window.print(), 300);
                  }}
                  className="p-2.5 bg-slate-950 hover:bg-emerald-950/60 text-emerald-400 rounded-lg text-xs border border-slate-800 transition-colors cursor-pointer"
                  title={language === 'hi' ? 'PDF प्रिंट / डाउनलोड करें' : 'Print / Download PDF'}
                >
                  <Download className="w-3.5 h-3.5" />
                </button>

                {book.isUserUploaded && (
                  <button
                    onClick={(e) => handleDeleteBook(book.id, e)}
                    className="p-2.5 bg-slate-950 hover:bg-rose-950/60 text-slate-400 hover:text-rose-400 rounded-lg text-xs border border-slate-800 transition-colors cursor-pointer"
                    title={language === 'hi' ? 'हटाएं' : 'Delete Book'}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Upload className="w-4 h-4 text-indigo-400" />
                <span>{language === 'hi' ? 'पुस्तक / PYQ नोट्स PDF अपलोड करें' : 'Upload Book / PYQ Notes PDF'}</span>
              </h3>
              <button
                onClick={() => setShowUploadModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveUpload} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  {language === 'hi' ? 'पुस्तक / संग्रह का नाम *' : 'Book / Compendium Title *'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={language === 'hi' ? 'उदा. 2010–2026 JEE Main Physics PYQs' : 'e.g. 2010–2026 JEE Main Physics Solved Papers'}
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    {language === 'hi' ? 'लेखक / कोचिंग *' : 'Author / Source'}
                  </label>
                  <input
                    type="text"
                    placeholder={language === 'hi' ? 'उदा. Allen / Resonance / Self' : 'e.g. Allen / Resonance / Self Notes'}
                    value={uploadAuthor}
                    onChange={(e) => setUploadAuthor(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    {language === 'hi' ? 'विषय' : 'Subject'}
                  </label>
                  <select
                    value={uploadSubject}
                    onChange={(e) => setUploadSubject(e.target.value as Subject)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Physics">Physics</option>
                    <option value="Chemistry">Chemistry</option>
                    <option value="Mathematics">Mathematics</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    {language === 'hi' ? 'अनुमानित प्रश्न संख्या' : 'Approx Question Count'}
                  </label>
                  <input
                    type="number"
                    value={uploadQuestionsCount}
                    onChange={(e) => setUploadQuestionsCount(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    {language === 'hi' ? 'कुल पृष्ठ' : 'Total Pages'}
                  </label>
                  <input
                    type="number"
                    value={uploadPages}
                    onChange={(e) => setUploadPages(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* File Drop Area */}
              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  {language === 'hi' ? 'PDF या टेक्स्ट फाइल चुनें' : 'Choose PDF, Markdown or Text File'}
                </label>
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="p-6 border-2 border-dashed border-slate-800 hover:border-indigo-500/60 rounded-xl bg-slate-950 text-center cursor-pointer transition-all"
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept=".pdf,.txt,.md,application/pdf"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <Upload className="w-6 h-6 text-slate-500 mx-auto mb-2" />
                  <span className="text-xs font-semibold text-slate-300 block">
                    {uploadFile ? uploadFile.name : (language === 'hi' ? 'फाइल चुनने के लिए यहां क्लिक करें' : 'Click to select PDF or notes file')}
                  </span>
                  <span className="text-[11px] text-slate-500 mt-1 block">
                    Supports PDF, TXT, Markdown documents
                  </span>
                </div>
              </div>

              {uploadSuccess && (
                <div className="p-3 bg-emerald-950/60 border border-emerald-800 text-emerald-300 rounded-lg flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{language === 'hi' ? 'पुस्तक सफलतापूर्वक लाइब्रेरी में जुड़ गई!' : 'Book uploaded successfully to your library!'}</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg font-semibold"
                >
                  {language === 'hi' ? 'रद्द करें' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isUploading}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-bold shadow-md shadow-indigo-600/30 flex items-center gap-1.5"
                >
                  {isUploading ? (
                    <span>{language === 'hi' ? 'सेव हो रहा है...' : 'Saving...'}</span>
                  ) : (
                    <>
                      <Upload className="w-3.5 h-3.5" />
                      <span>{language === 'hi' ? 'लाइब्रेरी में जोड़ें' : 'Add to Library'}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
