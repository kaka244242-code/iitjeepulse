import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '25mb' }));

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// System instruction for IIT JEE AI Master
const IIT_JEE_SYSTEM_INSTRUCTION = `
You are "Guru AI" (IIT JEE AI Master), an elite IIT JEE mentor with masteries across Physics, Physical/Organic/Inorganic Chemistry, and Advanced Mathematics.
Your mission is to guide JEE Main and JEE Advanced aspirants with mathematical rigor, intuitive conceptual clarity, and exam-cracking shortcuts.

Style & Formatting Guidelines:
1. Explain step-by-step with clear derivation and logic.
2. Highlight the "Core Concept / Formula Used" at the beginning.
3. Call out "Common Traps / Pitfalls" that negative marks occur from in JEE.
4. If applicable, provide a "JEE Ninja Shortcut / Elimination Trick" (e.g. dimensional analysis, boundary checking, symmetry, substitution).
5. Format mathematical equations clearly using standard text/LaTeX formatting (e.g., $E = mc^2$, $\\int_0^\\pi \\sin(x)dx$, $\\Delta G = \\Delta H - T\\Delta S$).
6. Provide encouraging, disciplined mentorship (Hinglish/English friendly, e.g. "Arjun ki tarah target par dhyan do", "Solid conceptual mastery is key").
7. If an image of a question or handwritten work is provided, transcribe the question carefully, diagnose any student mistakes, and provide the definitive solution.
`;

// AI Master Doubt Solver Chat Endpoint
app.post('/api/ai/doubt-solver', async (req, res) => {
  try {
    const { prompt, subject, topic, imageBase64, mimeType, history = [] } = req.body;

    if (!process.env.GEMINI_API_KEY) {
      return res.status(200).json({
        success: true,
        text: `⚠️ **Demo Note**: To connect live Gemini AI responses, please ensure GEMINI_API_KEY is configured in your Secrets panel.\n\n**Subject Context**: ${subject || 'Physics/Chemistry/Maths'}\n**Topic**: ${topic || 'IIT JEE General'}\n\nHere is a foundational JEE framework for your query:\n1. **Fundamental Principle**: Write down the governing equation and identify given constraints.\n2. **Free Body Diagram / Reaction Mechanism / Coordinate Map**: Visualize boundaries before calculating.\n3. **Sanity Check**: Verify units and dimensional balance at each step to prevent negative marking!`,
        isOfflineDemo: true,
      });
    }

    const contents: any[] = [];

    // Append prior conversational turns if provided
    if (Array.isArray(history) && history.length > 0) {
      for (const msg of history.slice(-6)) {
        contents.push({
          role: msg.role === 'user' ? 'user' : 'model',
          parts: [{ text: msg.content }],
        });
      }
    }

    const currentParts: any[] = [];

    if (imageBase64) {
      currentParts.push({
        inlineData: {
          mimeType: mimeType || 'image/jpeg',
          data: imageBase64.replace(/^data:image\/\w+;base64,/, ''),
        },
      });
    }

    const contextPrefix = `[Subject: ${subject || 'General JEE'}, Topic: ${topic || 'Core Concept'}]\nQuestion/Doubt:\n`;
    currentParts.push({
      text: contextPrefix + (prompt || 'Please analyze this JEE problem step-by-step.'),
    });

    contents.push({
      role: 'user',
      parts: currentParts,
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction: IIT_JEE_SYSTEM_INSTRUCTION,
        temperature: 0.4,
      },
    });

    return res.json({
      success: true,
      text: response.text || 'Solution generated successfully.',
    });
  } catch (error: any) {
    console.error('Error in /api/ai/doubt-solver:', error);
    return res.status(500).json({
      success: false,
      error: error?.message || 'Failed to process AI doubt query.',
    });
  }
});

// Dynamic Question / Drill Generator
app.post('/api/ai/generate-drill', async (req, res) => {
  try {
    const { subject, topic, difficulty = 'JEE Main', count = 3 } = req.body;

    if (!process.env.GEMINI_API_KEY) {
      return res.status(200).json({
        success: true,
        questions: [
          {
            id: 'demo-1',
            question: `A particle of mass m executes SHM with amplitude A. At what displacement from the mean position is its kinetic energy equal to half of its potential energy?`,
            subject: subject || 'Physics',
            topic: topic || 'Simple Harmonic Motion',
            difficulty: 'JEE Main',
            options: ['x = A/√3', 'x = A√2/√3', 'x = A/√2', 'x = A/2'],
            correctOption: 0,
            solution: 'KE = (1/2)mω²(A² - x²), PE = (1/2)mω²x². Given KE = (1/2)PE ⇒ (A² - x²) = (1/2)x² ⇒ x²(1 + 1/2) = A² ⇒ (3/2)x² = A² ⇒ x = A√(2/3) or if KE = PE/2, x = A√(2/3). Check option: x = A√(2/3).',
            shortcut: 'Use energy ratios: PE : KE = x² : (A² - x²). If KE/PE = 1/2, then (A²-x²)/x² = 1/2 ⇒ 2A² - 2x² = x² ⇒ 3x² = 2A² ⇒ x = A√(2/3).',
          }
        ],
        isDemo: true,
      });
    }

    const prompt = `Generate ${count} high-quality, authentic ${difficulty} level multiple-choice questions for IIT JEE.
Subject: ${subject}
Topic: ${topic}

Respond ONLY with valid JSON array of objects conforming to this schema:
[
  {
    "id": "gen-1",
    "question": "Full clear question statement with numerical values",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correctOption": 0, // index 0 to 3
    "solution": "Step-by-step conceptual derivation",
    "shortcut": "JEE exam hack / trick / elimination tip"
  }
]
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        systemInstruction: 'You are an IIT JEE question paper creator. Return strict JSON array only.',
        temperature: 0.3,
      },
    });

    const parsed = JSON.parse(response.text || '[]');
    return res.json({ success: true, questions: parsed });
  } catch (error: any) {
    console.error('Error generating drill:', error);
    return res.status(500).json({ success: false, error: 'Could not generate dynamic drill.' });
  }
});

// Setup Vite middleware in dev or static files in production
const isDev = process.env.NODE_ENV !== 'production';
if (isDev) {
  const { createServer } = await import('vite');
  const vite = await createServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (_req, res) => {
    res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
  });
}

app.listen(Number(PORT), '0.0.0.0', () => {
  console.log(`IIT JEE Sankalp server running on http://0.0.0.0:${PORT}`);
});
